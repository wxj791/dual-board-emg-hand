`timescale 1ns/1ps
// Integration boundary only; actual PLL period/phase verified in tb_1080_pll.
module vga_pll_25m2(input wire refclk,reset,output reg clk_pix=0,
 output wire clk_dac,locked);
 reg sim_run=1;reg [3:0] locks=0;
 always begin
  wait(sim_run);#(3.367003367*64);
  if(sim_run)clk_pix=~clk_pix;else clk_pix=0;
 end
 assign #2.525252525 clk_dac=clk_pix;
 always @(posedge refclk or posedge reset)
  if(reset)locks<=0;else if(locks!=15)locks<=locks+1'b1;
 assign locked=(locks==15)&&sim_run;
endmodule
