`timescale 1ns/1ps
module tb_tasks_old_a_replay;
 reg clk=0;always #20.833333 clk=~clk;reg rst=0,lc=0,lv=0;reg [7:0] ld=0;wire ready;
 always #500 lc=~lc;
 b_tasks_top #(.BOOT_CLKS(8),.SW_CLKS(8),.FLASH_RELEASE_CLKS(8)) d(
 .clk_24m(clk),.rst_n(rst),.host_uart_rx(1'b1),.display_sw(1'b1),.link_clk(lc),.link_valid(lv),.link_data(ld),.link_ready(ready),.scs_rx(1'b1),.flash_miso(1'b1));
 reg [7:0] bytes[0:71211];reg [831:0] expected[0:607];reg [255:0] expected_results[0:1];
 integer i,w=0,r=0,fifo_words=0,bad_results=0;reg [31:0] samples_before;integer lane;reg signed [31:0] val;reg [127:0] expected_scaled;
 integer clears=0,markers=0,mean_total,mi;
 always @(posedge d.clk_pix)if(d.pix_reset && d.pix_clear)clears=clears+1;
 always @(posedge d.clk_pix)if(d.pix_reset && d.capture_valid && d.fifo_capture[128])markers=markers+1;
 always @(negedge d.clk_pix)if(d.pix_reset && d.pix_clear && d.pix_valid)$fatal(1,"clear marker must not also publish a data sample");
 integer ring_words=0;reg write_pending=0;reg [9:0] written_address;reg [127:0] written_expected;
 reg frame_request=0,frame_sync1=0,frame_sync2=0,frame_seen=0,frame_commit=0;
 // Testbench-only mailbox: pixel work must never extend a link byte slot.
 always @(negedge d.clk_pix)begin
  frame_sync1<=frame_request;frame_sync2<=frame_sync1;frame_seen<=frame_sync2;
  frame_commit<=frame_sync2^frame_seen;
 end
 function automatic [127:0] scaled_expected(input [831:0] group_data);
  integer ch;reg signed [31:0] value;
  begin for(ch=0;ch<8;ch=ch+1)begin
   value=group_data[128+ch*16+:16];
   scaled_expected[ch*16+:16]=value>22900?22900:value< -22900?-22900:value;
  end end
 endfunction
 always @(posedge d.clk_pix)begin
  write_pending<=d.pix_reset && d.renderer.sample_valid1 && !d.renderer.history_clear;
  if(d.pix_reset && d.renderer.sample_valid1 && !d.renderer.history_clear)begin
   written_address<=d.renderer.write_ptr;written_expected<=scaled_expected(expected[d.sample_seq]);
  end
 end
 always @(negedge d.clk_pix)if(write_pending)begin
  if(written_address[0])begin
   if(d.renderer.native_trace.ring_odd[written_address[9:1]]!==written_expected)$fatal(1,"actual odd history RAM");
  end else if(d.renderer.native_trace.ring_even[written_address[9:1]]!==written_expected)$fatal(1,"actual even history RAM");
  ring_words=ring_words+1;
 end
 always @(posedge clk)if(d.sample_valid)begin
  if({d.slow_data,d.fast_data,d.filtered_data,d.raw_data}!==expected[d.sample_seq][831:128])$fatal(1,"A->B value sample=%d",d.sample_seq);
  if(d.sample_rate!==expected[d.sample_seq][79:64] || d.generation!==expected[d.sample_seq][95:80] || d.epoch!==expected[d.sample_seq][111:96])$fatal(1,"metadata");
  w=w+1;
 end
 always @(posedge clk)if(d.result_valid)begin
  if(1)$fatal(1,"invalid classification fabricated a valid result");
  if({32'd0,d.head_cycles,d.cnn_cycles,16'd0,d.epoch,d.class_count,d.generation,d.window_seq,d.margin,d.action_hint,d.class_id,d.result_flags,8'd1}!==expected_results[r])$fatal(1,"classification payload %d",r);
  r=r+1;
 end
 always @(posedge clk)if(d.result_fault)begin
  bad_results=bad_results+1;
  if(!d.reject_info[22] || d.class_id!=16'hffff || d.result_flags!=0)$fatal(1,"bad classification must disable action and preserve wave history");
 end
 always @(posedge d.clk_pix)if(d.capture_valid && !d.fifo_capture[128])begin
  fifo_words=fifo_words+1;
  for(lane=0;lane<8;lane=lane+1)begin
   val=expected[d.sample_seq][128+lane*16+:16];
   expected_scaled[lane*16+:16]=val>22900?22900:val< -22900?-22900:val;
  end
  if(d.fifo_capture[127:0]!==expected_scaled)$fatal(1,"A->B display FIFO sample %d",d.sample_seq);
 end
 initial begin
  $readmemh("artifacts/b_ab_v2/a_bad_capture.hex",bytes);$readmemh("artifacts/b_ab_v2/a_expected.hex",expected);$readmemh("artifacts/b_ab_v2/a_results.hex",expected_results);
  repeat(8)@(negedge clk);rst=1;wait(d.pix_reset);
  // Raster position is held during capture to avoid repeatedly simulating the
  // same artwork. Pixel clock, CDC, actual history RAM writes and scaling stay
  // at production rates. Independent display test checks native pixels.
  force d.renderer.timing.h=0;force d.renderer.timing.v=0;force d.renderer.frame_start=frame_commit;
  for(i=0;i<71212;i=i+1)begin
   @(negedge lc);while(!ready)@(negedge lc);ld=bytes[i];lv=1;
   // Commit the status mailbox periodically while the raster is parked, so a
   // real early stream break cannot arrive only at the final frame boundary.
   if(i%1000==0)frame_request=~frame_request;
  end
  @(negedge lc);lv=0;repeat(300)@(negedge clk);
  if(w!=602 || r!=0 || bad_results!=2 || d.a_crc!=0 || d.display_drops!=0 || fifo_words<512 || ring_words<512)$fatal(1,"capture totals w=%d r=%d fifo=%d ram=%d drops=%d crc=%d",w,r,fifo_words,ring_words,d.display_drops,d.a_crc);
  if(d.renderer.history<512)$fatal(1,"classification fault repeatedly clears wave history: history=%d clears=%d bad_results=%d",d.renderer.history,clears,bad_results);
  if(clears!=markers)$fatal(1,"empty FIFO replayed a clear marker: clears=%d markers=%d",clears,markers);
  wait(d.renderer.history>=512);frame_request=~frame_request;repeat(16000)@(negedge d.clk_pix);
  for(lane=0;lane<8;lane=lane+1)begin
   mean_total=0;
   for(mi=d.sample_seq-511;mi<=d.sample_seq;mi=mi+1)
    mean_total=mean_total+expected[mi][128+lane*16+:16];
   if(d.renderer.centers[lane*16+:16] !== (mean_total>>9))
    $fatal(1,"old A rolling mean lane=%d actual=%d expected=%d",lane,d.renderer.centers[lane*16+:16],mean_total>>9);
  end
  if(!d.renderer.wave_valid)$fatal(1,"display history not valid");
  $display("PASS: wave-debug actual top, real A waves through physical 1MHz parallel CRC, exact 8-channel values/FIFO/history RAM, invalid classifications isolated, history=%d wave_valid=%b clear_markers=%d clears=%d waves=%d results=%d fifo=%d ram=%d",d.renderer.history,d.renderer.wave_valid,markers,clears,w,r,fifo_words,ring_words);$finish;
 end
 initial begin #400000000;$fatal(1,"watchdog");end
endmodule
