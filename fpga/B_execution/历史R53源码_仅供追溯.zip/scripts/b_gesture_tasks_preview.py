"""Render synthetic scenes through the current private RTL; never run old scripts."""
from pathlib import Path
import ast,json,math,subprocess,hashlib
from PIL import Image
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'fpga_b/gesture_tasks';OUT=ROOT/'artifacts/b_gesture_tasks/preview_r53_text_minimal'
BIN=ROOT.parent/'.tools/icarus/portable/app/bin'
def main():
    OUT.mkdir(exist_ok=True)
    # Read only the historical raster-capture bench literal, without importing
    # its entrypoint (which writes old RTL/assets and is intentionally unused).
    tree=ast.parse((ROOT/'scripts/b_ab_v2_ui_r48_verify.py').read_text())
    function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    assignment=next(n for n in function.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='bench' for t in n.targets))
    bench=assignment.value.func.value.value
    bench=bench.replace('tb_b_v2_ui_r48','tb_tasks_preview').replace('artifacts/b_ab_v2/ui_r48','artifacts/b_gesture_tasks/preview_r50')
    bench=bench.replace('.servo_snapshot(320\'d0)',".servo_snapshot(snapshot)").replace('.channel_gains(gains)',".channel_gains(gains),.ranges(ranges),.custom(8'd0)")
    bench=bench.replace('reg [127:0] gains=0;',"reg [319:0] snapshot=0;reg [127:0] ranges={8{16'd1200}},centers={8{16'd1700}};reg [127:0] gains={8{16'd256}};")
    start=bench.index('  // Flow must follow')
    end=bench.index('  force r.animation_frame',start)
    bench=bench[:start]+'''  $readmemh("artifacts/b_gesture_tasks/preview_r50/preview_samples.hex",stimulus);
  for(i=0;i<5;i=i+1)begin
   snapshot[16+i*16+:16]=476+i*100;snapshot[96+i*16+:16]=16'h0401+i;
   snapshot[176+i*16+:16]=16'h0400+20+i;
  end
  snapshot[256+:5]=31;snapshot[261+:5]=15;snapshot[266+:5]=31;snapshot[289+:5]=31;
  force r.centers=centers;
'''+bench[end:]
    bench=bench.replace('SCENE_CASES','''0:begin page=0;rate=1000;fill=512;ready=1;frozen=0;flow=1;clip=0;ranges={8{16'd1200}};end
1:begin page=1;rate=1000;fill=512;ready=1;frozen=0;flow=1;clip=1;ranges={8{16'd200}};end
2:begin page=2;rate=1000;fill=512;ready=1;frozen=1;flow=1;clip=0;ranges={8{16'd100}};end
3:begin page=3;rate=0;fill=0;ready=0;frozen=0;flow=0;clip=0;snapshot=0;ranges={8{16'd100}};end''')
    bench=bench.replace('   tick_frame;\n   tx=0;', '''   for(i=0;i<512;i=i+1)begin
    r.native_trace.ring_even[i]=stimulus[s*1024+i*2];r.native_trace.ring_odd[i]=stimulus[s*1024+i*2+1];
   end
   tick_frame;repeat(700)@(negedge clk);
   tx=0;''')
    bench=bench.replace('stimulus[0:1023]','stimulus[0:4095]')
    bench=bench.replace('PASS: UI flow/timeout/freeze, decimal edge cases and four actual renderer scenes','PASS: four current B renderer scenes captured')
    bench=bench.replace('preview_r50','preview_r53_text_minimal')
    benchfile=OUT/'tb_tasks_preview.sv';benchfile.write_text(bench)
    samples=[]
    for scene in range(4):
        for i in range(1024):
            word=0
            for ch in range(8):
                wave=math.sin(i*(ch+2)*math.pi/130)*(0.55+0.45*math.sin(i*math.pi/300)**2)
                value=round(1700+750*wave) if scene==0 else round(27000*wave if scene==1 else 20000*wave)
                word|=(value&65535)<<(ch*16)
            samples.append(word)
    (OUT/'preview_samples.hex').write_text(''.join(f'{v:032x}\n' for v in samples))
    names=['b_v2_timing','b_v2_ui_r48_font','b_v2_native_trace','b_v2_whale_sprite','b_v2_whale_player','b_v2_ui_numbers','b_v2_ui_r48_renderer']
    paths=[D/(n+'.v') for n in names]
    paths_with_assets=paths+list((D/'assets').rglob('*.hex'))
    hashes={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths_with_assets}
    font=[int(x,16) for x in (D/'assets/font_rows.hex').read_text().split()]
    text=[int(x,16) for x in (D/'assets/text_rows_minimal.hex').read_text().split()]
    assert all(c==32 or any(font[c*8:(c+1)*8]) for c in set(text)), 'Missing visible title glyph'
    with (OUT/'simulation.log').open('wb') as stream:
        subprocess.run([str(BIN/'iverilog.exe'),'-g2012','-s','tb_tasks_preview','-o',str(OUT/'preview.vvp')]+[str(p) for p in paths]+[str(benchfile)],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)
        subprocess.run([str(BIN/'vvp.exe'),str(OUT/'preview.vvp')],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=1200,check=True)
    scenes=[]
    for i,name in enumerate(['raw_live','filter_clip','envelope_hold','waiting']):
        rgb=Image.new('RGB',(640,480),(8,12,24));seen=set()
        for line in (OUT/f'scene_{i}.hex').read_text().splitlines():
            x,y,c=(int(v,16) for v in line.split())
            if x<640 and y<480:
                rgb.putpixel((x,y),((c>>16)&255,(c>>8)&255,c&255));seen.add((x,y))
        rgb.resize((1280,960),Image.Resampling.NEAREST).save(OUT/(name+'.png'))
        scenes.append(dict(name=name,pixels=len(seen),passed=len(seen)==640*480))
    result=dict(passed=all(s['passed'] for s in scenes),scenes=scenes,input_hashes=hashes,stimulus='Synthetic display samples and servo snapshot; not board measurements',hardware='NOT_RUN')
    (OUT/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
