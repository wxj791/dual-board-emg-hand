"""Patch private r48 copies once, keeping the fine trace and whale pipelines."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'fpga_b/gesture_tasks'
def main():
    src=(ROOT/'fpga_b/ab_scope_v2/b_v2_native_trace.v').read_text()
    src=src.replace('input wire [9:0] write_ptr,view_base,',
        'input wire [9:0] write_ptr,view_base,\n input wire raw_page,\n input wire [127:0] centers,ranges,gains,input wire [7:0] custom,')
    src=src.replace('input wire wave_valid,','input wire wave_valid,view_commit,history_clear,output reg clipped,')
    src=src.replace('reg high_a5,low_a5,high_b5,low_b5;', '''reg high_a5,low_a5,high_b5,low_b5;
 reg clip_accum;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin clip_accum<=0;clipped<=0;end
  else if(history_clear)begin clip_accum<=0;clipped<=0;end
  else if(view_commit)begin clipped<=clip_accum;clip_accum<=0;end
  else if(region_pipe[5] && valid_pipe[5] && (high_a5 || low_a5 || high_b5 || low_b5))clip_accum<=1;
 end''')
    src=src.replace('reg signed [22:0] scale_a4,scale_b4;',
        '''reg signed [40:0] scale_a4,scale_b4;
 reg [23:0] coef3;
 function [23:0] raw_coef;input [15:0] r;
  begin case(r)
   20:raw_coef=2149581;50:raw_coef=859832;100:raw_coef=429916;
   200:raw_coef=214958;500:raw_coef=85983;1200:raw_coef=35826;default:raw_coef=13028;
  endcase end
 endfunction''')
    src=src.replace('sample_a3<=data_a2[channel[2]*16+:16];',
        '''sample_a3<=raw_page?$signed({1'b0,data_a2[channel[2]*16+:16]})-$signed({1'b0,centers[channel[2]*16+:16]}):data_a2[channel[2]*16+:16];
  coef3<=raw_page?(custom[channel[2]]?gains[channel[2]*16+:16]*24'd117:raw_coef(ranges[channel[2]*16+:16])):24'd1872;''')
    src=src.replace('sample_b3<=last2?data_a2[channel[2]*16+:16]:data_b2[channel[2]*16+:16];',
        '''sample_b3<=raw_page?$signed({1'b0,(last2?data_a2[channel[2]*16+:16]:data_b2[channel[2]*16+:16])})-$signed({1'b0,centers[channel[2]*16+:16]}):(last2?data_a2[channel[2]*16+:16]:data_b2[channel[2]*16+:16]);''')
    src=src.replace("scale_a4<=sample_a3*23'sd117;scale_b4<=sample_b3*23'sd117;",
        "scale_a4<=sample_a3*$signed({1'b0,coef3});scale_b4<=sample_b3*$signed({1'b0,coef3});")
    src=src.replace('scale_a4[22:8]','($signed(scale_a4)>>>12)').replace('scale_b4[22:8]','($signed(scale_b4)>>>12)')
    # Configuration changes in blanking. Compute coefficients ahead of raster
    # selection so CUSTOM gain multiplication cannot chain into pixel scaling.
    src=src.replace('reg [23:0] coef3;', '''reg [23:0] coef3;
 reg [23:0] lane_coef[0:7];
 reg [2:0] cfg_lane,cfg_lane1,cfg_lane2;
 reg [15:0] cfg_gain,cfg_gain2,cfg_range;
 reg [23:0] cfg_standard;
 reg cfg_custom,cfg_custom2;
 always @(posedge clk or negedge rst_n)
  if(!rst_n)begin cfg_lane<=0;cfg_lane1<=0;cfg_lane2<=0;cfg_gain<=0;cfg_gain2<=0;cfg_range<=0;cfg_standard<=0;cfg_custom<=0;cfg_custom2<=0;end
  else begin
   cfg_lane<=cfg_lane+1'b1;cfg_lane1<=cfg_lane;cfg_lane2<=cfg_lane1;
   cfg_gain<=gains[cfg_lane*16+:16];cfg_range<=ranges[cfg_lane*16+:16];cfg_custom<=custom[cfg_lane];
   cfg_standard<=raw_coef(cfg_range);cfg_gain2<=cfg_gain;cfg_custom2<=cfg_custom;
  end
 always @(posedge clk)lane_coef[cfg_lane2]<=cfg_custom2?cfg_gain2*24'd117:cfg_standard;
 reg [15:0] lane_a2,lane_b2,center2;
 always @(posedge clk)begin
  lane_a2<=odd_first1?odd1[channel[1]*16+:16]:even1[channel[1]*16+:16];
  lane_b2<=last1?(odd_first1?odd1[channel[1]*16+:16]:even1[channel[1]*16+:16]):(odd_first1?even1[channel[1]*16+:16]:odd1[channel[1]*16+:16]);
  center2<=centers[channel[1]*16+:16];
 end''')
    src=src.replace("coef3<=raw_page?(custom[channel[2]]?gains[channel[2]*16+:16]*24'd117:raw_coef(ranges[channel[2]*16+:16])):24'd1872;", "coef3<=raw_page?lane_coef[channel[2]]:24'd1872;")
    src=src.replace("sample_a3<=raw_page?$signed({1'b0,data_a2[channel[2]*16+:16]})-$signed({1'b0,centers[channel[2]*16+:16]}):data_a2[channel[2]*16+:16];", "sample_a3<=raw_page?$signed({1'b0,lane_a2})-$signed({1'b0,center2}):lane_a2;")
    src=src.replace("sample_b3<=raw_page?$signed({1'b0,(last2?data_a2[channel[2]*16+:16]:data_b2[channel[2]*16+:16])})-$signed({1'b0,centers[channel[2]*16+:16]}):(last2?data_a2[channel[2]*16+:16]:data_b2[channel[2]*16+:16]);", "sample_b3<=raw_page?$signed({1'b0,lane_b2})-$signed({1'b0,center2}):lane_b2;")
    # Split signed16 x unsigned24 into two registered DSP partial products.
    # The carry merge gets its own cycle, retaining exact Q12 arithmetic.
    src=src.replace('reg signed [40:0] scale_a4,scale_b4;', '''reg signed [40:0] scale_a4,scale_b4;
 reg signed [33:0] scale_low_a4,scale_low_b4;
 reg signed [23:0] scale_high_a4,scale_high_b4;''')
    src=src.replace("scale_a4<=sample_a3*$signed({1'b0,coef3});scale_b4<=sample_b3*$signed({1'b0,coef3});", '''scale_low_a4<=sample_a3*$signed({1'b0,coef3[16:0]});
  scale_low_b4<=sample_b3*$signed({1'b0,coef3[16:0]});
  scale_high_a4<=sample_a3*$signed({1'b0,coef3[23:17]});
  scale_high_b4<=sample_b3*$signed({1'b0,coef3[23:17]});
  scale_a4<={{7{scale_low_a4[33]}},scale_low_a4}+{scale_high_a4,17'd0};
  scale_b4<={{7{scale_low_b4[33]}},scale_low_b4}+{scale_high_b4,17'd0};''')
    src=src.replace('channel[0:17]','channel[0:18]').replace('lane[0:6]','lane[0:7]').replace('phase[0:6]','phase[0:7]')
    src=src.replace('reg [17:0] region_pipe,valid_pipe,mid_grid,edge_grid;','reg [18:0] region_pipe,valid_pipe,mid_grid,edge_grid;')
    for name in ('region_pipe','valid_pipe','mid_grid','edge_grid'):
        src=src.replace(name+'[16:0]',name+'[17:0]').replace(name+'[17]',name+'[18]')
    src=src.replace('data_i<18','data_i<19').replace('data_i<7','data_i<8')
    src=src.replace('lane[6]','lane[7]').replace('phase[6]','phase[7]').replace('channel[16]','channel[17]')
    src=src.replace('region_pipe[5] && valid_pipe[5]','region_pipe[6] && valid_pipe[6]')
    # Register the full BRAM words before the channel mux. This separates BRAM
    # clock-to-out/routing from 8-channel selection without changing storage.
    src=src.replace('reg [15:0] lane_a2,lane_b2,center2;', '''reg [15:0] lane_a2,lane_b2,center2;
 reg [127:0] even_read2,odd_read2;reg odd_first2,last_read2;
 always @(posedge clk)begin
  even_read2<=even1;odd_read2<=odd1;odd_first2<=odd_first1;last_read2<=last1;
 end''')
    src=src.replace('lane_a2<=odd_first1?odd1[channel[1]*16+:16]:even1[channel[1]*16+:16];','lane_a2<=odd_first2?odd_read2[channel[2]*16+:16]:even_read2[channel[2]*16+:16];')
    src=src.replace('lane_b2<=last1?(odd_first1?odd1[channel[1]*16+:16]:even1[channel[1]*16+:16]):(odd_first1?even1[channel[1]*16+:16]:odd1[channel[1]*16+:16]);','lane_b2<=last_read2?(odd_first2?odd_read2[channel[2]*16+:16]:even_read2[channel[2]*16+:16]):(odd_first2?even_read2[channel[2]*16+:16]:odd_read2[channel[2]*16+:16]);')
    src=src.replace('center2<=centers[channel[1]*16+:16];','center2<=centers[channel[2]*16+:16];').replace('lane_coef[channel[2]]','lane_coef[channel[3]]')
    src=src.replace('channel[0:18]','channel[0:19]').replace('lane[0:7]','lane[0:8]').replace('phase[0:7]','phase[0:8]')
    src=src.replace('reg [18:0] region_pipe,valid_pipe,mid_grid,edge_grid;','reg [19:0] region_pipe,valid_pipe,mid_grid,edge_grid;')
    for name in ('region_pipe','valid_pipe','mid_grid','edge_grid'):
        src=src.replace(name+'[17:0]',name+'[18:0]').replace(name+'[18]',name+'[19]')
    src=src.replace('data_i<19','data_i<20').replace('data_i<8','data_i<9')
    src=src.replace('lane[7]','lane[8]').replace('phase[7]','phase[8]').replace('channel[17]','channel[18]')
    src=src.replace('region_pipe[6] && valid_pipe[6]','region_pipe[7] && valid_pipe[7]')
    (D/'b_v2_native_trace.v').write_text(src)
    src=(ROOT/'fpga_b/ab_scope_v2/b_v2_ui_r48_renderer.v').read_text()
    src=src.replace('input wire [127:0] channel_gains,',
        'input wire [127:0] channel_gains,ranges,input wire [7:0] custom,')
    src=src.replace('reg [127:0] sample_data1;reg sample_valid1;',
        '''reg [127:0] sample_data1;reg sample_valid1;
 (* ram_style="block" *) reg [127:0] mean_ring[0:511];
 reg [127:0] mean_old,mean_new,mean_old2,mean_new2,centers;
 reg mean_pending,mean_full,mean_pending2,mean_full2,mean_delta_valid;reg signed [16:0] mean_delta[0:7];reg [21:0] mean_sum[0:7];integer mean_i;
 always @(posedge clk)begin
  mean_old<=mean_ring[write_ptr[8:0]];
  if(sample_valid1 && !history_clear && page==0)mean_ring[write_ptr[8:0]]<=sample_data1;
  mean_new<=sample_data1;
  mean_old2<=mean_old;mean_new2<=mean_new;
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin mean_pending<=0;mean_full<=0;mean_pending2<=0;mean_full2<=0;mean_delta_valid<=0;centers<=0;for(mean_i=0;mean_i<8;mean_i=mean_i+1)mean_sum[mean_i]<=0;end
  else begin
   mean_pending<=sample_valid1 && !history_clear && page==0;mean_full<=history>=512;
   mean_pending2<=mean_pending;mean_full2<=mean_full;
   mean_delta_valid<=mean_pending2;
   if(mean_pending2)for(mean_i=0;mean_i<8;mean_i=mean_i+1)
    mean_delta[mean_i]<=$signed({1'b0,mean_new2[mean_i*16+:16]})-$signed({1'b0,(mean_full2?mean_old2[mean_i*16+:16]:16'd0)});
   if(mean_delta_valid)for(mean_i=0;mean_i<8;mean_i=mean_i+1)
    mean_sum[mean_i]<=mean_sum[mean_i]+{{5{mean_delta[mean_i][16]}},mean_delta[mean_i]};
   if(history_clear)begin mean_pending<=0;mean_pending2<=0;mean_delta_valid<=0;for(mean_i=0;mean_i<8;mean_i=mean_i+1)mean_sum[mean_i]<=0;end
   if(view_commit)for(mean_i=0;mean_i<8;mean_i=mean_i+1)centers[mean_i*16+:16]<=mean_sum[mean_i]>>9;
  end
 end
 reg view_waiting;
 wire view_commit=(frame_start || view_waiting) && !sample_valid1 && !mean_pending && !mean_pending2 && !mean_delta_valid;
 always @(posedge clk or negedge rst_n)if(!rst_n)view_waiting<=0;else if(history_clear)view_waiting<=0;else if(view_commit)view_waiting<=0;else if(frame_start)view_waiting<=1;
''')
    src=src.replace('if(frame_start && !history_clear)begin','if(view_commit && !history_clear)begin')
    src=src.replace('.sample_data(sample_data1),.write_ptr(write_ptr)',
        '.sample_data(sample_data1),.raw_page(page==0),.centers(centers),.ranges(ranges),.gains(channel_gains),.custom(custom),.write_ptr(write_ptr)')
    src=src.replace('wire [23:0] native_rgb;wire native_active;', 'wire [23:0] native_rgb;wire native_active,native_clip;')
    src=src.replace('.wave_valid(wave_valid),','.wave_valid(wave_valid),.view_commit(view_commit),.history_clear(history_clear),.clipped(native_clip),')
    src=src.replace('saturated?11:10','(saturated || native_clip)?11:10').replace('wave_seen && saturated','wave_seen && (saturated || native_clip)')
    # Decimal range and center text is computed slowly at frame boundary.
    src=src.replace('wire [19:0] rate_bcd;', '''reg [127:0] ranges_bcd,centers_bcd;
 reg [79:0] positions_bcd,loads_bcd;
 reg [4:0] number_item,number_bit;reg numbers_busy;
 reg [31:0] number_shift;reg [31:0] number_adjusted;reg [15:0] number_input;
 integer number_k;
 always @*begin
  number_input=0;
  if(number_item<8)number_input=ranges[number_item*16+:16];
  else if(number_item<16)number_input=centers[(number_item-8)*16+:16];
  else if(number_item<21)number_input=servo_snapshot[16+(number_item-16)*16+:16];
  else number_input=servo_snapshot[176+(number_item-21)*16+:16]&16'h03ff;
  number_adjusted=number_shift;
  for(number_k=16;number_k<32;number_k=number_k+4)
   if(number_shift[number_k+:4]>=5)number_adjusted[number_k+:4]=number_shift[number_k+:4]+3;
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin ranges_bcd<=0;centers_bcd<=0;positions_bcd<=0;loads_bcd<=0;
   number_item<=0;number_bit<=0;number_shift<=0;numbers_busy<=0;end
  else begin
   if(view_commit)begin number_item<=0;number_bit<=0;numbers_busy<=1;end
   else if(numbers_busy)begin
    if(number_bit==0)begin number_shift<={16'd0,number_input};number_bit<=1;end
    else if(number_bit<=16)begin number_shift<=number_adjusted<<1;number_bit<=number_bit+1'b1;end
    else begin
     if(number_item<8)ranges_bcd[number_item*16+:16]<=number_shift[31:16];
     else if(number_item<16)centers_bcd[(number_item-8)*16+:16]<=number_shift[31:16];
     else if(number_item<21)positions_bcd[(number_item-16)*16+:16]<=number_shift[31:16];
     else loads_bcd[(number_item-21)*16+:16]<=number_shift[31:16];
     if(number_item==25)numbers_busy<=0;else begin number_item<=number_item+1'b1;number_bit<=0;end
    end
   end
  end
 end
 wire [19:0] rate_bcd;''')
    src=src.replace('gain_n0<=channel_gains[{lane_id(y),~x[4:3],2\'b00}+:4];',
        'gain_n0<=ranges_bcd[{lane_id(y),~x[4:3],2\'b00}+:4];')
    src=src.replace('if(col0>=4)begin dynamic_valid_early=1;dynamic_nibble_early=gain_n0;end',
        '''if(col0>=4)begin dynamic_valid_early=1;dynamic_nibble_early=gain_n0;end
   if(custom[channel_early])begin template_id_early=30;dynamic_valid_early=0;end''')
    # Per-channel center on second lane line, in the pre-existing left margin.
    src=src.replace('end else if(x0<384)begin', '''end else if(y0>=48 && y0<368 && lane_early>=16 && lane_early<32 && col0<8 && page==0)begin
   template_id_early=27;text_colour_early=24'h9cacc6;
   if(col0>=4)begin dynamic_valid_early=1;dynamic_nibble_early=centers_bcd[{channel_early,~col0[1:0],2'b00}+:4];end
  end else if(x0<384)begin''')
    src=src.replace('reg [4:0] template_id,template_id_early;', '''wire [2:0] servo_row=y0[6:4];
 wire [1:0] speed_digit=2'd2-col0[1:0],load_digit=2'd1-col0[1:0];
 reg [4:0] template_id,template_id_early;''')
    src=src.replace("else if(y0>=384 && y0<464)begin template_id_early=22+((y0-384)>>4);text_colour_early=24'h6d819d;end", '''else if(y0>=384 && y0<464)begin
    template_id_early=22+servo_row;text_colour_early=24'h6d819d;
    if(servo_snapshot[266+servo_row])begin
     if(col0>=4 && col0<8)begin dynamic_valid_early=1;dynamic_nibble_early=positions_bcd[{servo_row,~col0[1:0],2'b00}+:4];end
     if(col0>=11 && col0<15)begin dynamic_valid_early=1;dynamic_nibble_early=servo_snapshot[96+{servo_row,speed_digit,2'b00}+:4];end
     if(col0>=18 && col0<22)begin dynamic_valid_early=1;dynamic_nibble_early=loads_bcd[{servo_row,load_digit,2'b00}+:4];end
    end
    if(col0==24)begin dynamic_valid_early=1;dynamic_nibble_early={3'd0,servo_snapshot[256+servo_row]};end
    if(col0==27 && servo_snapshot[289+servo_row])begin dynamic_valid_early=1;dynamic_nibble_early={3'd0,servo_snapshot[261+servo_row]};end
    if(col0==30)begin dynamic_valid_early=1;dynamic_nibble_early={3'd0,servo_snapshot[266+servo_row]};end
    if(col0==33)begin dynamic_valid_early=1;dynamic_nibble_early={3'd0,servo_snapshot[186+{servo_row,4'd0}]};end
   end''')
    src=src.replace("if(y0<384 && y0>=368)begin template_id_early=21;text_colour_early=24'hffc56b;end", "if(y0<384 && y0>=368)begin template_id_early=21;text_colour_early=24'hffc56b;if(col0==35)begin dynamic_valid_early=1;dynamic_nibble_early={3'd0,armed};end end")
    # Private font adds the bipolar '+' glyph missing from the r48 alphabet.
    # Original font and whale ROMs remain read-only.
    font=[int(x,16) for x in (ROOT/'fpga_b/ab_scope_v2/assets/ui_r48/font_rows.hex').read_text().split()]
    font[ord('+')*8:ord('+')*8+8]=[0,4,4,31,4,4,0,0]
    (D/'assets/font_rows.hex').write_text(''.join(f'{v:02x}\n' for v in font))
    font_rtl=(D/'b_v2_ui_r48_font.v').read_text().replace('fpga_b/ab_scope_v2/assets/ui_r48/font_rows.hex','fpga_b/gesture_tasks/assets/font_rows.hex')
    (D/'b_v2_ui_r48_font.v').write_text(font_rtl)
    # Custom text ROM; no changes to old font or whale ROMs.
    rows=[int(x,16) for x in (ROOT/'fpga_b/ab_scope_v2/assets/ui_r48/text_rows.hex').read_text().split()]
    def text(index,s):
        rows[index*128:(index+1)*128]=[ord(c) for c in s.ljust(128)]
    text(4,'NOMINAL       Hz   WINDOW 512 PTS   ADC mV / RANGE PER CHANNEL')
    text(0,'RAW / +/- RANGE mV / CENTER = VISIBLE 512 MEAN')
    text(1,'FILTER / +/- RANGE mV / CENTER = ZERO')
    text(2,'FAST ENVELOPE / 0..RANGE mV / ZERO AT BOTTOM')
    text(3,'SLOW ENVELOPE / 0..RANGE mV / ZERO AT BOTTOM')
    for i in range(8):text(13+i,f'CH{i} 0000')
    text(27,'CTR 0000')
    text(30,'CUSTOM')
    text(28,'R50 / GESTURE TASKS / GPIO RETURN')
    # Bottom panel gets live controller status rather than DISABLED placeholders.
    text(21,'P/L COUNTS H=SPEED HEX O/T/F/D ARM=0')
    for i in range(5):text(22+i,f'{i+1} P ---- H ---- L ---- O0 T- F0 D0')
    assets=D/'assets';assets.mkdir(exist_ok=True)
    (assets/'text_rows.hex').write_text(''.join(f'{v:02x}\n' for v in rows))
    src=src.replace('fpga_b/ab_scope_v2/assets/ui_r48/text_rows.hex','fpga_b/gesture_tasks/assets/text_rows.hex')
    # Footer tells bipolar and envelope semantics, decimal mV labels above.
    src=src.replace('template_id_early=21;text_colour_early', 'template_id_early=21;text_colour_early')
    # Match the added native multiply-merge cycle in every overlay/timing path.
    src=src.replace('overlay_pipe[0:11]','overlay_pipe[0:13]').replace('overlay_pipe[11]','overlay_pipe[13]').replace('pipe_i<12','pipe_i<14')
    src=src.replace('reg [21:0] output_flush','reg [23:0] output_flush').replace('output_flush[20:0]','output_flush[22:0]').replace('output_reset_n<=output_flush[21]','output_reset_n<=output_flush[23]')
    # Decimal updates start one blanking cycle later; the raster frame-start
    # and history-commit logic no longer feed every BCD register enable.
    src=src.replace('reg [127:0] ranges_bcd,centers_bcd;', '''reg number_update;
 always @(posedge clk or negedge rst_n)if(!rst_n)number_update<=0;else number_update<=view_commit;
 reg [127:0] ranges_bcd,centers_bcd;''')
    src=src.replace('if(view_commit)begin number_item<=0;','if(number_update)begin number_item<=0;')
    # Select each decimal source bank before the shared conversion input.
    # Two settling cycles follow item changes; arithmetic precision is unchanged.
    src=src.replace('integer number_k;', '''reg [15:0] number_range,number_center,number_position,number_load;
 always @(posedge clk)begin
  number_range<=ranges[number_item[2:0]*16+:16];
  number_center<=centers[number_item[2:0]*16+:16];
  number_position<=servo_snapshot[16+number_item[2:0]*16+:16];
  number_load<=servo_snapshot[176+(number_item-21)*16+:16]&16'h03ff;
 end
 integer number_k;''')
    src=src.replace('number_input=ranges[number_item*16+:16]','number_input=number_range').replace('number_input=centers[(number_item-8)*16+:16]','number_input=number_center')
    src=src.replace('number_input=servo_snapshot[16+(number_item-16)*16+:16]','number_input=number_position').replace("number_input=servo_snapshot[176+(number_item-21)*16+:16]&16'h03ff",'number_input=number_load')
    src=src.replace("if(number_bit==0)begin number_shift<={16'd0,number_input};number_bit<=1;end", "if(number_bit==0)number_bit<=1;\n    else if(number_bit==1)begin number_shift<={16'd0,number_input};number_bit<=2;end")
    src=src.replace('else if(number_bit<=16)begin','else if(number_bit<=17)begin')
    # Preselect new center/servo decimal nibbles in the same stage as r48 gain.
    # Their earlier raster coordinates keep overlay alignment unchanged.
    src=src.replace('reg [3:0] gain_n0,rate_n0,fill_n0,count_n0;', '''reg [3:0] gain_n0,rate_n0,fill_n0,count_n0,center_n0,position_n0,speed_n0,load_n0;
 wire [2:0] servo_row_input=y[6:4];
 wire [1:0] speed_digit_input=2'd2-x[4:3],load_digit_input=2'd1-x[4:3];
 always @(posedge clk)begin
  center_n0<=centers_bcd[{lane_id(y),~x[4:3],2'b00}+:4];
  position_n0<=positions_bcd[{servo_row_input,~x[4:3],2'b00}+:4];
  speed_n0<=servo_snapshot[96+{servo_row_input,speed_digit_input,2'b00}+:4];
  load_n0<=loads_bcd[{servo_row_input,load_digit_input,2'b00}+:4];
 end''')
    src=src.replace("dynamic_nibble_early=centers_bcd[{channel_early,~col0[1:0],2'b00}+:4]",'dynamic_nibble_early=center_n0')
    src=src.replace("dynamic_nibble_early=positions_bcd[{servo_row,~col0[1:0],2'b00}+:4]",'dynamic_nibble_early=position_n0')
    src=src.replace("dynamic_nibble_early=servo_snapshot[96+{servo_row,speed_digit,2'b00}+:4]",'dynamic_nibble_early=speed_n0')
    src=src.replace("dynamic_nibble_early=loads_bcd[{servo_row,load_digit,2'b00}+:4]",'dynamic_nibble_early=load_n0')
    # A per-item registered enable drives only one 16-bit BCD destination.
    # Avoid distributing the number_bit comparison to all 416 destination CEs.
    src=src.replace('reg [127:0] ranges_bcd,centers_bcd;', '''reg [25:0] number_write;
 reg [15:0] number_result;
 integer write_i;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin number_write<=0;number_result<=0;end
  else begin
   for(write_i=0;write_i<26;write_i=write_i+1)
    number_write[write_i]<=numbers_busy && number_bit==18 && number_item==write_i;
   number_result<=number_shift[31:16];
  end
 end
 reg [127:0] ranges_bcd,centers_bcd;''')
    src=src.replace('ranges_bcd<=0;centers_bcd<=0;positions_bcd<=0;loads_bcd<=0;', '')
    old='''if(number_item<8)ranges_bcd[number_item*16+:16]<=number_shift[31:16];
     else if(number_item<16)centers_bcd[(number_item-8)*16+:16]<=number_shift[31:16];
     else if(number_item<21)positions_bcd[(number_item-16)*16+:16]<=number_shift[31:16];
     else loads_bcd[(number_item-21)*16+:16]<=number_shift[31:16];'''
    assert old in src
    src=src.replace(old,'')
    src=src.replace('wire [19:0] rate_bcd;', '''genvar bcd_item;
 generate for(bcd_item=0;bcd_item<26;bcd_item=bcd_item+1)begin:bcd_destination
  if(bcd_item<8)begin
   always @(posedge clk or negedge rst_n)if(!rst_n)ranges_bcd[bcd_item*16+:16]<=0;else if(number_write[bcd_item])ranges_bcd[bcd_item*16+:16]<=number_result;
  end else if(bcd_item<16)begin
   always @(posedge clk or negedge rst_n)if(!rst_n)centers_bcd[(bcd_item-8)*16+:16]<=0;else if(number_write[bcd_item])centers_bcd[(bcd_item-8)*16+:16]<=number_result;
  end else if(bcd_item<21)begin
   always @(posedge clk or negedge rst_n)if(!rst_n)positions_bcd[(bcd_item-16)*16+:16]<=0;else if(number_write[bcd_item])positions_bcd[(bcd_item-16)*16+:16]<=number_result;
  end else begin
   always @(posedge clk or negedge rst_n)if(!rst_n)loads_bcd[(bcd_item-21)*16+:16]<=0;else if(number_write[bcd_item])loads_bcd[(bcd_item-21)*16+:16]<=number_result;
  end
 end endgenerate
 wire [19:0] rate_bcd;''')
    src=src.replace('center_n0<=centers_bcd[{lane_id(y),~x[4:3],2\'b00}+:4];', '')
    src=src.replace('reg [3:0] gain_n0,rate_n0,fill_n0,count_n0,center_n0,position_n0,speed_n0,load_n0;', '''reg [3:0] gain_n0,rate_n0,fill_n0,count_n0,position_n0,speed_n0,load_n0;
 reg [31:0] center_digits;integer digit_lane;
 always @(posedge clk)for(digit_lane=0;digit_lane<8;digit_lane=digit_lane+1)
  center_digits[digit_lane*4+:4]<=centers_bcd[digit_lane*16+{~x[4:3],2'b00}+:4];
 wire [3:0] center_n0=center_digits[channel_early*4+:4];''')
    src=src.replace('reg [3:0] gain_n0,rate_n0,fill_n0,count_n0,position_n0,speed_n0,load_n0;', '''reg [3:0] rate_n0,fill_n0,count_n0;
 reg [31:0] range_digits;reg [19:0] position_digits,speed_digits,load_digits;integer servo_digit;
 always @(posedge clk)begin
  for(servo_digit=0;servo_digit<8;servo_digit=servo_digit+1)
   range_digits[servo_digit*4+:4]<=ranges_bcd[servo_digit*16+{~x[4:3],2'b00}+:4];
  for(servo_digit=0;servo_digit<5;servo_digit=servo_digit+1)begin
   position_digits[servo_digit*4+:4]<=positions_bcd[servo_digit*16+{~x[4:3],2'b00}+:4];
   speed_digits[servo_digit*4+:4]<=servo_snapshot[96+servo_digit*16+{speed_digit_input,2'b00}+:4];
   load_digits[servo_digit*4+:4]<=loads_bcd[servo_digit*16+{load_digit_input,2'b00}+:4];
  end
 end
 wire [3:0] gain_n0=range_digits[channel_early*4+:4];
 wire [3:0] position_n0=position_digits[servo_row*4+:4];
 wire [3:0] speed_n0=speed_digits[servo_row*4+:4];
 wire [3:0] load_n0=load_digits[servo_row*4+:4];''')
    for line in ["gain_n0<=ranges_bcd[{lane_id(y),~x[4:3],2'b00}+:4];", "position_n0<=positions_bcd[{servo_row_input,~x[4:3],2'b00}+:4];", "speed_n0<=servo_snapshot[96+{servo_row_input,speed_digit_input,2'b00}+:4];", "load_n0<=loads_bcd[{servo_row_input,load_digit_input,2'b00}+:4];"]:
        assert line in src
        src=src.replace(line,'')
    # Register lane-line predicates alongside the existing early raster stage.
    # This removes the lane subtraction/comparison from text priority selection.
    src=src.replace('reg [2:0] channel_early;reg [5:0] lane_early;', '''reg [2:0] channel_early;reg [5:0] lane_early;
 reg range_line_early,center_line_early;
 always @(posedge clk)begin
  range_line_early<=y>=48 && y<368 && lane_offset(y)<16 && x[9:3]<8;
  center_line_early<=y>=48 && y<368 && lane_offset(y)>=16 && lane_offset(y)<32 && x[9:3]<8;
 end''')
    src=src.replace('y0<368 && lane_early<16 && col0<8','range_line_early')
    src=src.replace('y0>=48 && y0<368 && lane_early>=16 && lane_early<32 && col0<8 && page==0','center_line_early && page==0')
    # Decode text column regions beside x0, before the priority/data mux.
    # Every predicate sees the same pixel as the original col0 expression.
    column_regions=[('col0>=8 && col0<=12','x[9:3]>=8 && x[9:3]<=12'),
        ('col0>=27 && col0<=29','x[9:3]>=27 && x[9:3]<=29'),
        ('col0>=65 && col0<=72','x[9:3]>=65 && x[9:3]<=72'),
        ('col0>=4 && col0<8','x[9:3]>=4 && x[9:3]<8'),
        ('col0>=11 && col0<15','x[9:3]>=11 && x[9:3]<15'),
        ('col0>=18 && col0<22','x[9:3]>=18 && x[9:3]<22'),
        ('col0<16','x[9:3]<16'),('col0<36','x[9:3]<36'),('col0<54','x[9:3]<54'),
        ('col0>=4','x[9:3]>=4'),('col0==24','x[9:3]==24'),('col0==27','x[9:3]==27'),
        ('col0==30','x[9:3]==30'),('col0==33','x[9:3]==33'),('col0==35','x[9:3]==35'),
        ('x0<384','x<384')]
    for i,(condition,_) in enumerate(column_regions):
        assert condition in src,condition
        src=src.replace(condition,f'text_col_select[{i}]')
    decode='reg [15:0] text_col_select;\n always @(posedge clk)begin\n'
    decode+=''.join(f'  text_col_select[{i}]<={expression};\n' for i,(_,expression) in enumerate(column_regions))+' end\n '
    src=src.replace('reg range_line_early,center_line_early;',decode+'reg range_line_early,center_line_early;')
    # The last-item flag settles during the 18 conversion clocks; avoid
    # feeding the full item comparator into counter/enable termination paths.
    src=src.replace('reg [4:0] number_item,number_bit;reg numbers_busy;',
        'reg [4:0] number_item,number_bit;reg numbers_busy;\n reg number_last;\n always @(posedge clk)number_last<=number_item==25;')
    src=src.replace('if(number_item==25)numbers_busy<=0;', 'if(number_last)numbers_busy<=0;')
    (D/'b_v2_ui_r48_renderer.v').write_text(src)
    # Anticipate the horizontal active-window comparison by one physical
    # pixel, preserving the original x counter update on every clock.
    timing=(ROOT/'fpga_b/ab_scope_v2/b_v2_timing.v').read_text()
    timing=timing.replace('reg wave_window;', 'reg wave_window;\n reg x_window;')
    timing=timing.replace('begin wave_window<=0;', 'begin x_window<=0;wave_window<=0;')
    timing=timing.replace('wave_window<=h>=383 && h<2110;', 'x_window<=h>=191 && h<2110;\n   wave_window<=h>=383 && h<2110;')
    timing=timing.replace('if(h<192 || h>=2111)', 'if(!x_window)')
    (D/'b_v2_timing.v').write_text(timing)
    # Decode the sprite bank before the 12-bank data mux, retaining its
    # original three-clock latency and every pixel/animation asset.
    sprite=(ROOT/'fpga_b/ab_scope_v2/b_v2_whale_sprite.v').read_text()
    sprite=sprite.replace('reg [3:0] bank1,bank2;', 'reg [3:0] bank1;(* preserve="true" *) reg [11:0] bank2;')
    begin=sprite.index(' always @*begin\n  case(bank2)')
    end=sprite.index(' always @(posedge clk)begin\n  bank1',begin)
    sprite=sprite[:begin]+' always @*selected='+ '|'.join("({8{bank2[%d]}} & delay%d)"%(i,i) for i in range(12))+';\n'+sprite[end:]
    sprite=sprite.replace('bank2<=bank1;', "bank2<=12'b1<<bank1;")
    # Combine bank and nibble decoding before the final data selector.
    sprite=sprite.replace('reg [11:0] bank2;', 'reg [23:0] bank2;')
    sprite=sprite.replace("bank2<=12'b1<<bank1;", "bank2<=24'b1<<({bank1,1'b0}+half1);")
    sprite=sprite.replace('palette_index<=half2?selected[7:4]:selected[3:0];',
        'palette_index<='+ '|'.join("({4{bank2[%d]}} & delay%d[%s])"%(i*2+j,i,'7:4' if j else '3:0') for i in range(12) for j in range(2))+';')
    (D/'b_v2_whale_sprite.v').write_text(sprite)
    from b_gesture_tasks_pipeline_patch import restructure
    renderer,native=restructure((D/'b_v2_ui_r48_renderer.v').read_text(),(D/'b_v2_native_trace.v').read_text())
    from b_gesture_tasks_frame_patch import patch
    renderer,native=patch(renderer,native)
    from b_gesture_tasks_minimal_text import simplify,assets
    renderer=simplify(renderer)
    assets()
    (D/'b_v2_ui_r48_renderer.v').write_text(renderer)
    (D/'b_v2_native_trace.v').write_text(native)
    print('Patched private renderer/native trace; original assets unchanged')
if __name__=='__main__':main()
