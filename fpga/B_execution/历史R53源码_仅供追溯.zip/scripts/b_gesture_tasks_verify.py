"""Offline private RTL runner. Never regenerates A or historical B inputs."""
from pathlib import Path
import argparse,hashlib,json,subprocess,time
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'fpga_b/gesture_tasks';OUT=ROOT/'artifacts/b_gesture_tasks'
BIN=ROOT.parent/'.tools/icarus/portable/app/bin'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,src,timeout=1800):
    paths=src+[f'fpga_b/gesture_tasks/{name}.sv']
    dependencies=paths+[str(p.relative_to(ROOT)).replace('\\','/') for p in D.rglob('*') if p.is_file() and p.suffix in ('.vh','.hex','.txt')]
    hashes={p:sha(ROOT/p) for p in dependencies}
    log=OUT/(name+'.log');start=time.monotonic()
    with log.open('wb') as f:
        cp=subprocess.run([str(BIN/'iverilog.exe'),'-g2012','-s',name,'-o',str(OUT/(name+'.vvp'))]+paths,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
        if cp.returncode==0:cp=subprocess.run([str(BIN/'vvp.exe'),str(OUT/(name+'.vvp'))],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    text=log.read_text(errors='replace')
    ok=cp.returncode==0 and 'PASS:' in text and 'FATAL' not in text and 'ERROR:' not in text and all(sha(ROOT/p)==v for p,v in hashes.items())
    print(name,ok,round(time.monotonic()-start,2),text[-800:],flush=True)
    return dict(name=name,passed=ok,seconds=round(time.monotonic()-start,2),input_hashes=hashes,log=str(log.relative_to(ROOT)))
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--only');ap.add_argument('--reuse',action='store_true',help='Reuse successful tests only if their complete dependency hashes still match');args=ap.parse_args()
    src=(D/'sources.txt').read_text().split()
    src=[p for p in src if not p.endswith('/pll_148m5.v')]+['fpga_b/pc_scope_1080_fine_exp/pll_integration_model.v']
    tests={
        'tb_tasks_collision':['fpga_b/gesture_tasks/b_tasks_div.v','fpga_b/gesture_tasks/b_tasks_collision.v'],
        'tb_tasks_control':['fpga_b/gesture_tasks/b_tasks_control.v'],
        'tb_tasks_scale':['fpga_b/gesture_tasks/b_tasks_scale.v'],
        'tb_tasks_top':src,
        'tb_tasks_servo':['fpga_b/rtl/legacy_scs/uart_rx_byte.v','fpga_b/rtl/legacy_scs/uart_tx_byte.v',
            'fpga_b/rtl/legacy_scs/spi_flash_byte.v','fpga_b/rtl/legacy_scs/teach_flash_store.v',
            'fpga_b/gesture_tasks/b_tasks_div.v','fpga_b/gesture_tasks/b_tasks_collision.v',
            'fpga_b/gesture_tasks/b_tasks_engine.v','fpga_b/gesture_tasks/b_tasks_servo.v','fpga_b/gesture_tasks/b_tasks_scs_model.v'],
    }
    tests['tb_tasks_collision_uart']=tests['tb_tasks_servo']
    tests['tb_tasks_history_top']=src
    tests['tb_tasks_guards']=tests['tb_tasks_collision']
    tests['tb_tasks_display']=[p for p in src if any(p.endswith('/'+n) for n in ['b_v2_timing.v','b_v2_ui_r48_font.v','b_v2_whale_sprite.v','b_v2_whale_player.v','b_v2_native_trace.v','b_v2_ui_numbers.v','b_v2_ui_r48_renderer.v'])]
    tests['tb_tasks_flash']=['fpga_b/rtl/legacy_scs/spi_flash_byte.v','fpga_b/rtl/legacy_scs/teach_flash_store.v','fpga_b/gesture_tasks/test_nor_flash.v','fpga_b/gesture_tasks/b_tasks_flash_input.v']
    tests['tb_tasks_mailbox']=['fpga_b/gesture_tasks/b_v2_mailbox.v']
    tests['tb_tasks_grid_reset']=['fpga_b/gesture_tasks/b_v2_native_trace.v']
    tests['tb_tasks_frame_mean']=tests['tb_tasks_display']
    tests['tb_tasks_mean_multicycle']=tests['tb_tasks_display']
    tests['tb_tasks_minimal_text']=tests['tb_tasks_display']
    results=[];previous={}
    if args.reuse and (OUT/'verification_all.json').exists():
        previous={t['name']:t for t in json.loads((OUT/'verification_all.json').read_text())['tests']}
    for name,paths in tests.items():
        if args.only and args.only!=name:continue
        if not (D/(name+'.sv')).exists():continue
        prior=previous.get(name)
        expected=set(paths+[f'fpga_b/gesture_tasks/{name}.sv']+[str(p.relative_to(ROOT)).replace('\\','/') for p in D.rglob('*') if p.is_file() and p.suffix in ('.vh','.hex','.txt')])
        if prior and prior['passed'] and set(prior['input_hashes'])==expected and all(sha(ROOT/p)==h for p,h in prior['input_hashes'].items()):
            print(name,'PASS: reused unchanged dependency hashes',flush=True);results.append(prior)
        else:results.append(run(name,paths))
        if not results[-1]['passed']:break
    protected=json.loads((OUT/'r48_protected.json').read_text())
    unchanged=all(sha(ROOT/p)==h for p,h in protected.items())
    report=dict(passed=bool(results) and all(r['passed'] for r in results) and unchanged,
        tests=results,r48_unchanged=unchanged,hardware='NOT_RUN')
    (OUT/('verification_'+(args.only or 'all')+'.json')).write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
