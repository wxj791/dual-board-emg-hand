"""Reuse the routed, source-identical r51 checkpoint; do not resynthesize."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'artifacts/b_gesture_tasks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    parent='r51_frame_mean_01';attempt='r51_frame_mean_signoff3'
    src=OUT/('td_'+parent);dst=OUT/('td_'+attempt)
    inputs=json.loads((OUT/(parent+'_build_inputs.json')).read_text())
    assert all(sha(ROOT/p)==h for p,h in inputs.items()),'Parent RTL/base constraints changed'
    extra='fpga_b/gesture_tasks/b_tasks_mean_multicycle.sdc';inputs[extra]=sha(ROOT/extra)
    dst.mkdir(exist_ok=False)
    for name in ['all.v','gate.v','mapped.v','gate.area','rtl.area','placed.area','placed_timing.rpt']:
        shutil.copy2(src/name,dst/name)
    recipe='scripts/b_gesture_tasks_finish_r51.tcl';shutil.copy2(ROOT/recipe,dst/'build_recipe.tcl')
    options=dict(recipe_source=recipe,recipe_sha256=sha(ROOT/recipe),parent_routed=parent,
                 extra_sdc=extra,extra_sdc_sha256=sha(ROOT/extra),physical_optimization=True)
    (OUT/(attempt+'_build_inputs.json')).write_text(json.dumps(inputs,indent=2)+'\n')
    (OUT/(attempt+'_build_options.json')).write_text(json.dumps(options,indent=2)+'\n')
    env=dict(os.environ,B_TASKS_ROOT=ROOT.as_posix(),B_TASKS_BUILD_DIR=dst.as_posix(),B_TASKS_PARENT_DB=(src/'routed.db').as_posix())
    with (OUT/('build_'+attempt+'.log')).open('w') as f:
        cp=subprocess.run(['E:/FPGA/TD_6.2.1_Engineer_168116/bin/td_commands_prompt.exe',(dst/'build_recipe.tcl').as_posix()],cwd=dst,env=env,stdout=f,stderr=subprocess.STDOUT)
    result=dict(exit_code=cp.returncode,sources_unchanged=all(sha(ROOT/p)==h for p,h in inputs.items()),bit_exists=(dst/'fpga_b_gesture_tasks_r50.bit').exists(),hardware='NOT_RUN')
    (OUT/('build_'+attempt+'_result.json')).write_text(json.dumps(result,indent=2)+'\n');print(result)
    return 0 if cp.returncode==0 and result['sources_unchanged'] and result['bit_exists'] else 1
if __name__=='__main__':raise SystemExit(main())
