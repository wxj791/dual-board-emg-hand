"""Assemble the private r49 production top; never writes old release files."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'fpga_b/gesture_tasks'
def main():
    s=(ROOT/'fpga_b/ab_scope_v2/b_v2_wave_debug_top.v').read_text()
    s=s.replace('module b_v2_wave_debug_top #(','module b_tasks_top #(')
    a=s.index(' wire [7:0] byte_data;');b=s.index(' wire command_valid,command_ready,response_valid,response_ready;',a)
    s=s[:a]+''' // Daily commands arrive over A's validated parallel 0x42 link.
 // USB UART TX remains a passive mirror; omit the optional local RX parser.
 wire fv=1'b0,pv=1'b0,pl=1'b0;wire fr,pr;wire [7:0] ft=8'd0,pd=8'd0;wire [10:0] fl=11'd0;
'''+s[b:]
    s=s.replace('parameter integer BOOT_CLKS=262144','parameter integer BOOT_CLKS=262144,SW_CLKS=480000,FLASH_RELEASE_CLKS=2400000,SERVO_TIMEOUT_CLKS=480000,SERVO_GAP_CLKS=2400')
    s=s.replace('input wire clk_24m,rst_n,host_uart_rx,output wire host_uart_tx,',
        'input wire clk_24m,rst_n,host_uart_rx,display_sw,output wire host_uart_tx,b_return_tx,')
    s=s.replace('wire sample_valid,result_valid,segment_break,result_fault,stale;',
        '''wire display_enabled;
 b_tasks_switch #(.STABLE_CLKS(SW_CLKS)) sw(.clk(clk_24m),.rst_n(ctrl_reset),.display_sw(display_sw),.initialized(ctrl_reset),.enabled(display_enabled));
 wire [31:0] fault_stamp=a_crc+a_gaps+a_timeouts+a_overflows+a_length+a_version;
 reg [31:0] old_fault_stamp;
 always @(posedge clk_24m or negedge ctrl_reset)if(!ctrl_reset)old_fault_stamp<=0;else old_fault_stamp<=fault_stamp;
 wire transport_break=fault_stamp!=old_fault_stamp;
 wire decode_fr,decode_pr;
 wire sample_valid,result_valid,segment_break,result_fault,stale;''')
    s=s.replace('.frame_valid(afv),.frame_ready(afr),\n  .frame_type(aft),.frame_length(afl),.payload_valid(apv),.payload_ready(apr),.payload_data(apd),.payload_last(apl),\n  .wave_valid',
        '.frame_valid(afv && aft!=8\'h42),.frame_ready(decode_fr),\n  .frame_type(aft),.frame_length(afl),.payload_valid(apv && !parallel_command),.payload_ready(decode_pr),.payload_data(apd),.payload_last(apl),\n  .wave_valid')
    start=s.index(' wire command_valid,command_ready,response_valid,response_ready;')
    end=s.index(' wire [2:0] page;',start)
    pc=s[start:end]
    pc=pc.replace('.frame_valid(fv),.frame_ready(fr),.frame_type(ft),.frame_length(fl),',
        '.frame_valid(cmd_fv),.frame_ready(cmd_fr),.frame_type(cmd_ft),.frame_length(cmd_fl),')
    pc=pc.replace('.payload_valid(pv),.payload_ready(pr),.payload_data(pd),.payload_last(pl),',
        '.payload_valid(cmd_pv),.payload_ready(cmd_pr),.payload_data(cmd_pd),.payload_last(cmd_pl),')
    pc=pc.replace('.response_data(response_data),','.response_data(response_data),.response_byte(response_byte),.response_byte_index(response_byte_index),')
    mux=''' // Whole-frame command arbitration; waveform decoder never sees 0x42.
 reg cmd_busy,cmd_parallel,parallel_command;
 wire cmd_fr,cmd_pr;
 wire select_parallel=!cmd_busy && afv && aft==8'h42;
 wire cmd_fv=!cmd_busy && (select_parallel || fv);
 wire [7:0] cmd_ft=select_parallel?8'h42:ft;
 wire [10:0] cmd_fl=select_parallel?afl:fl;
 wire cmd_pv=cmd_busy && (cmd_parallel?apv:pv);
 wire [7:0] cmd_pd=cmd_parallel?apd:pd;
 wire cmd_pl=cmd_parallel?apl:pl;
 assign afr=aft==8'h42 ? (!cmd_busy && cmd_fr):decode_fr;
 assign apr=parallel_command?(cmd_busy && cmd_parallel && cmd_pr):decode_pr;
 assign fr=!cmd_busy && !select_parallel && cmd_fr;
 assign pr=cmd_busy && !cmd_parallel && cmd_pr;
 always @(posedge clk_24m or negedge ctrl_reset)begin
  if(!ctrl_reset)begin cmd_busy<=0;cmd_parallel<=0;parallel_command<=0;end
  else begin
   if(afv && afr)parallel_command<=aft==8'h42;
   if(cmd_fv && cmd_fr)begin cmd_busy<=cmd_fl!=0;cmd_parallel<=select_parallel;end
   if(cmd_pv && cmd_pr && cmd_pl)cmd_busy<=0;
  end
 end
 assign b_return_tx=host_uart_tx;
'''
    s=s[:start]+mux+pc+s[end:]
    start=s.index(' wire [2:0] page;');end=s.index('\n // Classification',start)
    control=''' wire [9:0] response_byte_index;wire [7:0] response_byte;
 wire [2:0] page;wire freeze,armed,teach_mode;wire [127:0] gains,ranges;wire [7:0] custom;wire [15:0] revision;
 wire flash_init_done,flash_available,flash_load_valid,flash_save_req,flash_save_done,flash_save_ok;
 wire [3:0] flash_load_group,flash_save_group;wire [49:0] flash_load_positions,flash_save_positions;
 reg [31:0] flash_boot;
 always @(posedge clk_24m or negedge ctrl_reset)if(!ctrl_reset)flash_boot<=0;else if(flash_boot<FLASH_RELEASE_CLKS)flash_boot<=flash_boot+1'b1;
 wire flash_miso_captured;
 b_tasks_flash_input flash_capture(.clk(clk_24m),.miso(flash_miso),.captured(flash_miso_captured));
 teach_flash_store flash_store(.clk(clk_24m),.rst_n(ctrl_reset && flash_boot>=FLASH_RELEASE_CLKS),
  .save_req(flash_save_req),.save_group(flash_save_group),.save_positions(flash_save_positions),
  .init_done(flash_init_done),.available(flash_available),.load_valid(flash_load_valid),.load_group(flash_load_group),
  .load_positions(flash_load_positions),.save_done(flash_save_done),.save_ok(flash_save_ok),
  .flash_cs_n(flash_cs_n),.flash_clk(flash_clk),.flash_mosi(flash_mosi),.flash_miso(flash_miso_captured));
 // uart_rx_byte inside the shared engine owns the two-flop RX synchronizer.
 wire scs_sync=scs_rx;
 wire req_valid,req_ready,event_valid,event_ready,servo_idle;wire [2:0] req_op;
 wire [15:0] req_id,req_arg,event_id,event_status;wire [3:0] query_pose;wire query_valid;wire [49:0] query_positions;
 wire [4:0] online,torque,torque_valid_mask,active_mask,retired_mask,feedback_valid_mask;wire [79:0] positions,speeds,loads,feedback_age_ms;wire [8:0] pose_valid;
 wire [7:0] motion_state;wire [31:0] fault_flags,auto_count,auto_rejects;wire servo_data,servo_enable;
 b_tasks_servo #(.TIMEOUT_CLKS(SERVO_TIMEOUT_CLKS),.GAP_CLKS(SERVO_GAP_CLKS)) servo_controller(
  .clk(clk_24m),.rst_n(ctrl_reset),.servo_rx(scs_sync),.servo_tx(servo_data),.servo_tx_enable(servo_enable),
  .req_valid(req_valid),.req_ready(req_ready),.req_op(req_op),.req_id(req_id),.req_arg(req_arg),
  .event_valid(event_valid),.event_ready(event_ready),.event_id(event_id),.event_status(event_status),.idle(servo_idle),
  .query_pose(query_pose),.query_valid(query_valid),.query_positions(query_positions),
  .flash_init_done(flash_init_done),.flash_available(flash_available),.flash_load_valid(flash_load_valid),
  .flash_load_group(flash_load_group),.flash_load_positions(flash_load_positions),.flash_save_req(flash_save_req),
  .flash_save_group(flash_save_group),.flash_save_positions(flash_save_positions),.flash_save_done(flash_save_done),.flash_save_ok(flash_save_ok),
  .online(online),.torque(torque),.torque_valid_mask(torque_valid_mask),.positions(positions),.speeds(speeds),.loads(loads),.feedback_age_ms(feedback_age_ms),.feedback_valid_mask(feedback_valid_mask),.pose_valid(pose_valid),
  .motion_state(motion_state),.active_mask(active_mask),.retired_mask(retired_mask),.fault_flags(fault_flags));
 assign scs_tx=servo_enable?servo_data:1'b1;
 b_tasks_control control(.clk(clk_24m),.rst_n(ctrl_reset),.display_enabled(display_enabled),
  .command_valid(command_valid),.command_ready(command_ready),.request_id(request_id),.opcode(opcode),.data_length(data_length),.arguments(arguments),
  .response_valid(response_valid),.response_ready(response_ready),.response_type(response_type),.response_id(response_id),.response_opcode(response_opcode),
  .response_status(response_status),.response_length(response_length),.response_data(response_data),.response_byte(response_byte),.response_byte_index(response_byte_index),
  .result_valid(result_valid),.wave_valid(sample_valid),.link_fault(transport_break || result_fault || heartbeat_timeout),.stale(stale),
  .generation(generation),.epoch(epoch),.class_id(class_id),.class_count(class_count),.result_flags(result_flags),.window_seq(window_seq),
  .online(online),.torque(torque),.pose_valid(pose_valid),.servo_idle(servo_idle),.flash_ready(flash_available && flash_init_done),
  .flash_available(flash_available),.flash_initialized(flash_init_done),.positions(positions),.speeds(speeds),.loads(loads),.feedback_age_ms(feedback_age_ms),.feedback_valid_mask(feedback_valid_mask),.torque_valid_mask(torque_valid_mask),
  .motion_state(motion_state),.active_mask(active_mask),.retired_mask(retired_mask),.fault_flags(fault_flags),
  .req_valid(req_valid),.req_ready(req_ready),.req_op(req_op),.req_id(req_id),.req_arg(req_arg),
  .event_valid(event_valid),.event_ready(event_ready),.event_id(event_id),.event_status(event_status),
  .query_pose(query_pose),.query_valid(query_valid),.query_positions(query_positions),
  .page(page),.freeze(freeze),.armed(armed),.teach_mode(teach_mode),.ranges(ranges),.gains(gains),.custom(custom),.revision(revision),
  .auto_count(auto_count),.auto_rejects(auto_rejects));
'''
    s=s[:start]+control+s[end:]
    s=s.replace('wire history_break=segment_break;', 'wire history_break=segment_break || transport_break;')
    s=s.replace('b_v2_scale scale(', 'b_tasks_scale scale(').replace('.page(page),.gains(gains),.revision(revision),',
        '.page(page),.gains(gains),.ranges(ranges),.custom(custom),.revision(revision),')
    s=s.replace('reg [223:0] display_meta;wire [223:0] pix_meta;', 'reg [679:0] display_meta;wire [679:0] pix_meta;')
    s=s.replace('always @* display_meta={42\'d0,gains,saturated,stale,freeze,page,generation,sample_rate,revision};',
        '''wire [319:0] servo_snapshot={26'd0,torque_valid_mask,armed,motion_state,pose_valid,feedback_valid_mask,torque,online,loads,speeds,positions,16'd0};
 always @* display_meta={servo_snapshot,custom,ranges,42'd0,gains,saturated,stale,freeze,page,generation,sample_rate,revision};''')
    s=s.replace('#(.WIDTH(224))','#(.WIDTH(680))')
    a=s.index(' reg [144:0] fifo_capture;');b=s.index(' wire [15:0] pix_revision=',a)
    s=s[:a]+''' reg [144:0] fifo_capture;reg capture_valid;
 always @(posedge clk_pix)fifo_capture<=fifo_data[144:0];
 always @(posedge clk_pix or negedge pix_reset)if(!pix_reset)capture_valid<=0;else capture_valid<=!fifo_empty;
 reg [3:0] revision_match;reg capture_valid2,capture_clear2;reg [127:0] capture_data2;
 genvar meta_part;
 generate for(meta_part=0;meta_part<4;meta_part=meta_part+1)begin:compare_revision
  always @(posedge clk_pix)revision_match[meta_part]<=fifo_capture[129+meta_part*4+:4]==pix_meta[meta_part*4+:4];
 end endgenerate
 always @(posedge clk_pix)begin capture_data2<=fifo_capture[127:0];capture_clear2<=fifo_capture[128];end
 always @(posedge clk_pix or negedge pix_reset)if(!pix_reset)capture_valid2<=0;else capture_valid2<=capture_valid;
 reg [127:0] pix_data;reg pix_valid,pix_clear;reg [15:0] last_revision;
 always @(posedge clk_pix)pix_data<=capture_data2;
 always @(posedge clk_pix or negedge pix_reset)begin
  if(!pix_reset)begin pix_valid<=0;pix_clear<=0;last_revision<=0;end
  else begin
   pix_valid<=0;pix_clear<=0;last_revision<=pix_meta[15:0];
   if(last_revision!=pix_meta[15:0])pix_clear<=1;
   else if(capture_valid2 && &revision_match && !pix_meta[51])begin
    pix_clear<=capture_clear2;pix_valid<=!capture_clear2;
   end
  end
 end
'''+s[b:]
    s=s.replace('.channel_gains(pix_gains),.gain(pix_gains[15:0]),',
        '.channel_gains(pix_gains),.ranges(pix_meta[351:224]),.custom(pix_meta[359:352]),.gain(pix_gains[15:0]),')
    s=s.replace('.armed(1\'b0)', '.armed(pix_meta[648])').replace('.servo_snapshot(320\'d0)', '.servo_snapshot(pix_meta[679:360])')
    a=s.index(' assign scs_tx=1\'b1;');b=s.index('\nendmodule',a)
    s=s[:a]+" assign status_led_n=~{(|fault_flags),locked,(|online),display_enabled};"+s[b:]
    (D/'b_tasks_top.v').write_text(s)
    pc=(ROOT/'fpga_b/ab_scope_v2/b_v2_pc.v').read_text()
    pc=pc.replace("if(kind==8'h50 && length>=8", "if((kind==8'h50 || kind==8'h42) && length>=8")
    # Reject oversize requests before truncation can masquerade as a short command.
    pc=pc.replace('length>=8 && index==length','length>=8 && length<=18 && index==length')
    pc=pc.replace('input wire [9:0] response_length,input wire [4095:0] response_data,',
        'input wire [9:0] response_length,input wire [4095:0] response_data,input wire [7:0] response_byte,output wire [9:0] response_byte_index,')
    pc=pc.replace('reg sending,buffering;','reg sending,buffering,copy_phase;\n assign response_byte_index=copy_index;')
    pc=pc.replace('if(buffering && copy_index<len_hold)','if(buffering && copy_phase && copy_index<len_hold)')
    pc=pc.replace("op_hold==16'h02f2 ? (copy_index[7:0]^response_data[7:0]) : response_data[copy_index*8+:8]",'response_byte')
    pc=pc.replace('sending<=0;buffering<=0;copy_index<=0;', 'sending<=0;buffering<=0;copy_phase<=0;copy_index<=0;')
    pc=pc.replace('buffering<=1;copy_index<=0;', 'buffering<=1;copy_phase<=0;copy_index<=0;')
    pc=pc.replace('if(buffering)begin','if(buffering)begin\n    copy_phase<=!copy_phase;')
    pc=pc.replace('else copy_index<=copy_index+1\'b1;', 'else if(copy_phase)copy_index<=copy_index+1\'b1;')
    (D/'b_v2_pc.v').write_text(pc)
    src=(D/'sources.txt').read_text().split()
    src=[p for p in src if not p.endswith(('/b_v2_scale.v','/b_v2_wave_debug_control.v','/b_v2_wave_debug_top.v'))]
    src+=['fpga_b/rtl/legacy_scs/uart_rx_byte.v','fpga_b/rtl/legacy_scs/spi_flash_byte.v','fpga_b/rtl/legacy_scs/teach_flash_store.v','fpga_b/gesture_tasks/b_tasks_flash_input.v']
    src+=['fpga_b/gesture_tasks/'+n for n in ['b_tasks_switch.v','b_tasks_scale.v','b_tasks_div.v','b_tasks_collision.v','b_tasks_engine.v','b_tasks_servo.v','b_tasks_control.v','b_tasks_top.v']]
    (D/'sources.txt').write_text('\n'.join(dict.fromkeys(src))+'\n')
    print('Generated independent production top')
if __name__=='__main__':main()
