"""Freeze byte-exact vectors from the shared contract, locally owned outputs."""
from pathlib import Path
import struct,binascii,json
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'artifacts/b_gesture_tasks'
def frame(kind,p,seq=0):
    b=struct.pack('<BBHHI',1,kind,seq,len(p),0)+p
    return b'\xa5\x5a'+b+struct.pack('<H',binascii.crc_hqx(b,65535))
def request(id,op,data=b'',seq=0):return frame(0x42,struct.pack('<BBHHH',1,2,id,op,len(data))+data,seq)
def main():
    vectors=[request(1,1,seq=0),request(2,0x0204,struct.pack('<BBH',1,255,50),seq=1),
        request(3,0x0200,b'\x01',seq=2),request(4,0x0604,seq=3),
        request(5,0x030a,b'\x08\x00',seq=4),request(6,0x0002,seq=5),
        request(7,0x0002,b'\x02',seq=6)]
    (OUT/'command_vectors.json').write_text(json.dumps([x.hex() for x in vectors],indent=2)+'\n')
    (OUT/'command_vectors.hex').write_text(''.join(f'{b:02x}\n' for v in vectors for b in v))
    (ROOT/'fpga_b/gesture_tasks/vector_constants.vh').write_text(f'localparam integer VECTOR_BYTES={sum(map(len,vectors))},VECTOR_FRAMES={len(vectors)};\n')
    (ROOT/'fpga_b/gesture_tasks/vector_lengths.vh').write_text(
        '\n'.join(f'lengths[{i}]={len(v)};' for i,v in enumerate(vectors))+'\n')
    print('Wrote',sum(map(len,vectors)),'bytes of target2 0x42 requests')
if __name__=='__main__':main()
