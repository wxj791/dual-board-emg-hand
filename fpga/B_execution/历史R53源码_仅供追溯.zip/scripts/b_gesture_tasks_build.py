"""Serialize independent B EDA with other endpoints; never connects hardware."""
from pathlib import Path
import subprocess,time,json,hashlib,datetime,argparse,os,shutil,re
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'artifacts/b_gesture_tasks';D=ROOT/'fpga_b/gesture_tasks'
TD=Path('E:/FPGA/TD_6.2.1_Engineer_168116/bin/td_commands_prompt.exe')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--attempt',required=True)
    resume_group=parser.add_mutually_exclusive_group()
    resume_group.add_argument('--resume-mapped')
    resume_group.add_argument('--resume-routed',help='Refresh STA and physically repair hold from a matching routed checkpoint, without resynthesis')
    parser.add_argument('--pack-mode',choices=['auto','more_lut_pair','adaptive_pin_density','lower_pin_density'],default='auto')
    parser.add_argument('--pr-strategy',type=int,default=1)
    parser.add_argument('--seed',type=int,default=0)
    parser.add_argument('--route-effort',choices=['normal','high','routability'],default='normal',
        help='TD User Guide 6.2 section 9.6: routability enables the congestion avoidance algorithm')
    parser.add_argument('--share-eda',action='store_true',help='Allow isolated concurrent EDA only with measured CPU/memory headroom')
    parser.add_argument('--congestion',choices=['default','medium'],default='default');args=parser.parse_args()
    assert args.attempt.replace('_','').isalnum()
    target=OUT/('td_'+args.attempt)
    if target.exists():raise SystemExit('Refusing to overwrite r50 build; use a new revision directory')
    # Only inspect process names/commands to avoid competing EDA jobs.
    query="Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'td_commands_prompt.exe'} | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"
    last='';resource_snapshot=None
    while True:
        state=subprocess.check_output(['powershell','-NoProfile','-Command',query],text=True,encoding='utf-8').strip()
        if not state:break
        if args.share_eda:
            resource_query="$o=Get-CimInstance Win32_OperatingSystem; $c=Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter \"Name='_Total'\"; @{free_kib=$o.FreePhysicalMemory;cpu_percent=$c.PercentProcessorTime} | ConvertTo-Json -Compress"
            resource_snapshot=json.loads(subprocess.check_output(['powershell','-NoProfile','-Command',resource_query],text=True,encoding='utf-8'))
            if resource_snapshot['free_kib']>=4*1024*1024 and resource_snapshot['cpu_percent']<40:
                print('Isolated EDA with measured headroom:',resource_snapshot,flush=True);break
        if state!=last:print('Waiting for other EDA:',state,flush=True);last=state
        time.sleep(10)
    paths=[ROOT/p for p in (D/'sources.txt').read_text().split()]
    paths += [ROOT/name for p in list(paths) for name in re.findall(r'\$readmemh\("([^"]+)"',p.read_text())]
    paths+=list(D.rglob('*.vh'))+list(D.rglob('*.hex'))+[D/'sources.txt',D/'b_tasks.adc',D/'b_tasks.sdc']
    paths+=[D/'b_tasks_mean_multicycle.sdc']
    manifest={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in paths}
    resume=None
    resume_attempt=args.resume_mapped or args.resume_routed
    if resume_attempt:
        resume=OUT/('td_'+resume_attempt)
        assert manifest==json.loads((OUT/(resume_attempt+'_build_inputs.json')).read_text()),'Checkpoint source mismatch'
        target.mkdir()
        names=['all.v','mapped.v','mapped.db','gate.area']
        if args.resume_routed:names=['all.v','mapped.v','gate.v','gate.area','rtl.area','placed.area','placed_timing.rpt','routed.db']
        for name in names:
            shutil.copy2(resume/name,target/name)
    (OUT/(args.attempt+'_build_inputs.json')).write_text(json.dumps(manifest,indent=2)+'\n')
    print('Starting isolated B r50 EDA',datetime.datetime.now().isoformat(),flush=True)
    target.mkdir(exist_ok=True)
    recipe='scripts/b_gesture_tasks_finish_r50.tcl' if args.resume_routed else 'scripts/b_gesture_tasks_build_r50.tcl'
    shutil.copy2(ROOT/recipe,target/'build_recipe.tcl')
    env=dict(os.environ,B_TASKS_BUILD_DIR=target.as_posix(),B_TASKS_PACK_MODE=args.pack_mode,B_TASKS_PR_STRATEGY=str(args.pr_strategy),B_TASKS_SEED=str(args.seed),B_TASKS_CONGESTION=args.congestion,B_TASKS_ROUTE_EFFORT=args.route_effort)
    if args.resume_mapped:env['B_TASKS_RESUME_MAPPED']=(resume/'mapped.db').as_posix()
    (OUT/(args.attempt+'_build_options.json')).write_text(json.dumps(dict(resume_mapped=args.resume_mapped,resume_routed=args.resume_routed,pack_mode=args.pack_mode,pr_strategy=args.pr_strategy,seed=args.seed,congestion=args.congestion,route_effort=args.route_effort,resource_snapshot=resource_snapshot,tool=TD.as_posix(),recipe_source=recipe,recipe_sha256=sha(ROOT/recipe)),indent=2)+'\n')
    with (OUT/('build_'+args.attempt+'.log')).open('wb') as stream:
        cp=subprocess.run([TD.as_posix(),(target/'build_recipe.tcl').as_posix()],cwd=target,stdout=stream,stderr=subprocess.STDOUT,env=dict(env,B_TASKS_ROOT=ROOT.as_posix()))
    unchanged=all(sha(ROOT/p)==h for p,h in manifest.items())
    report=dict(exit_code=cp.returncode,sources_unchanged=unchanged,bit_exists=(target/'fpga_b_gesture_tasks_r50.bit').exists(),hardware='NOT_RUN')
    (OUT/('build_'+args.attempt+'_result.json')).write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
    return 0 if cp.returncode==0 and unchanged and report['bit_exists'] else 1
if __name__=='__main__':raise SystemExit(main())
