"""Freeze exact Python model/endpoints/config bytes into B-private ROMs."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'fpga_b/gesture_tasks';OUT=ROOT/'artifacts/b_gesture_tasks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    C=ROOT/'collision_detection';bank=json.loads((C/'models/percent_v5/rate_100.json').read_text())
    ranges=json.loads((C/'queue_motion_range.json').read_text());lower=json.loads((C/'user_lower_pose.json').read_text())
    sensitivity=json.loads((C/'sensitivity.json').read_text());profiles=json.loads((C/'models/queue_full_current/queue_profiles.json').read_text())
    assert bank['range_sha256']==sha(C/'queue_motion_range.json')
    assert bank['trajectory']=='shared-percent-feedback-v5' and bank['percent_per_second']==100
    run=Path(bank['source_run']);configs={}
    for line in (run/'wire.jsonl').read_text().splitlines():
        r=json.loads(line)
        if r['instruction']==2 and r['params']==[0,49] and r['id'] not in configs:
            configs[r['id']]=bytes.fromhex(r['rx'])[5:-1]
    rom=[0]*512;params=[]
    for i in range(1,6):
        config=configs[i];assert len(config)==49
        if i==2:
            params.append(dict(id=i,config=config.hex()));continue
        model=bank['servos'][str(i)]
        assert hashlib.sha256(config[:40]).hexdigest()==model['configuration_sha256']
        assert bank['command_speeds'][str(i)]==220
        lo=ranges.get('lower_positions',{}).get(str(i),lower['positions'][str(i)]['position'])
        hi=ranges['upper_positions'][str(i)]
        bounds=[max(20,min(lo,hi,lower['positions'][str(i)]['observed_min'])-12),
                min(1023,max(lo,hi,lower['positions'][str(i)]['observed_max'])+12)]
        for direction in (-1,1):
            channel=model['channels'][f'{i}:{direction}:220']
            for bucket,cell in channel['bins'].items():
                assert cell['independent_passes']>=3 and int(cell['upper'])==cell['upper']
                addr=(i-1)*64+(32 if direction==1 else 0)+int(bucket)
                # bit20 coverage, startup10, normal10: integer source has zero quantization.
                rom[addr]=(1<<20)|(channel['startup_upper']<<10)|cell['upper']
        params.append(dict(id=i,lower=lo,upper=hi,bounds=bounds,observed=model['position_range'],
            hard=profiles[str(i)]['hard_load'],startup_hard=profiles[str(i)].get('startup_hard_load',profiles[str(i)]['hard_load']),
            startup_stall_ms=round(profiles[str(i)].get('startup_stall_seconds',.35)*1000),
            **sensitivity[str(i)],config=config.hex()))
    (D/'assets/collision_model.hex').write_text(''.join(f'{v:06x}\n' for v in rom))
    functions=[]
    for name,default,values,width in [
        ('upper',0,{p['id']:p.get('upper',0) for p in params},10),
        ('lower',0,{p['id']:p.get('lower',0) for p in params},10),
        ('bound_low',20,{p['id']:p.get('bounds',[20,1023])[0] for p in params},10),
        ('bound_high',1023,{p['id']:p.get('bounds',[20,1023])[1] for p in params},10),
        ('observed_low',0,{p['id']:p.get('observed',[0,0])[0] for p in params},10),
        ('observed_high',0,{p['id']:p.get('observed',[0,0])[1] for p in params},10),
        ('hard_load',300,{p['id']:p.get('hard',300) for p in params},10),
        ('startup_hard',300,{p['id']:p.get('startup_hard',300) for p in params},10),
        ('startup_stall',350,{p['id']:p.get('startup_stall_ms',350) for p in params},10),
        ('load_margin',30,{p['id']:p.get('load_margin',30) for p in params},10),
        ('hold_ms',60,{p['id']:p.get('hold_ms',60) for p in params},10),
        ('expected_config',0,{p['id']:int.from_bytes(bytes.fromhex(p['config'])[:40],'little') for p in params},320),
    ]:
        functions.append(f'function [{width-1}:0] {name};input [2:0] lane;begin case(lane)')
        functions.extend(f"3'd{i-1}:{name}={width}'h{v:x};" for i,v in values.items())
        functions.append(f"default:{name}={width}'d{default};endcase end endfunction")
    (D/'collision_params.vh').write_text('\n'.join(functions)+'\n')
    inputs=[C/'together_run.py',C/'guard.py',C/'load_model.py',C/'percent_model.py',C/'sensitivity.json',
            C/'models/percent_v5/rate_100.json',C/'queue_motion_range.json',C/'user_lower_pose.json',
            C/'models/queue_full_current/queue_profiles.json',run/'wire.jsonl']
    report=dict(trajectory=bank['trajectory'],rate=100,params=params,input_sha256={str(p.relative_to(ROOT)):sha(p) for p in inputs},
        model_quantization_error=0,configuration_comparison='exact first40 EEPROM bytes + lock48=1',hardware='NOT_RUN')
    (OUT/'collision_assets.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Frozen exact model, endpoints, sensitivity, five EEPROM identities')
if __name__=='__main__':main()
