"""Private display-only simplification; leave native trace and raster untouched."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'fpga_b/gesture_tasks'

def simplify(src):
    start=src.index(' reg [25:0] number_write;')
    end=src.index(' function [6:0] hexchar;', start)
    numbers=src[start:end]
    numbers=numbers[:numbers.index(' wire [19:0] rate_bcd;')]
    numbers=numbers.replace('[25:0]', '[12:0]')
    numbers=numbers.replace('number_result_range,number_result_center,number_result_position,number_result_load', 'number_result_center,number_result_position')
    numbers=numbers.replace('reg [127:0] ranges_bcd,centers_bcd;', 'reg [127:0] centers_bcd;\n wire [127:0] ranges_bcd;')
    numbers=numbers.replace('positions_bcd,loads_bcd', 'positions_bcd')
    numbers=numbers.replace('   number_selected=number_selected | ({16{number_slot[number_source]}} & ranges[number_source*16+:16]);\n', '')
    numbers=numbers.replace('number_slot[8+number_source]', 'number_slot[number_source]')
    numbers=numbers.replace('number_slot[16+number_source]', 'number_slot[8+number_source]')
    numbers=numbers.replace("   number_selected=number_selected | ({16{number_slot[21+number_source]}} & (servo_snapshot[176+number_source*16+:16] & 16'h03ff));\n", '')
    numbers=numbers.replace('number_result_range<=0;', '').replace('number_result_load<=0;', '')
    numbers=numbers.replace('number_result_range<=number_shift[31:16];', '').replace('number_result_load<=number_shift[31:16];', '')
    numbers=numbers.replace('<26', '<13').replace('[24:0]', '[11:0]').replace('number_slot[25]', 'number_slot[12]')
    g=numbers.index(' generate for(bcd_item=0;')
    numbers=numbers[:g]+''' generate for(bcd_item=0;bcd_item<13;bcd_item=bcd_item+1)begin:bcd_destination
  if(bcd_item<8)begin
   always @(posedge clk or negedge rst_n)if(!rst_n)centers_bcd[bcd_item*16+:16]<=0;else if(number_write[bcd_item])centers_bcd[bcd_item*16+:16]<=number_result_center;
  end else begin
   always @(posedge clk or negedge rst_n)if(!rst_n)positions_bcd[(bcd_item-8)*16+:16]<=0;else if(number_write[bcd_item])positions_bcd[(bcd_item-8)*16+:16]<=number_result_position;
  end
 end endgenerate
 // Seven legal ranges have fixed decimal digits; no runtime conversion.
 function [15:0] range_decimal;input [15:0] mv;begin case(mv)
  20:range_decimal=16'h0020;50:range_decimal=16'h0050;
  100:range_decimal=16'h0100;200:range_decimal=16'h0200;
  500:range_decimal=16'h0500;1200:range_decimal=16'h1200;
  3300:range_decimal=16'h3300;default:range_decimal=16'hffff;
 endcase end endfunction
 generate for(bcd_item=0;bcd_item<8;bcd_item=bcd_item+1)begin:range_lookup
  assign ranges_bcd[bcd_item*16+:16]=range_decimal(ranges[bcd_item*16+:16]);
 end endgenerate
'''
    src=src[:start]+numbers+src[end:]
    start=src.index(' reg [15:0] text_col_select;')
    end=src.index(' wire [2:0] font_row=', start)
    text=''' // Prepare only range, RAW mean and finger position digits.
 reg [31:0] range_digits,center_digits;reg [19:0] position_digits;
 integer digit_lane;
 wire [2:0] servo_row_input=y[6:4],servo_row=y0[6:4];
 reg servo_online0,servo_torque0,servo_feedback0,servo_torque_valid0;
 reg custom0;
 always @(posedge clk)begin
  channel_early<=lane_id(y);lane_early<=lane_offset(y);
  custom0<=custom[lane_id(y)];
  for(digit_lane=0;digit_lane<8;digit_lane=digit_lane+1)begin
   range_digits[digit_lane*4+:4]<=ranges_bcd[digit_lane*16+{~x[4:3],2'b00}+:4];
   center_digits[digit_lane*4+:4]<=centers_bcd[digit_lane*16+{~x[4:3],2'b00}+:4];
  end
  for(digit_lane=0;digit_lane<5;digit_lane=digit_lane+1)
   position_digits[digit_lane*4+:4]<=positions_bcd[digit_lane*16+{~x[4:3],2'b00}+:4];
  servo_online0<=servo_snapshot[256+servo_row_input];
  servo_torque0<=servo_snapshot[261+servo_row_input];
  servo_feedback0<=servo_snapshot[266+servo_row_input];
  servo_torque_valid0<=servo_snapshot[289+servo_row_input];
 end
 reg [4:0] text_region;
 reg [5:0] text_column;
 always @(posedge clk)begin
  text_region[0]<=y<16;
  text_region[1]<=y>=16 && y<32;
  text_region[2]<=y>=48 && y<368 && lane_offset(y)<16 && x<64;
  text_region[3]<=y>=48 && y<368 && lane_offset(y)>=16 && lane_offset(y)<32 && x<64;
  text_region[4]<=y>=384 && y<464 && x<384;
  text_column[0]<=x[9:3]==1;
  text_column[1]<=x[9:3]>=4 && x[9:3]<8;
  text_column[2]<=x[9:3]==2;
  text_column[3]<=x[9:3]>=8 && x[9:3]<12;
  text_column[4]<=x[9:3]==17;
  text_column[5]<=x[9:3]==23;
 end
 reg [2:0] template_id,template_id_early;
 reg text_enabled,text_enabled_early,text_enabled2;
 reg [23:0] text_colour,text_colour_early;
 reg dynamic_valid,dynamic_valid_early;
 reg [6:0] dynamic_terms[0:5];
 wire [6:0] dynamic_character=dynamic_terms[0]|dynamic_terms[1]|dynamic_terms[2]|dynamic_terms[3]|dynamic_terms[4]|dynamic_terms[5];
 wire range_active=text_region[2] && text_column[1];
 wire center_active=text_region[3] && page==0 && text_column[1];
 wire position_active=text_region[4] && text_column[3];
 wire channel_active=text_region[2] && text_column[0];
 wire finger_active=text_region[4] && text_column[2];
 wire status_active=text_region[1] && (col0==5 || col0==14 || col0==23 || col0==30);
 wire finger_flags=text_region[4] && (text_column[4] || text_column[5]);
 wire [3:0] range_nibble=range_digits[channel_early*4+:4];
 wire [6:0] custom_character=col0==4?7'd67:col0==5?7'd85:col0==6?7'd83:7'd84;
 wire [6:0] range_character=custom0?custom_character:hexchar(range_nibble);
 wire [6:0] center_character=hexchar(center_digits[channel_early*4+:4]);
 wire [6:0] position_character=servo_feedback0?hexchar(position_digits[servo_row*4+:4]):7'd63;
 reg [6:0] status_character;
 always @*begin
  status_character=7'd48;
  case(col0)
   5:status_character=freeze?7'd49:7'd48;
   14:status_character=(!link_stale && flow_active)?7'd49:7'd48;
   23:status_character=(saturated || native_clip)?7'd49:7'd48;
   30:status_character=armed?7'd49:7'd48;
  endcase
 end
 wire [6:0] finger_character=text_column[4]?(servo_online0?7'd49:7'd48):
  !servo_torque_valid0?7'd63:servo_torque0?7'd49:7'd48;
 always @*begin
  template_id_early=({3{text_region[0]}} & page[1:0]) |
   ({3{text_region[1]}} & 3'd4) | ({3{text_region[2]}} & 3'd5) |
   ({3{text_region[3]}} & 3'd6) | ({3{text_region[4]}} & 3'd7);
  text_enabled_early=text_region[0] || text_region[1] || text_region[2] ||
   (text_region[3] && page==0) || text_region[4];
  text_colour_early=text_region[2]?24'h65d9ef:24'h9cacc6;
  dynamic_valid_early=range_active || center_active || position_active || channel_active || finger_active || status_active || finger_flags;
 end
 always @(posedge clk)begin
  template_id<=template_id_early;text_enabled<=text_enabled_early;
  text_colour<=text_colour_early;dynamic_valid<=dynamic_valid_early;
  dynamic_terms[0]<=range_active?range_character:7'd0;
  dynamic_terms[1]<=center_active?center_character:7'd0;
  dynamic_terms[2]<=position_active?position_character:7'd0;
  dynamic_terms[3]<=channel_active?(7'd48+channel_early):finger_active?(7'd49+servo_row):7'd0;
  dynamic_terms[4]<=status_active?status_character:7'd0;
  dynamic_terms[5]<=finger_flags?finger_character:7'd0;
 end
 (* ram_style="block" *) reg [6:0] text_rows[0:1023];
 initial $readmemh("fpga_b/gesture_tasks/assets/text_rows_minimal.hex",text_rows);
'''
    src=src[:start]+text+src[end:]
    src=src.replace('reg [3:0] nibble2;', 'reg [6:0] dynamic_character2;')
    src=src.replace('dynamic_space2<=dynamic_space;nibble2<=dynamic_nibble;', 'text_enabled2<=text_enabled;dynamic_character2<=dynamic_character;')
    src=src.replace("dynamic_valid2?(dynamic_space2?7'd32:hexchar(nibble2)):static_character2", "!text_enabled2?7'd32:dynamic_valid2?dynamic_character2:static_character2")
    return src

def assets():
    rows=[
        'RAW  ADC mV   RANGE +/- mV   AVG = VISIBLE 512 SAMPLES',
        'FILTER  ADC mV   RANGE +/- mV   CENTER = 0',
        'FAST ENVELOPE  ADC mV   RANGE 0..mV',
        'SLOW ENVELOPE  ADC mV   RANGE 0..mV',
        'HOLD 0  LINK  0  CLIP  0  ARM 0',
        'C0  1200',
        'AVG 1590',
        'ID1 POS 0476  ON 1  TQ 1',
    ]
    assert rows[4][5]=='0' and rows[4][14]=='0' and rows[4][23]=='0' and rows[4][30]=='0'
    assert rows[7][17]=='1' and rows[7][23]=='1'
    (D/'assets/text_rows_minimal.hex').write_text(''.join(f'{ord(c):02x}\n' for r in rows for c in r.ljust(128)))

def main():
    p=D/'b_v2_ui_r48_renderer.v'
    assets()
    p.write_text(simplify(p.read_text()))

if __name__=='__main__':main()
