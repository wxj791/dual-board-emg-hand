set root [file normalize [file join [file dirname [info script]] ..]]
report_param -all -detail -file [file join $root artifacts b_gesture_tasks tool_parameters.txt]
exit
