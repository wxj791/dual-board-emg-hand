"""Exhaustive raster selector and scheduled decimal equivalence, offline only."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'fpga_b/gesture_tasks'
OUT=ROOT/'artifacts/b_gesture_tasks/pipeline_candidate'
BIN=ROOT.parent/'.tools/icarus/portable/app/bin'

def main():
    ref=(OUT/'reference_renderer.v').read_text()
    new=(OUT/'b_v2_ui_r48_renderer.v').read_text()
    modules=[]
    for name,body in [('reference',ref),('candidate',new)]:
        functions=body[body.index(' function [2:0] lane_id'):body.index(' wire [6:0] col0=')]
        decode=body[body.index('reg [15:0] text_col_select;'):body.index(' always @(posedge clk)begin channel_early')]
        if name=='reference':
            start=body.index(' always @*begin\n  template_id_early=31;')
        else:start=body.index(' reg [10:0] text_region;')
        logic=body[start:body.index(' always @(posedge clk)begin\n  template_id<=',start)]
        modules.append('''module text_'''+name+'''(input clk,input [9:0] x,input [8:0] y,
 input [1:0] page,input [7:0] custom,input [319:0] servo_snapshot,
 input flow_active,freeze,wave_valid,wave_seen,saturated,native_clip,armed,
 output reg [4:0] template_id_early,output reg [23:0] text_colour_early,
 output reg dynamic_valid_early,output reg [3:0] dynamic_nibble_early);
 reg [9:0] x0;reg [8:0] y0;reg [2:0] channel_early;
 always @(posedge clk)begin x0<=x;y0<=y;channel_early<=lane_id(y);end
 wire [6:0] col0=x0[9:3];wire [2:0] servo_row=y0[6:4],servo_row_input=y[6:4];
 wire [3:0] rate_n0=1,fill_n0=2,count_n0=3,gain_n0=4,center_n0=5,position_n0=6,speed_n0=7,load_n0=8;
 reg [3:0] dynamic_terms[1:13];
'''+functions+decode+logic+'\nendmodule\n')
        start=body.index(' reg [25:0] number_write;')
        end=body.index(' wire [19:0] rate_bcd;',start)
        number=body[start:end]
        modules.append('''module decimal_'''+name+'''(input clk,rst_n,number_update,
 input [127:0] ranges,centers,input [319:0] servo_snapshot,
 output wire [415:0] result,output wire busy);
 assign result={loads_bcd,positions_bcd,centers_bcd,ranges_bcd};assign busy=numbers_busy;
'''+number+'\nendmodule\n')
    bench='''`timescale 1ns/1ps
module tb_pipeline_equivalence;
 reg clk=0;always #5 clk=~clk;
 reg [9:0] x=0;reg [8:0] y=0;reg [1:0] page=0;
 reg [7:0] custom=0;reg [319:0] servo_snapshot=0;
 reg [6:0] flags=0;
 wire [4:0] tr,tn;wire [23:0] cr,cn;wire vr,vn;wire [3:0] dr,dn;
 text_reference r(clk,x,y,page,custom,servo_snapshot,flags[0],flags[1],flags[2],flags[3],flags[4],flags[5],flags[6],tr,cr,vr,dr);
 text_candidate n(clk,x,y,page,custom,servo_snapshot,flags[0],flags[1],flags[2],flags[3],flags[4],flags[5],flags[6],tn,cn,vn,dn);
 reg rst_n=0,update=0;reg [127:0] ranges=0,centers=0;
 wire [415:0] br,bn;wire busy_r,busy_n;
 decimal_reference nr(clk,rst_n,update,ranges,centers,servo_snapshot,br,busy_r);
 decimal_candidate nn(clk,rst_n,update,ranges,centers,servo_snapshot,bn,busy_n);
 integer xx,yy,scene,k,trial,compared=0;
 initial begin
  repeat(3)@(negedge clk);rst_n=1;
  for(trial=0;trial<16;trial=trial+1)begin
   for(k=0;k<8;k=k+1)begin ranges[k*16+:16]=$random%10000;centers[k*16+:16]=$random%10000;end
   for(k=0;k<5;k=k+1)begin servo_snapshot[16+k*16+:16]=$random%10000;servo_snapshot[176+k*16+:16]=$random;end
   update=1;@(negedge clk);update=0;
   repeat(520)@(negedge clk);
   if(br!==bn || busy_r || busy_n)$fatal(1,"decimal schedule mismatch trial=%0d ref=%h new=%h",trial,br,bn);
  end
  for(scene=0;scene<8;scene=scene+1)begin
   page=scene[1:0];custom=scene[2]?8'ha5:0;
   for(yy=0;yy<480;yy=yy+1)begin
    flags=$random;servo_snapshot={$random,$random,$random,$random,$random,$random,$random,$random,$random,$random};
    for(xx=0;xx<640;xx=xx+1)begin
     x=xx;y=yy;@(negedge clk);
     if(tr!==tn || cr!==cn || vr!==vn || (vr && dr!==dn))
      $fatal(1,"text mismatch scene=%0d x=%0d y=%0d template=%d/%d colour=%h/%h valid=%b/%b nibble=%h/%h",scene,xx,yy,tr,tn,cr,cn,vr,vn,dr,dn);
     if((n.text_active & (n.text_active-1))!=0 || (n.digit_active & (n.digit_active-1))!=0)
      $fatal(1,"parallel text selections overlap");
     compared=compared+1;
    end
   end
  end
  $display("PASS: %0d exhaustive raster selections, 16 decimal schedules and disjoint one-hot sources",compared);$finish;
 end
 initial begin #30000000;$fatal(1,"equivalence watchdog");end
endmodule
'''
    source=OUT/'tb_pipeline_equivalence.sv';source.write_text(bench+'\n'.join(modules))
    log=OUT/'equivalence.log'
    with log.open('wb') as stream:
        subprocess.run([str(BIN/'iverilog.exe'),'-g2012','-s','tb_pipeline_equivalence','-o',str(OUT/'equivalence.vvp'),str(source)],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)
        subprocess.run([str(BIN/'vvp.exe'),str(OUT/'equivalence.vvp')],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True,timeout=600)
    text=log.read_text();print(text)
    evidence=[OUT/n for n in ['reference_renderer.v','b_v2_ui_r48_renderer.v','reference_native.v','b_v2_native_trace.v','tb_pipeline_equivalence.sv']]+[Path(__file__).resolve()]
    report=dict(passed='PASS:' in text and 'FATAL' not in text,input_hashes={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in evidence},hardware='NOT_RUN')
    (OUT/'equivalence.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
