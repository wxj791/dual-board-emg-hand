"""Private dynamic-ID SCS engine, retaining the proven byte/CRC state machine."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'fpga_b/gesture_tasks'
def main():
    s=(ROOT/'fpga_b/rtl/legacy_scs/scs_packet_engine.v').read_text()
    s=s.replace('module scs_packet_engine #(','module b_tasks_engine #(')
    s=s.replace("parameter [7:0] SERVO_ID = 8'd1,",'')
    s=s.replace('input  wire        command_valid,',
        'input wire [7:0] SERVO_ID,\n    input wire [15:0] command_speed,\n    output reg [7:0] torque_value,\n    output reg [391:0] configuration,\n    input  wire        command_valid,')
    s=s.replace('reg [9:0] target_latched;','reg [9:0] target_latched;reg [15:0] speed_latched;reg [391:0] config_temp;reg [7:0] torque_temp;')
    # Commands 5 and 6 are read-only EEPROM/torque queries in the new engine.
    a=s.index('                CMD_HOLD_HIGH: begin')
    b=s.index('                default: begin',s.index('                CMD_HOLD_LOW: begin',a))
    s=s[:a]+'''                CMD_HOLD_HIGH, CMD_HOLD_LOW: begin
                    case(tx_index)
                     3:selected_tx_byte=4;
                     4:selected_tx_byte=2;
                     5:selected_tx_byte=command_latched==CMD_HOLD_HIGH?0:40;
                     6:selected_tx_byte=command_latched==CMD_HOLD_HIGH?49:1;
                     7:selected_tx_byte=~(SERVO_ID+8'd4+8'd2+(command_latched==CMD_HOLD_LOW?8'd41:8'd49));
                     default:selected_tx_byte=8'hff;
                    endcase
                end
'''+s[b:]
    s=s.replace("10: selected_tx_byte = 8'd0;",'10: selected_tx_byte = speed_latched[15:8];')
    s=s.replace("11: selected_tx_byte = (command_latched == CMD_SLOW_MOVE) ? 8'd20 : 8'd200;",'11: selected_tx_byte = speed_latched[7:0];')
    s=s.replace("((command_latched == CMD_SLOW_MOVE) ? 8'd20 : 8'd200)","speed_latched[15:8]+speed_latched[7:0]")
    s=s.replace('target_latched    <= target_position;','target_latched    <= target_position;speed_latched<=command_speed;')
    s=s.replace("(rx_data <= 8'd17)","(rx_data <= 8'd51)")
    s=s.replace('case (parameter_index)',
        '''if(command_latched==CMD_HOLD_HIGH)config_temp[parameter_index*8+:8]<=rx_data;
                                if(command_latched==CMD_HOLD_LOW)torque_temp<=rx_data;
                                case (parameter_index)''')
    s=s.replace("((command_latched != CMD_READ_STATE) &&\n                                              (response_length != 8'd2))",
        "((command_latched == CMD_HOLD_HIGH) && response_length!=51) ||\n                                             ((command_latched == CMD_HOLD_LOW) && response_length!=3) ||\n                                             ((command_latched != CMD_READ_STATE && command_latched != CMD_HOLD_HIGH && command_latched != CMD_HOLD_LOW) && response_length!=2)")
    s=s.replace("result_code <= (servo_error == 8'd0) ? 4'd0 : 4'd4;",
        "result_code <= ((servo_error & 8'hfe) == 0) ? 4'd0 : 4'd4;\n                                    if(command_latched==CMD_HOLD_HIGH)configuration<=config_temp;\n                                    if(command_latched==CMD_HOLD_LOW)torque_value<=torque_temp;")
    # Configuration is consumed only on a checksum-valid completion pulse.
    # Write one register bank while receiving; failed/partial reads are ignored.
    s=s.replace('reg [391:0] config_temp;','')
    s=s.replace('config_temp[parameter_index*8+:8]<=rx_data','configuration[parameter_index*8+:8]<=rx_data')
    s=s.replace('if(command_latched==CMD_HOLD_HIGH)configuration<=config_temp;','')
    (D/'b_tasks_engine.v').write_text(s)
    print('Generated shared dynamic-ID engine')
if __name__=='__main__':main()
