"""Keep native sample geometry; replace expensive Euclidean AA with 3 levels."""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'fpga_b/gesture_tasks'

def simplify(src):
    if 'function [23:0] light_palette' in src:return src
    # Preserve the old palette's full/half-coverage gamma-correct RGB values.
    colours=[int(v,16) for v in (ROOT/'fpga_b/pc_scope_1080_fine_exp/assets/trace_colours.hex').read_text().split()]
    palette=' function [23:0] light_palette;input [2:0] ch;input full;\n  begin case({ch,full})\n'
    for ch in range(8):
        for full in range(2):
            palette+=f"   4'd{ch*2+full}:light_palette=24'h{colours[ch*256+(255 if full else 128)]:06x};\n"
    palette+="   default:light_palette=24'h080c18;\n  endcase end\n endfunction\n"
    start=src.index(' (* ram_style="block" *) reg [23:0] normalization')
    end=src.index(' reg [8:0] index0;',start)
    src=src[:start]+palette+src[end:]
    start=src.index('  normal9<=normalization[')
    end=src.index(' end\n always @(posedge clk or negedge rst_n)',start)
    src=src[:start]+'''  // Chebyshev strip: one pixel on horizontal/vertical segments,
  // at most sqrt(2) pixels on diagonals; full/half/off alpha levels.
  // Keep every original front-end and output stage, so sample coordinates,
  // range clipping, grid alignment and display timing do not change.
  light_width9<=slope8>864?{slope8,2'b00}:18'd3456;
  magnitude10<=error9[20]?-error9:error9;light_width10<=light_width9;
  light_alpha[0]<=magnitude10<=(light_width10>>1)?2'd2:
   magnitude10<(light_width10+(light_width10>>1))?2'd1:2'd0;
  for(light_i=1;light_i<6;light_i=light_i+1)light_alpha[light_i]<=light_alpha[light_i-1];
  colour17<=light_palette(channel[19],light_alpha[5]==2);
  line17<=light_alpha[5]!=0;
'''+src[end:]
    src=src.replace(' reg line17;', ''' reg line17;
 reg [17:0] light_width9,light_width10;
 reg [1:0] light_alpha[0:5];integer light_i;''')
    src=src.replace('// 256 coverage levels with linear-light sRGB blending; stages 0..18.',
                    '// r52: three coverage levels; same sample/coordinate/output pipeline.')
    return src

if __name__=='__main__':
    p=D/'b_v2_native_trace.v';p.write_text(simplify(p.read_text()))
