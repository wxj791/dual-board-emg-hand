"""Final B-only gates and release packaging. Never connects any hardware."""
from pathlib import Path
import argparse,ast,hashlib,json,re,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'fpga_b/gesture_tasks';OUT=ROOT/'artifacts/b_gesture_tasks'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def timing(path):
    text=path.read_text();metrics={}
    for key in ('SWNS','STNS','HWNS','HTNS'):
        m=re.search(r'\b'+key+r':\s+(-?[0-9.]+)ns',text)
        if m:metrics[key]=float(m[1])
    return metrics,len(metrics)==4 and all(v>=0 for v in metrics.values())
def rom_audit(td,minimal_text=False):
    # Reuse the read-only physical INIT-bit decoder from r48 without running
    # its old build/release entrypoint or changing any old report.
    source=(ROOT/'scripts/b_ab_v2_ui_r48_audit.py').read_text()
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='mapped_roms')
    body=ast.get_source_segment(source,node).replace('fpga_b/ab_scope_v2/assets/ui_r48/text_rows.hex','fpga_b/gesture_tasks/assets/text_rows.hex')
    body=body.replace('fpga_b/ab_scope_v2/assets/ui_r48/font_rows.hex','fpga_b/gesture_tasks/assets/font_rows.hex')
    if minimal_text:
        body=body.replace('fpga_b/gesture_tasks/assets/text_rows.hex','fpga_b/gesture_tasks/assets/text_rows_minimal.hex').replace("'4096x7'","'1024x7'")
    body=body.replace("    result = {}", "    memories += [('collision_model','fpga_b/gesture_tasks/assets/collision_model.hex',21,'servo_controller/collision/','512x21'),('query_tokens','fpga_b/gesture_tasks/assets/query_tokens.hex',12,'control/','4096x12')]\n    result = {}")
    namespace={'ROOT':ROOT,'re':re};exec(compile(body,'r48_INIT_decoder','exec'),namespace)
    assert max(int(x,16) for x in (D/'assets/query_tokens.hex').read_text().split())<4096
    return namespace['mapped_roms'](td)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--attempt',required=True);ap.add_argument('--release',action='store_true');args=ap.parse_args()
    td=OUT/('td_'+args.attempt);build=(OUT/('build_'+args.attempt+'.log')).read_text(errors='replace')
    signoff=(OUT/('signoff_'+args.attempt+'.log')).read_text(errors='replace')
    report=dict(build=args.attempt,hardware='NOT_RUN',three_endpoint_integration='NOT_RUN')
    report['timing_ns'],report['timing_passed']=timing(td/'final_timing.rpt')
    report['independent_timing_ns'],report['independent_timing_passed']=timing(td/'independent_timing.rpt')
    report['timing_matches']=report['timing_ns']==report['independent_timing_ns']
    report['timing_coverage_passed']=all(all(re.search(pattern,(td/name).read_text(),re.M) for pattern in [r'STA coverage\s*:\s*100\.00%',r'Confidence\s*:\s*Routed',r'Check Corner\s*:\s*Both \(Slow and Fast\)']) for name in ['final_timing.rpt','independent_timing.rpt'])
    report['pass_markers']='B_GESTURE_TASKS_R50_TD_PASS' in build and 'B_GESTURE_TASKS_R50_INDEPENDENT_STA_PASS' in signoff
    report['errors']=re.findall(r'^.*(?:\bERROR\b|CRITICAL-WARNING|No objects matched|Oops!|Undriven pin:).*$',build+'\n'+signoff,re.M)
    report['drc_passed']=all(s in build and s in signoff for s in ['No multi-drive.','All clock nets do not utilize local routing resource.','No abnormal timing path.'])
    required=['no clock','clock definition','invalid constraint','pll/clock buffer clock constraints','combinational loops','soft fifo timing exception constraints','no path constraints','shadowed/ignored timing exception constraints','no output delay','partial output delay']
    report['constraints_passed']=True
    # Asynchronous pins have no synchronous external delay. The source-
    # synchronous parallel inputs intentionally specify only clock_fall;
    # TD calls these partial, although both min/max falling-edge delays exist.
    expected_no_input={'rst_n','host_uart_rx','scs_rx','display_sw'}
    expected_partial_input={'link_valid'}|{f'link_data[{i}]' for i in range(8)}
    for name in ('timing_check.rpt','independent_timing_check.rpt'):
        constraint_text=(td/name).read_text()
        categories=dict(re.findall(r'checking ([^\n(]+)\((\d+)\) \((?:HIGH|MEDIUM)\)',constraint_text))
        report[name]=categories;report['constraints_passed'] &= all(categories.get(k)=='0' for k in required)
        def input_ports(section,next_section):
            title={10:'no input delay',12:'partial input delay'}[section]
            match=re.search(r'\n'+str(section)+r'\. checking '+title+r' \(MEDIUM\)\n(.*?)\n'+str(next_section)+r'\. checking ',constraint_text,re.S)
            return set(re.findall(r'^\t([^\s]+)\s*$',match[1],re.M)) if match else set()
        no_input=input_ports(10,11);partial_input=input_ports(12,13)
        report[name+'_input_exceptions']={'asynchronous':sorted(no_input),'falling_edge_only':sorted(partial_input)}
        report['constraints_passed'] &= no_input==expected_no_input and partial_input==expected_partial_input and categories.get('abnormal input delay')=='0'
    manifest=json.loads((OUT/(args.attempt+'_build_inputs.json')).read_text())
    report['source_matches_build']=all(sha(ROOT/p)==h for p,h in manifest.items())
    options=json.loads((OUT/(args.attempt+'_build_options.json')).read_text())
    recipe=options.get('recipe_source','scripts/b_gesture_tasks_build_r50.tcl')
    report['build_recipe_passed']=recipe in ['scripts/b_gesture_tasks_build_r50.tcl','scripts/b_gesture_tasks_finish_r50.tcl'] and options.get('recipe_sha256')==sha(td/'build_recipe.tcl')==sha(ROOT/recipe)
    if options.get('resume_routed'):
        parent=options['resume_routed']
        report['build_recipe_passed'] &= manifest==json.loads((OUT/(parent+'_build_inputs.json')).read_text()) and 'reset_path_margin -all' in (td/'build_recipe.tcl').read_text()
    reset_exception='set_false_path -hold -from [get_regs {pix_sync/sync_pipe[*]}] -to [get_regs {renderer/native_trace/edge_grid[18] renderer/native_trace/mid_grid[19]}]'
    recipe_text=(td/'build_recipe.tcl').read_text()
    report['grid_reset_exception']=dict(applied=reset_exception in recipe_text,kind='hold/removal only',endpoints=['renderer/native_trace/edge_grid[18]','renderer/native_trace/mid_grid[19]'],proof='tb_tasks_grid_reset')
    report['grid_reset_exception_passed']=not options.get('resume_routed') or (recipe_text.count(reset_exception)==1 and (td/'grid_reset_only.sdc').read_text()==reset_exception+'\n')
    parts=[]
    for path in (D/'sources.txt').read_text().split():
        body=(ROOT/path).read_text()
        for inc in ('caps','status','collision_params'):
            body=body.replace('`include "fpga_b/gesture_tasks/'+inc+'.vh"',(D/(inc+'.vh')).read_text())
        for prefix in ('fpga_b/pc_scope_1080_fine_exp/assets/','fpga_b/pc_scope_servo/assets/','fpga_b/ab_scope_v2/assets/','fpga_b/gesture_tasks/assets/'):
            body=body.replace(prefix,ROOT.as_posix()+'/'+prefix)
        parts.append(body+'\n')
    report['source_matches_build'] &= ''.join(parts)==(td/'all.v').read_text()
    protected=json.loads((OUT/'r48_protected.json').read_text());report['r48_changed']=[p for p,h in protected.items() if sha(ROOT/p)!=h]
    pins=re.findall(r'set_pin_assignment\s*\{\s*([^}]+?)\s*\}\s*\{\s*LOCATION\s*=\s*(\w+)',(D/'b_tasks.adc').read_text())
    report['pins']={name.strip():ball for name,ball in pins}
    report['pins_passed']=len(pins)==len(set(ball for _,ball in pins)) and report['pins'].get('display_sw')=='R15' and report['pins'].get('b_return_tx')=='A11'
    report['roms']=rom_audit(td);report['rom_passed']=all(r['passed'] for r in report['roms'].values())
    verification=json.loads((OUT/'verification_all.json').read_text())
    expected_tests={'tb_tasks_'+name for name in ['collision','control','scale','top','servo','collision_uart','history_top','guards','display','flash','mailbox','grid_reset']}
    report['tests_passed']=verification['passed'] and {t['name'] for t in verification['tests']}==expected_tests and all(t['passed'] and all(sha(ROOT/p)==h for p,h in t['input_hashes'].items()) for t in verification['tests'])
    wire=json.loads((OUT/'gpio_validation.json').read_text())
    report['wire_passed']=wire['passed'] and bool(wire.get('input_hashes')) and all(sha(ROOT/p)==h for p,h in wire['input_hashes'].items())
    comparison=json.loads((OUT/'python_comparison.json').read_text())
    report['python_passed']=comparison['passed'] and all(sha(ROOT/p)==h for p,h in comparison['reference_sha256'].items())
    reference_hashes=json.loads((OUT/'collision_assets.json').read_text())['input_sha256']
    report['frozen_references_passed']=all(sha(ROOT/p)==h for p,h in reference_hashes.items())
    preview=json.loads((OUT/'preview_r50/validation.json').read_text())
    report['preview_passed']=preview['passed'] and all(sha(ROOT/p)==h for p,h in preview['input_hashes'].items())
    pixels=json.loads((OUT/'preview_r50/pipeline_pixel_comparison.json').read_text())
    report['pixel_equivalence_passed']=pixels['passed'] and all(sha(ROOT/p)==h for p,h in pixels['input_hashes'].items()) and all(v['different_pixels']==0 and v['current_sha256']==sha(OUT/'preview_r50'/(name+'.png')) for name,v in pixels['scenes'].items())
    equivalence_path=OUT/'pipeline_candidate/equivalence.json'
    report['pipeline_equivalence_required']='reg [25:0] number_slot' in (D/'b_v2_ui_r48_renderer.v').read_text()
    if report['pipeline_equivalence_required'] and equivalence_path.exists():
        equivalence=json.loads(equivalence_path.read_text())
        report['pipeline_equivalence_passed']=equivalence['passed'] and all(sha(ROOT/p)==h for p,h in equivalence['input_hashes'].items()) and all(sha(D/name)==sha(OUT/'pipeline_candidate'/name) for name in ['b_v2_ui_r48_renderer.v','b_v2_native_trace.v'])
    else:report['pipeline_equivalence_passed']=not report['pipeline_equivalence_required']
    report['resources']={k:int(v) for k,v in re.findall(r'^#(\w+)\s+(\d+)\s+out of',(td/'phy.area').read_text(),re.M)}
    report['resources_passed']=all(report['resources'].get(k,n+1)<=n for k,n in dict(lut=19600,reg=19600,bram=64,bram32k=16,dsp=29).items())
    bit=td/'fpga_b_gesture_tasks_r50.bit';report.update(bit=str(bit.relative_to(ROOT)),bit_bytes=bit.stat().st_size,bit_sha256=sha(bit))
    checks=['timing_passed','independent_timing_passed','timing_matches','timing_coverage_passed','pass_markers','drc_passed','constraints_passed','source_matches_build','build_recipe_passed','grid_reset_exception_passed','pins_passed','rom_passed','tests_passed','wire_passed','python_passed','frozen_references_passed','preview_passed','pixel_equivalence_passed','pipeline_equivalence_passed','resources_passed']
    report['passed']=all(report[k] for k in checks) and not report['errors'] and not report['r48_changed'] and report['bit_bytes']>600000
    (OUT/(args.attempt+'_validation.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('roms','pins')},indent=2))
    if args.release:
        assert report['passed'],'Release gates failed'
        release=OUT/'r50_release';release.mkdir(exist_ok=False)
        shutil.copy2(bit,release/bit.name)
        assert sha(release/bit.name)==report['bit_sha256']
        for source in [OUT/(args.attempt+'_validation.json'),OUT/'verification_all.json',OUT/'gpio_validation.json',OUT/'python_comparison.json',OUT/(args.attempt+'_build_inputs.json')]:shutil.copy2(source,release/source.name)
        for source in (ROOT/'docs').glob('B_GESTURE_TASKS_*.md'):
            body=source.read_text(encoding='utf-8').replace('../artifacts/b_gesture_tasks/r50_release/','')
            (release/source.name).write_text(body,encoding='utf-8')
        for name in ['test_reports/PC_SCOPE_1080_60_EXPERIMENT_STATUS.md']:
            destination=release/name;destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(ROOT/'docs'/name,destination)
        for name in ['final_timing.rpt','independent_timing.rpt','timing_check.rpt','independent_timing_check.rpt','timing_exceptions.rpt','build_recipe.tcl','phy.area','clocks.rpt']:
            shutil.copy2(td/name,release/name)
        if report['grid_reset_exception']['applied']:shutil.copy2(td/'grid_reset_only.sdc',release/'grid_reset_only.sdc')
        for source in [OUT/('build_'+args.attempt+'.log'),OUT/('signoff_'+args.attempt+'.log'),OUT/'gpio_responses.hex',OUT/'query_readback.jsonl',OUT/'preview_r50/validation.json']:
            shutil.copy2(source,release/('preview_validation.json' if source.name=='validation.json' else source.name))
        for name in ['raw_live','filter_clip','envelope_hold','waiting']:
            shutil.copy2(OUT/'preview_r50'/(name+'.png'),release/(name+'.png'))
        shutil.copy2(OUT/'preview_r50/pipeline_pixel_comparison.json',release/'pipeline_pixel_comparison.json')
        if report['pipeline_equivalence_required']:
            shutil.copy2(equivalence_path,release/'pipeline_equivalence.json')
            shutil.copy2(OUT/'pipeline_candidate/equivalence.log',release/'pipeline_equivalence.log')
        snapshot={ROOT/p for p in manifest}
        snapshot.update(D.rglob('*.v'));snapshot.update(D.rglob('*.sv'));snapshot.update(D.rglob('*.vh'))
        snapshot.update((ROOT/'scripts').glob('b_gesture_tasks_*'))
        # These historical helpers are read as AST only; their build/release
        # entrypoints are never called. Preserve them for offline reproduction.
        snapshot.update(ROOT/'scripts'/name for name in ['b_ab_v2_ui_r48_audit.py','b_ab_v2_ui_r48_verify.py'])
        snapshot.add(OUT/'collision_assets.json')
        snapshot.add(OUT/'r48_protected.json')
        if report['pipeline_equivalence_required']:
            snapshot.update(ROOT/p for p in equivalence['input_hashes'])
        references=json.loads((OUT/'collision_assets.json').read_text())['input_sha256']
        snapshot.update(ROOT/p for p in references)
        for p in list(snapshot):
            if p.is_file() and p.suffix in ('.v','.sv'):
                snapshot.update(ROOT/name for name in re.findall(r'\$readmemh\("([^"]+)"',p.read_text()))
        snapshot={p for p in snapshot if p.is_file()}
        with zipfile.ZipFile(release/'sources_and_tools.zip','w',zipfile.ZIP_DEFLATED) as archive:
            for p in sorted(snapshot):archive.write(p,p.relative_to(ROOT).as_posix())
        (release/'source_snapshot_sha256.json').write_text(json.dumps({p.relative_to(ROOT).as_posix():sha(p) for p in sorted(snapshot)},indent=2)+'\n')
        shutil.copy2(OUT/(args.attempt+'_build_options.json'),release/'build_options.json')
        shutil.copy2(OUT/'collision_assets.json',release/'collision_assets.json')
        readme=f'''# B r50 独立离线候选

构建：{args.attempt}。离线仿真、布局布线、DRC、独立STA、引脚和ROM审计通过。未连接串口/JTAG、未烧录、未驱动舵机；实板及A/B/PC三端联调为NOT_RUN。当前历史基线r48保留。

时序包含两个显示网格后段寄存器的复位hold/removal例外；异常值注入验证其在有效像素到达前被覆盖。精确范围、证明与限制见[B网格复位例外](B_GESTURE_TASKS_GRID_RESET_EXCEPTION.md)及[实际构建约束](build_recipe.tcl)。工作数据路径、其他寄存器及全部recovery检查仍保留。

- [独立BIT]({bit.name})，{report['bit_bytes']}字节。
- SHA256：`{report['bit_sha256']}`。
- [总审计]({args.attempt}_validation.json)、[离线测试](verification_all.json)、[独立STA](independent_timing.rpt)、[资源报告](phy.area)。
- [交接说明](B_GESTURE_TASKS_HANDOFF.md)、[接口及接线候选](B_GESTURE_TASKS_INTERFACE.md)。
- [源码和工具快照](sources_and_tools.zip)、[快照哈希](source_snapshot_sha256.json)、[交付文件哈希](SHA256SUMS)。

旧L循环移除，九姿态槽保留；碰撞为独立任务。030a保持历史13字节，五指实时反馈和逐通道量程经0002分页查询。原始/滤波使用双极量程，包络零点在底部，mV为ADC尺度。

本包预览来自RTL输出，采用人工波形和反馈快照，不是手环实测或实板截图。候选回传为B A11/40针33→A C11/40针35，SW15为R15、有效低；物理接线、板版本及拨码ON方向待实板确认。
'''
        (release/'README.md').write_text(readme,encoding='utf-8')
        (release/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.relative_to(release).as_posix()+'\n' for p in sorted(release.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
    return 0 if report['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
