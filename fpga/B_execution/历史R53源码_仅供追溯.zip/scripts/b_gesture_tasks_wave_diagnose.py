"""Read-only r50 diagnosis: replay historical A data, no board access or rebuild."""
from pathlib import Path
import hashlib
import json
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'artifacts/b_gesture_tasks/r53_text_minimal_validation_20261101'
BIN = ROOT.parent / '.tools/icarus/portable/app/bin'


def main():
    OUT.mkdir(exist_ok=True)
    old = ROOT / 'fpga_b/ab_scope_v2/tb_b_v2_ui_r48_stream.sv'
    bench = old.read_text()
    bench = bench.replace('tb_b_v2_ui_r48_stream', 'tb_tasks_old_a_replay')
    bench = bench.replace('b_v2_wave_debug_top #(.BOOT_CLKS(8))',
                          'b_tasks_top #(.BOOT_CLKS(8),.SW_CLKS(8),.FLASH_RELEASE_CLKS(8))')
    bench = bench.replace(".host_uart_rx(1'b1),", ".host_uart_rx(1'b1),.display_sw(1'b1),")
    bench = bench.replace("value=($signed({1'b0,group_data[128+ch*16+:16]})-1650)*16;",
                          'value=group_data[128+ch*16+:16];')
    bench = bench.replace("val=($signed({1'b0,expected[d.sample_seq][128+lane*16+:16]})-1650)*16;",
                          'val=expected[d.sample_seq][128+lane*16+:16];')
    bench = bench.replace('integer clears=0,markers=0;', 'integer clears=0,markers=0,mean_total,mi;')
    bench = bench.replace('repeat(25)@(negedge d.clk_pix);', 'repeat(16000)@(negedge d.clk_pix);')
    bench = bench.replace('  if(!d.renderer.wave_valid)', '''  for(lane=0;lane<8;lane=lane+1)begin
   mean_total=0;
   for(mi=d.sample_seq-511;mi<=d.sample_seq;mi=mi+1)
    mean_total=mean_total+expected[mi][128+lane*16+:16];
   if(d.renderer.centers[lane*16+:16] !== (mean_total>>9))
    $fatal(1,"old A rolling mean lane=%d actual=%d expected=%d",lane,d.renderer.centers[lane*16+:16],mean_total>>9);
  end
  if(!d.renderer.wave_valid)''')
    tb = OUT / 'tb_tasks_old_a_replay.sv'
    tb.write_text(bench)
    src = (ROOT / 'fpga_b/gesture_tasks/sources.txt').read_text().split()
    src = [s for s in src if not s.endswith('/pll_148m5.v')]
    src += ['artifacts/b_ab_v2/integration_pll_fast.v', str(tb)]
    evidence = [ROOT / s for s in src]
    evidence += [ROOT / 'artifacts/b_ab_v2' / n for n in
                 ['a_bad_capture.hex', 'a_expected.hex', 'a_results.hex']]
    evidence += list((ROOT/'fpga_b/gesture_tasks').rglob('*.hex'))
    evidence += list((ROOT/'fpga_b/gesture_tasks').glob('*.vh'))
    hashes = {p.relative_to(ROOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in evidence}
    started = time.monotonic()
    log = OUT / 'old_a_replay.log'
    with log.open('w') as f:
        subprocess.run([str(BIN / 'iverilog.exe'), '-g2012', '-s', 'tb_tasks_old_a_replay',
                        '-o', str(OUT / 'old_a.vvp')] + src,
                       cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, check=True)
        cp = subprocess.run([str(BIN / 'vvp.exe'), str(OUT / 'old_a.vvp')],
                            cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=180)
    output = log.read_text()
    unchanged = all(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == h
                    for p, h in hashes.items())
    report = dict(passed=cp.returncode == 0 and 'PASS:' in output and 'ERROR:' not in output and 'FATAL' not in output and unchanged,
                  seconds=round(time.monotonic()-started, 2), input_hashes=hashes,
                  scope='Historical A simulation capture; raw ADC values/FIFO/actual history/512-point means.',
                  acceleration='Pixel clock divided by 64; raster parked; periodic frame commits. Control 24MHz/link 1MHz unchanged.',
                  limitation='Not live bracelet capture, gate simulation or physical timing verification.',
                  board_access=False)
    (OUT / 'old_a_replay.json').write_text(json.dumps(report, indent=2)+'\n')
    print(output[-2500:])
    print('passed=', report['passed'], 'seconds=', report['seconds'])
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
