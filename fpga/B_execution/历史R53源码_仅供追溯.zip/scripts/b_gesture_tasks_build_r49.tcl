# Private r49 EDA. No cable/JTAG/programming commands, no old outputs.
set root [file normalize [file join [file dirname [info script]] ..]]
set build_dir [file join $root artifacts b_gesture_tasks td_r49]
file mkdir $build_dir
cd $root
set f [open fpga_b/gesture_tasks/sources.txt r]
set sources [split [string trim [read $f]] "\n"]
close $f
set combined [open [file join $build_dir all.v] w]
foreach source $sources {
 set input [open [string trim $source] r]
 set body [read $input]
 close $input
 foreach inc {caps status} {
  set input [open fpga_b/gesture_tasks/$inc.vh r]
  set body [string map [list "`include \"fpga_b/gesture_tasks/$inc.vh\"" [read $input]] $body]
  close $input
 }
 set body [string map [list "fpga_b/pc_scope_1080_fine_exp/assets/" "$root/fpga_b/pc_scope_1080_fine_exp/assets/" "fpga_b/pc_scope_servo/assets/" "$root/fpga_b/pc_scope_servo/assets/" "fpga_b/ab_scope_v2/assets/" "$root/fpga_b/ab_scope_v2/assets/" "fpga_b/gesture_tasks/assets/" "$root/fpga_b/gesture_tasks/assets/"] $body]
 puts $combined $body
}
close $combined
cd $build_dir
import_device eagle_s20.db -package EG4S20BG256
read_verilog -file all.v -top b_tasks_top
read_adc [file join $root fpga_b gesture_tasks b_tasks.adc]
read_sdc [file join $root fpga_b gesture_tasks b_tasks.sdc]
set_param rtl min_ripple_len 8
optimize_rtl
report_area -file rtl.area
optimize_gate -maparea gate.area
legalize_phy_inst
write_verilog gate.v
place
export_db placed.db
report_timing_summary -ep_num 30 -file placed_timing.rpt
report_area -io_info -file placed.area
set_param route effort high
set_param route post_route_opt on
route
export_db pre_hold.db
import_db pre_hold.db
fix_hold
report_area -io_info -file phy.area
report_timing_summary -ep_num 30 -file final_timing.rpt
check_timing -verbose -file timing_check.rpt
report_timing_exception -file timing_exceptions.rpt
report_clock_summary -file clocks.rpt
export_db routed.db
report_route_status -drc
set f [open final_timing.rpt r]
set timing [read $f]
close $f
foreach metric {SWNS STNS HWNS HTNS} {
 if {![regexp "$metric: +(-?\[0-9.\]+)ns" $timing unused value]} {error "Missing $metric"}
 if {$value < 0} {error "R49_REJECT $metric=$value"}
}
bitgen -bit fpga_b_gesture_tasks_r49.bit
puts B_GESTURE_TASKS_R49_TD_PASS
exit
