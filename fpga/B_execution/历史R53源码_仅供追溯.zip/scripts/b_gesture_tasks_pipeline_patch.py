"""Apply coordinated B display pipeline changes with aligned raster outputs.

Only called by the private display generator. No historical input is changed.
"""

def restructure(renderer, native):
    # Keep two settling clocks + 16 double-dabble clocks + one write clock,
    # but replace counter terminal decoding with rotating one-hot schedules.
    begin=renderer.index(' reg [25:0] number_write;')
    end=renderer.index(' genvar bcd_item;',begin)
    controller=''' reg [25:0] number_write;
 reg [15:0] number_result;
 reg [127:0] ranges_bcd,centers_bcd;
 reg [79:0] positions_bcd,loads_bcd;
 (* preserve="true" *) reg [25:0] number_slot;
 (* preserve="true" *) reg [18:0] number_phase;
 reg numbers_busy;
 reg [31:0] number_shift;
 reg [31:0] number_adjusted;
 reg [15:0] number_selected;
 integer number_k,number_source;
 always @*begin
  number_selected=0;
  for(number_source=0;number_source<8;number_source=number_source+1)begin
   number_selected=number_selected | ({16{number_slot[number_source]}} & ranges[number_source*16+:16]);
   number_selected=number_selected | ({16{number_slot[8+number_source]}} & centers[number_source*16+:16]);
  end
  for(number_source=0;number_source<5;number_source=number_source+1)begin
   number_selected=number_selected | ({16{number_slot[16+number_source]}} & servo_snapshot[16+number_source*16+:16]);
   number_selected=number_selected | ({16{number_slot[21+number_source]}} & (servo_snapshot[176+number_source*16+:16] & 16'h03ff));
  end
  number_adjusted=number_shift;
  for(number_k=16;number_k<32;number_k=number_k+4)
   if(number_shift[number_k+:4]>=5)number_adjusted[number_k+:4]=number_shift[number_k+:4]+3;
 end
 reg [15:0] number_input;
 always @(posedge clk)number_input<=number_selected;
 integer number_destination;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   number_slot<=1;number_phase<=1;numbers_busy<=0;
   number_shift<=0;number_write<=0;number_result<=0;
  end else begin
   for(number_destination=0;number_destination<26;number_destination=number_destination+1)
    number_write[number_destination]<=numbers_busy && number_phase[18] && number_slot[number_destination];
   number_result<=number_shift[31:16];
   if(number_update)begin number_slot<=1;number_phase<=1;numbers_busy<=1;end
   else if(numbers_busy)begin
    number_phase<={number_phase[17:0],number_phase[18]};
    if(number_phase[1])number_shift<={16'd0,number_input};
    else if(|number_phase[17:2])number_shift<=number_adjusted<<1;
    if(number_phase[18])begin
     number_slot<={number_slot[24:0],1'b0};
     if(number_slot[25])numbers_busy<=0;
    end
   end
  end
 end
'''
    renderer=renderer[:begin]+controller+renderer[end:]
    # Independent raster regions, captured beside x0/y0. Their disjointness
    # makes the following OR trees actual parallel selectors, without a
    # priority cascade across unrelated text rows and servo fields.
    region=''' reg [10:0] text_region;
 always @(posedge clk)begin
  text_region[0]<=y<16;
  text_region[1]<=y>=16 && y<32;
  text_region[2]<=y>=32 && y<48 && x[9:3]<16;
  text_region[3]<=y>=32 && y<48 && x[9:3]>=16 && x[9:3]<36;
  text_region[4]<=y>=32 && y<48 && x[9:3]>=36 && x[9:3]<54;
  text_region[5]<=y>=32 && y<48 && x[9:3]>=54;
  text_region[6]<=y>=48 && y<368 && lane_offset(y)<16 && x[9:3]<8;
  text_region[7]<=y>=48 && y<368 && lane_offset(y)>=16 && lane_offset(y)<32 && x[9:3]<8;
  text_region[8]<=y>=368 && y<384 && x<384;
  text_region[9]<=y>=384 && y<464 && x<384;
  text_region[10]<=y>=464 && x<384;
 end
 reg [23:0] channel_colour;
 always @*begin
  case(channel_early)
   0:channel_colour=24'h00ffff;1:channel_colour=24'h30ff80;
   2:channel_colour=24'hffd050;3:channel_colour=24'hff80c0;
   4:channel_colour=24'h80b0ff;5:channel_colour=24'hff9050;
   6:channel_colour=24'ha0ff50;7:channel_colour=24'hc090ff;
  endcase
 end
 wire [10:0] text_active=text_region & {3'b111,(page==0),7'b1111111};
 wire [4:0] range_template=custom[channel_early]?5'd30:(5'd13+channel_early);
 wire [4:0] view_template=freeze?5'd8:wave_valid?5'd7:5'd9;
 wire [4:0] clip_template=!wave_seen?5'd29:(saturated || native_clip)?5'd11:5'd10;
 wire [23:0] view_colour=freeze?24'hffc56b:wave_valid?24'h30ff80:24'h65d9ef;
 wire [23:0] clip_colour=wave_seen && (saturated || native_clip)?24'hff657a:24'h9cacc6;
 wire [13:0] digit_active={
  text_region[9] && text_col_select[13],
  text_region[9] && text_col_select[12],
  text_region[9] && text_col_select[11] && servo_snapshot[289+servo_row],
  text_region[9] && text_col_select[10],
  text_region[9] && text_col_select[5] && servo_snapshot[266+servo_row],
  text_region[9] && text_col_select[4] && servo_snapshot[266+servo_row],
  text_region[9] && text_col_select[3] && servo_snapshot[266+servo_row],
  text_region[8] && text_col_select[14],
  text_active[7] && text_col_select[9],
  text_region[6] && text_col_select[9] && !custom[channel_early],
  text_region[5] && text_col_select[2],
  text_region[3] && text_col_select[1] && !freeze && !wave_valid,
  text_region[1] && text_col_select[0],1'b0};
 always @*begin
  template_id_early=({5{text_active[0]}} & {3'd0,page[1:0]}) |
   ({5{text_active[1]}} & 5'd4) |
   ({5{text_active[2]}} & (flow_active?5'd5:5'd6)) |
   ({5{text_active[3]}} & view_template) |
   ({5{text_active[4]}} & clip_template) |
   ({5{text_active[5]}} & 5'd12) |
   ({5{text_active[6]}} & range_template) |
   ({5{text_active[7]}} & 5'd27) |
   ({5{text_active[8]}} & 5'd21) |
   ({5{text_active[9]}} & (5'd22+servo_row)) |
   ({5{text_active[10]}} & 5'd28) | {5{!(|text_active)}};
  text_colour_early=({24{text_active[0]}} & 24'h65d9ef) |
   ({24{text_active[2]}} & (flow_active?24'h30ff80:24'hffc56b)) |
   ({24{text_active[3]}} & view_colour) |
   ({24{text_active[4]}} & clip_colour) |
   ({24{text_active[6]}} & channel_colour) |
   ({24{text_active[8]}} & 24'hffc56b) |
   ({24{text_active[9]}} & 24'h6d819d) |
   ({24{!(text_active[0] || text_active[2] || text_active[3] || text_active[4] || text_active[6] || text_active[8] || text_active[9])}} & 24'h9cacc6);
  dynamic_valid_early=|digit_active;
  dynamic_nibble_early=({4{digit_active[1]}} & rate_n0) |
   ({4{digit_active[2]}} & fill_n0) | ({4{digit_active[3]}} & count_n0) |
   ({4{digit_active[4]}} & gain_n0) | ({4{digit_active[5]}} & center_n0) |
   ({4{digit_active[6]}} & {3'd0,armed}) |
   ({4{digit_active[7]}} & position_n0) | ({4{digit_active[8]}} & speed_n0) |
   ({4{digit_active[9]}} & load_n0) |
   ({4{digit_active[10]}} & {3'd0,servo_snapshot[256+servo_row]}) |
   ({4{digit_active[11]}} & {3'd0,servo_snapshot[261+servo_row]}) |
   ({4{digit_active[12]}} & {3'd0,servo_snapshot[266+servo_row]}) |
   ({4{digit_active[13]}} & {3'd0,servo_snapshot[186+{servo_row,4'd0}]});
 end
'''
    begin=renderer.index(' always @*begin\n  template_id_early=31;')
    end=renderer.index(' always @(posedge clk)begin\n  template_id<=',begin)
    renderer=renderer[:begin]+region+renderer[end:]
    # Use the existing extra RAM-output stage to select each 16-bit channel.
    # The following stage now selects parity/last sample only. No extra
    # latency, region delay, Q format, arithmetic or coverage change.
    native=native.replace('reg [127:0] even_read2,odd_read2;', 'reg [15:0] even_read2,odd_read2;')
    native=native.replace('even_read2<=even1;odd_read2<=odd1;',
        'even_read2<=even1[channel[1]*16+:16];odd_read2<=odd1[channel[1]*16+:16];')
    native=native.replace('even_read2[channel[2]*16+:16]', 'even_read2').replace('odd_read2[channel[2]*16+:16]', 'odd_read2')
    # Preserve a full RAM output register before channel selection. The RAM
    # clock-to-output delay and the 8:1 mux must not share one pixel period.
    # Carry every related coordinate/valid signal, and the overlay output,
    # through the same additional clock so the visible raster is unchanged.
    native=native.replace('reg [15:0] even_read2,odd_read2;', '''reg [127:0] even_ram2,odd_ram2;
 reg odd_ramfirst2,last_ram2;
 always @(posedge clk)begin
  even_ram2<=even1;odd_ram2<=odd1;odd_ramfirst2<=odd_first1;last_ram2<=last1;
 end
 reg [15:0] even_read2,odd_read2;''')
    native=native.replace('even_read2<=even1[channel[1]*16+:16];odd_read2<=odd1[channel[1]*16+:16];odd_first2<=odd_first1;last_read2<=last1;',
        'even_read2<=even_ram2[channel[2]*16+:16];odd_read2<=odd_ram2[channel[2]*16+:16];odd_first2<=odd_ramfirst2;last_read2<=last_ram2;')
    native=native.replace('center2<=centers[channel[2]*16+:16];','center2<=centers[channel[3]*16+:16];')
    native=native.replace('lane_coef[channel[3]]','lane_coef[channel[4]]')
    native=native.replace('channel[0:19]','channel[0:20]').replace('lane[0:8]','lane[0:9]')
    native=native.replace('phase[0:8]','phase[0:9]')
    native=native.replace('reg [19:0] region_pipe','reg [20:0] region_pipe')
    native=native.replace('[18:0],','[19:0],').replace('data_i<20','data_i<21').replace('data_i<9','data_i<10')
    native=native.replace('region_pipe[7] && valid_pipe[7]','region_pipe[8] && valid_pipe[8]')
    native=native.replace('inv_phase[8]','inv_phase[9]').replace('phase[8]','phase[9]').replace('lane[8]','lane[9]')
    native=native.replace('channel[18]','channel[19]').replace('region_pipe[19]','region_pipe[20]').replace('valid_pipe[19]','valid_pipe[20]').replace('edge_grid[19]','edge_grid[20]').replace('mid_grid[19]','mid_grid[20]')
    renderer=renderer.replace('overlay_pipe[0:13]','overlay_pipe[0:14]').replace('overlay_pipe[13]','overlay_pipe[14]').replace('pipe_i<14','pipe_i<15')
    # Decode the standard range in parallel beside its gain/custom capture.
    # Avoid a six-level priority implementation of the coefficient case.
    native=native.replace('reg [23:0] cfg_standard;', 'reg [23:0] cfg_standard;\n reg [5:0] cfg_match;\n reg [2:0] cfg_lane3;reg [15:0] cfg_gain3;reg cfg_custom3;')
    native=native.replace('cfg_range<=0;', 'cfg_range<=0;cfg_match<=0;')
    native=native.replace('cfg_custom2<=0;', 'cfg_custom2<=0;cfg_lane3<=0;cfg_gain3<=0;cfg_custom3<=0;')
    native=native.replace('cfg_standard<=raw_coef(cfg_range);', '''cfg_match<={ranges[cfg_lane*16+:16]==1200,ranges[cfg_lane*16+:16]==500,
    ranges[cfg_lane*16+:16]==200,ranges[cfg_lane*16+:16]==100,
    ranges[cfg_lane*16+:16]==50,ranges[cfg_lane*16+:16]==20};
   cfg_standard<=({24{cfg_match[0]}} & 24'd2149581) |
    ({24{cfg_match[1]}} & 24'd859832) | ({24{cfg_match[2]}} & 24'd429916) |
    ({24{cfg_match[3]}} & 24'd214958) | ({24{cfg_match[4]}} & 24'd85983) |
    ({24{cfg_match[5]}} & 24'd35826) | ({24{!(|cfg_match)}} & 24'd13028);''')
    # Separate the 8:1 channel mux from 16-bit comparisons. Configuration
    # settles in blanking; this extra preparation clock does not delay pixels.
    native=native.replace('ranges[cfg_lane*16+:16]==', 'cfg_range==')
    native=native.replace('cfg_gain2<=cfg_gain;cfg_custom2<=cfg_custom;',
        'cfg_gain2<=cfg_gain;cfg_custom2<=cfg_custom;\n   cfg_lane3<=cfg_lane2;cfg_gain3<=cfg_gain2;cfg_custom3<=cfg_custom2;')
    native=native.replace("lane_coef[cfg_lane2]<=cfg_custom2?cfg_gain2*24'd117:cfg_standard;",
        "lane_coef[cfg_lane3]<=cfg_custom3?cfg_gain3*24'd117:cfg_standard;")
    # Select servo flags before the text overlay's multi-source OR tree,
    # alongside the existing per-pixel decimal digit preparation.
    flags=''' reg servo_online0,servo_torque0,servo_feedback0,servo_torque_valid0,servo_direction0;
 always @(posedge clk)begin
  servo_online0<=servo_snapshot[256+servo_row_input];
  servo_torque0<=servo_snapshot[261+servo_row_input];
  servo_feedback0<=servo_snapshot[266+servo_row_input];
  servo_torque_valid0<=servo_snapshot[289+servo_row_input];
  servo_direction0<=servo_snapshot[186+{servo_row_input,4'd0}];
 end
'''
    renderer=renderer.replace(' wire [13:0] digit_active=', flags+' wire [13:0] digit_active=')
    for old,new in [('servo_snapshot[256+servo_row]','servo_online0'),
                    ('servo_snapshot[261+servo_row]','servo_torque0'),
                    ('servo_snapshot[266+servo_row]','servo_feedback0'),
                    ('servo_snapshot[289+servo_row]','servo_torque_valid0'),
                    ('servo_snapshot[186+{servo_row,4\'d0}]','servo_direction0')]:
        renderer=renderer.replace(old,new)
    # Use the existing nibble2 stage for the OR reduction: prepare independent
    # source terms in the previous stage instead of mux + reduction together.
    renderer=renderer.replace('reg [3:0] dynamic_nibble,dynamic_nibble_early;',
        'reg [3:0] dynamic_nibble_early;\n reg [3:0] dynamic_terms[1:13];\n wire [3:0] dynamic_nibble='+' | '.join('dynamic_terms[%d]'%i for i in range(1,14))+';')
    begin=renderer.index('  dynamic_nibble_early=')
    end=renderer.index(';',begin)
    expression=renderer[begin:end].split('=',1)[1]
    terms=expression.split(' |')
    assert len(terms)==13
    registers=' always @(posedge clk)begin\n'+''.join('  dynamic_terms[%d]<=%s;\n'%(i,t.strip()) for i,t in enumerate(terms,1))+' end\n'
    insert=renderer.index(' always @(posedge clk)begin\n  template_id<=',end)
    renderer=renderer[:insert]+registers+renderer[insert:]
    renderer=renderer.replace('dynamic_nibble<=dynamic_nibble_early;','')
    return renderer,native
