"""One-shot private r49 seed; refuses to overwrite an existing candidate."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'fpga_b/gesture_tasks'
OUT=ROOT/'artifacts/b_gesture_tasks'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    D.mkdir(exist_ok=True); OUT.mkdir(exist_ok=True)
    assert not (D/'sources.txt').exists(), 'candidate already seeded'
    source=(ROOT/'fpga_b/ab_scope_v2/wave_ui_r48_sources.txt').read_text().split()
    protected=source+[str(p.relative_to(ROOT)).replace('\\','/') for p in
        (ROOT/'fpga_b/ab_scope_v2/assets').rglob('*') if p.is_file()]
    protected += ['artifacts/b_ab_v2/ui_r48_release/fpga_b_ab_scope_v2_ui_r48.bit',
                  'artifacts/b_ab_v2/td_ui_r48_validation.json']
    manifest={p:sha(ROOT/p) for p in protected}
    (OUT/'r48_protected.json').write_text(json.dumps(manifest,indent=2)+'\n')
    new=[]
    for name in source:
        p=Path(name)
        if p.parent.as_posix()=='fpga_b/ab_scope_v2':
            dest=D/p.name
            shutil.copyfile(ROOT/p,dest)
            new.append(dest.relative_to(ROOT).as_posix())
        else:new.append(name)
    (D/'sources.txt').write_text('\n'.join(new)+'\n')
    shutil.copyfile(ROOT/'fpga_b/ab_scope_v2/b_v2.adc',D/'b_tasks.adc')
    shutil.copyfile(ROOT/'fpga_b/ab_scope_v2/wave_debug.sdc',D/'b_tasks.sdc')
    print('Seeded private r49; protected',len(manifest),'r48 inputs')
if __name__=='__main__':main()
