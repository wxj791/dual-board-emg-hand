"""Replace differential RAW centering with a bounded blanking-only scan."""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'fpga_b/gesture_tasks'

ENGINE=''' reg [127:0] centers;
 reg [21:0] mean_sum[0:7];
 reg [3:0] mean_state;
 reg [7:0] mean_pair;
 reg [2:0] mean_lane;
 reg [8:0] mean_even_addr,mean_odd_addr;
 reg [127:0] mean_even_word,mean_odd_word;
 reg [15:0] mean_even_lane,mean_odd_lane;
 reg [16:0] mean_pair_value;
 reg mean_bad,mean_fault;
 wire [127:0] mean_even_data,mean_odd_data;
 wire mean_busy=mean_state!=0;
 wire mean_read=mean_busy;
 wire [9:0] mean_base=write_ptr-10'd512;
 integer mean_i;
 // Read the existing 1024-point history only during vertical blanking.
 // Eight channels share one sum datapath. Every scan begins from zero;
 // no read/write collision or old differential sum can cause drift.
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   centers<=0;mean_state<=0;mean_pair<=0;mean_lane<=0;
   mean_even_addr<=0;mean_odd_addr<=0;mean_bad<=0;mean_fault<=0;
   for(mean_i=0;mean_i<8;mean_i=mean_i+1)mean_sum[mean_i]<=0;
  end else if(history_clear)begin
   centers<=0;mean_state<=0;mean_bad<=0;mean_fault<=0;
   for(mean_i=0;mean_i<8;mean_i=mean_i+1)mean_sum[mean_i]<=0;
  end else if(mean_busy && v>=41)begin
   mean_state<=0;mean_fault<=1;
  end else case(mean_state)
   0:if(view_commit && page==0 && history>=512 && !freeze && v<41)begin
    mean_even_addr<=mean_base[9:1]+mean_base[0];mean_odd_addr<=mean_base[9:1];
    mean_pair<=0;mean_lane<=0;mean_bad<=0;mean_state<=1;
    for(mean_i=0;mean_i<8;mean_i=mean_i+1)mean_sum[mean_i]<=0;
   end
   1:mean_state<=2;
   2:mean_state<=3;
   3:begin mean_even_word<=mean_even_data;mean_odd_word<=mean_odd_data;mean_lane<=0;mean_state<=4;end
   4:begin
    mean_even_lane<=mean_even_word[mean_lane*16+:16];mean_odd_lane<=mean_odd_word[mean_lane*16+:16];mean_state<=5;
   end
   5:begin
    mean_pair_value<={1'b0,mean_even_lane}+{1'b0,mean_odd_lane};
    if(mean_even_lane>3300 || mean_odd_lane>3300)mean_bad<=1;
    mean_state<=6;
   end
   6:begin
    mean_sum[mean_lane]<=mean_sum[mean_lane]+mean_pair_value;
    if(mean_lane!=7)begin mean_lane<=mean_lane+1'b1;mean_state<=4;end
    else if(mean_pair==255)mean_state<=7;
    else begin
     mean_pair<=mean_pair+1'b1;mean_even_addr<=mean_even_addr+1'b1;mean_odd_addr<=mean_odd_addr+1'b1;mean_state<=1;
    end
   end
   7:begin
    if(!mean_bad)for(mean_i=0;mean_i<8;mean_i=mean_i+1)centers[mean_i*16+:16]<=mean_sum[mean_i]>>9;
    else mean_fault<=1;
    mean_state<=0;
   end
   default:begin mean_state<=0;mean_fault<=1;end
  endcase
 end
 reg view_waiting;
 wire view_commit=(frame_start || view_waiting) && !sample_valid1 && !mean_busy;
 always @(posedge clk or negedge rst_n)if(!rst_n)view_waiting<=0;else if(history_clear)view_waiting<=0;else if(view_commit)view_waiting<=0;else if(frame_start)view_waiting<=1;

'''

def patch(renderer,native):
    if 'mean_ring[0:511]' in renderer:
        start=renderer.index(' (* ram_style="block" *) reg [127:0] mean_ring')
        end=renderer.index(' always @(posedge clk or negedge rst_n)\n  if(!rst_n)begin sample_valid1',start)
        renderer=renderer[:start]+ENGINE+renderer[end:]
        renderer=renderer.replace('.raw_page(page==0),', '.raw_page(page==0),.mean_read(mean_read),.mean_even_addr(mean_even_addr),.mean_odd_addr(mean_odd_addr),.mean_even_data(mean_even_data),.mean_odd_data(mean_odd_data),')
        # Keep BCD publication after the new centers have actually committed.
        renderer=renderer.replace('else number_update<=view_commit;', 'else number_update<=view_commit || mean_state==7;')
    if 'input wire mean_read,' not in native:
        native=native.replace(' input wire raw_page,',' input wire raw_page,\n input wire mean_read,input wire [8:0] mean_even_addr,mean_odd_addr,\n output wire [127:0] mean_even_data,mean_odd_data,')
        native=native.replace(' reg [127:0] even1,odd1,data_a2,data_b2;', ' assign mean_even_data=even1;assign mean_odd_data=odd1;\n reg [127:0] even1,odd1,data_a2,data_b2;')
        native=native.replace('even1<=ring_even[even_address];odd1<=ring_odd[odd_address];', 'even1<=ring_even[mean_read?mean_even_addr:even_address];odd1<=ring_odd[mean_read?mean_odd_addr:odd_address];')
    renderer=renderer.replace('wire mean_read=mean_busy && v<41;', 'wire mean_read=mean_busy;')
    if 'number_result_range' not in renderer:
        renderer=renderer.replace(' reg [15:0] number_result;', ' reg [15:0] number_result;\n (* preserve="true" *) reg [15:0] number_result_range,number_result_center,number_result_position,number_result_load;')
        renderer=renderer.replace('number_result<=0;', 'number_result<=0;number_result_range<=0;number_result_center<=0;number_result_position<=0;number_result_load<=0;')
        renderer=renderer.replace('number_result<=number_shift[31:16];', 'number_result<=number_shift[31:16];number_result_range<=number_shift[31:16];number_result_center<=number_shift[31:16];number_result_position<=number_shift[31:16];number_result_load<=number_shift[31:16];')
        for target,suffix in [('ranges_bcd','range'),('centers_bcd','center'),('positions_bcd','position'),('loads_bcd','load')]:
            lines=renderer.splitlines(True)
            renderer=''.join(line.replace('<=number_result;', '<=number_result_'+suffix+';') if target+'[' in line else line for line in lines)
    return renderer,native

def main():
    renderer,native=patch((D/'b_v2_ui_r48_renderer.v').read_text(),(D/'b_v2_native_trace.v').read_text())
    (D/'b_v2_ui_r48_renderer.v').write_text(renderer)
    (D/'b_v2_native_trace.v').write_text(native)

if __name__=='__main__':main()
