"""Audit a whale candidate without altering r43 reports or using hardware."""
import argparse
import json
import re
from b_ab_v2_audit import ROOT, OUT, sha, readlog
from b_ab_v2_diagnostic_audit import timing


def mapped_roms(td):
    text = (td / 'gate.v').read_text()
    blocks = list(re.finditer(r'// address_offset=([^\n]+)\n\s*// ([^\n]+)\n\s*EG_PHY_(BRAM32K|BRAM) #\((.*?)\)\s*\\[^\s]+\s*\((.*?)\);', text, re.S))
    memories = [(f'whale_bank{i}', f'fpga_b/ab_scope_v2/assets/whale/packed{i}.hex', 8,
                 'renderer/sprite/', '4096x8') for i in range(12)]
    memories += [
        ('font', 'fpga_b/ab_scope_v2/assets/ui_r48/font_rows.hex', 5, 'renderer/font/', '1024x5'),
        ('normalization', 'fpga_b/pc_scope_1080_fine_exp/assets/normalization.hex', 24, 'renderer/native_trace/', '1024x24'),
        ('coverage', 'fpga_b/pc_scope_1080_fine_exp/assets/coverage.hex', 8, 'renderer/native_trace/', '8192x8'),
        ('colours', 'fpga_b/pc_scope_1080_fine_exp/assets/trace_colours.hex', 24, 'renderer/native_trace/', '2048x24'),
        ('text', 'fpga_b/ab_scope_v2/assets/ui_r48/text_rows.hex', 7, 'renderer/ramread', '4096x7')]
    result = {}
    for name, path, bits, prefix, shape in memories:
        values = [int(x, 16) for x in (ROOT / path).read_text().split()]
        seen, errors, count, types = set(), 0, 0, []
        for m in blocks:
            if not m[2].startswith(prefix) or not m[2].strip().endswith('_' + shape):
                continue
            # TD assigns ramread numbers independently of the source bank
            # numbers. Identify each bank by the actual connected qN net.
            if name.startswith('whale_bank'):
                bank = int(name[len('whale_bank'):])
                connection = re.search(r'\.doa\((.*?)\)', m[5], re.S)
                if not connection or not re.search(r'\\renderer/sprite/q' + str(bank) + r'\s', connection[1]):
                    continue
            meta = dict(x.split('=') for x in ('address_offset=' + m[1]).split(';') if '=' in x)
            base, offset, depth, width, physical = [int(meta[k]) for k in ['address_offset', 'data_offset', 'depth', 'width', 'working_width']]
            data = {int(n, 16): int(v, 16) for n, v in re.findall(r"\.INIT_([0-9A-F]{2})\(256'h([0-9A-F]+)\)", m[4])}
            parity = {int(n, 16): int(v, 16) for n, v in re.findall(r"\.INITP_([0-9A-F]{2})\(256'h([0-9A-F]+)\)", m[4])}
            for address in range(base, min(base + depth, len(values))):
                for bit in range(width):
                    if physical >= 9 and bit % 9 == 8:
                        index = (address - base) * (physical // 9) + bit // 9
                        init = parity
                    else:
                        stride = physical * 8 // 9 if physical >= 9 else physical
                        local = bit // 9 * 8 + bit % 9 if physical >= 9 else bit
                        index = (address - base) * stride + local
                        init = data
                    actual = (init[index // 256] >> (index % 256)) & 1
                    errors += actual != ((values[address] >> (offset + bit)) & 1)
                    seen.add((address, offset + bit))
            count += 1
            types.append(m[3])
        result[name] = dict(blocks=count, types=types, bits_checked=len(seen), expected_bits=len(values) * bits,
                            mismatches=errors, passed=len(seen) == len(values) * bits and errors == 0)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', default='td_ui_r48')
    args = parser.parse_args()
    td = OUT / args.build
    build_log = readlog(OUT / (args.build + '_build.log'))
    signoff_log = readlog(OUT / (args.build + '_signoff.log'))
    result = dict(build=args.build, hardware='NOT_RUN', purpose='DISPLAY_INFORMATION_AND_STATE_CLARITY')
    result['timing_ns'], result['timing_passed'] = timing(td / 'final_timing.rpt')
    result['independent_timing_ns'], result['independent_timing_passed'] = timing(td / 'independent_timing.rpt')
    result['timing_matches'] = result['timing_ns'] == result['independent_timing_ns']
    result['pass_markers'] = ('B_AB_V2_WAVE_DEBUG_TD_PASS' in build_log and
                              'B_AB_V2_WAVE_DEBUG_INDEPENDENT_STA_PASS' in signoff_log)
    result['errors'] = re.findall(r'^.*(?:\bERROR\b|CRITICAL-WARNING|No objects matched|Oops!).*$', build_log + '\n' + signoff_log, re.M)
    result['drc_passed'] = all(s in build_log and s in signoff_log for s in
                             ['No multi-drive.', 'All clock nets do not utilize local routing resource.', 'No abnormal timing path.'])
    required = ['no clock', 'clock definition', 'invalid constraint', 'pll/clock buffer clock constraints',
                'combinational loops', 'soft fifo timing exception constraints', 'no path constraints',
                'shadowed/ignored timing exception constraints', 'no output delay', 'partial output delay']
    result['constraints_passed'] = True
    for filename in ['timing_check.rpt', 'independent_timing_check.rpt']:
        categories = dict(re.findall(r'checking ([^\n(]+)\((\d+)\) \((?:HIGH|MEDIUM)\)', (td / filename).read_text()))
        result[filename] = categories
        result['constraints_passed'] &= all(categories.get(key) == '0' for key in required)
    sources = (ROOT / 'fpga_b/ab_scope_v2/wave_ui_r48_sources.txt').read_text().split()
    parts = []
    for source in sources:
        body = (ROOT / source).read_text()
        for prefix in ['fpga_b/pc_scope_1080_fine_exp/assets/', 'fpga_b/pc_scope_servo/assets/', 'fpga_b/ab_scope_v2/assets/']:
            body = body.replace(prefix, ROOT.as_posix() + '/' + prefix)
        parts.append(body + '\n')
    result['source_matches_build'] = ''.join(parts) == (td / 'wave_debug_all.v').read_text()
    result['mapped_roms'] = mapped_roms(td)
    result['rom_passed'] = all(row['passed'] for row in result['mapped_roms'].values())
    (td / 'rom_audit.json').write_text(json.dumps(result['mapped_roms'], indent=2) + '\n')
    result['tests'] = []
    for name in ['ui_r48_display_validation.json', 'ui_r48_animation_validation.json', 'ui_r48_stream_validation.json', 'ui_r48_production_validation.json']:
        evidence = json.loads((OUT / name).read_text())
        hashes = dict(evidence.get('input_hashes', {}), **evidence.get('vector_hashes', {}), **evidence.get('asset_hashes', {}))
        for test in evidence.get('tests', []):
            hashes.update(test['input_hashes'])
        evidence['current_inputs'] = all(sha(ROOT / p) == h for p, h in hashes.items())
        result['tests'].append(evidence)
    result['tests_passed'] = all(row['passed'] and row['current_inputs'] for row in result['tests'])
    result['resources'] = {k: int(v) for k, v in re.findall(r'^#(\w+)\s+(\d+)\s+out of', (td / 'phy.area').read_text(), re.M)}
    result['resource_passed'] = all(result['resources'].get(k, limit + 1) <= limit for k, limit in
                                     dict(lut=19600, reg=19600, bram=64, bram32k=16, dsp=29).items())
    preserved = json.loads((OUT / 'ui_r47/preserved_r46.json').read_text())
    preserved = {p: h for p, h in preserved.items() if not p.startswith('docs/')}
    protected = json.loads((ROOT / 'artifacts/ab_scope_1080_fine/protected_inputs.json').read_text())
    result['preserved_changed'] = [p for p, h in {**preserved, **protected}.items() if sha(ROOT / p) != h]
    paths = {ROOT / p for p in sources}
    for source in sources:
        paths.update(ROOT / p for p in re.findall(r'\$readmemh\("([^"]+)"', (ROOT / source).read_text()))
    paths.update(ROOT / p for p in ['fpga_b/ab_scope_v2/wave_debug.sdc', 'fpga_b/ab_scope_v2/b_v2.adc',
                                   'fpga_b/ab_scope_v2/wave_ui_r48_sources.txt', 'fpga_b/ab_scope_v2/assets/whale/SOURCE.json',
                                   'scripts/b_ab_v2_ui_r48_prepare.py', 'scripts/b_ab_v2_ui_r48_verify.py',
                                   'scripts/b_ab_v2_ui_r48_animation_verify.py',
                                   'scripts/b_ab_v2_ui_r48_stream_verify.py', 'scripts/b_ab_v2_ui_r48_audit.py',
                                   'scripts/b_ab_v2_build_ui_r48.tcl', 'scripts/b_ab_v2_signoff_ui_r48.tcl'])
    metadata = json.loads((ROOT / 'fpga_b/ab_scope_v2/assets/whale/SOURCE.json').read_text())
    result['source_gif_matches'] = sha(ROOT / metadata['source']) == metadata['source_sha256']
    paths.add(ROOT / metadata['source'])
    result['source_asset_hashes'] = {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(paths)}
    bit = next(td.glob('*.bit'))
    result.update(bit=bit.relative_to(ROOT).as_posix(), bit_bytes=bit.stat().st_size, bit_sha256=sha(bit))
    checks = ['timing_passed', 'independent_timing_passed', 'timing_matches', 'pass_markers', 'drc_passed',
              'constraints_passed', 'source_matches_build', 'rom_passed', 'tests_passed', 'resource_passed', 'source_gif_matches']
    result['passed'] = all(result[k] for k in checks) and not result['errors'] and not result['preserved_changed'] and result['bit_bytes'] > 600000
    result['limits'] = 'UI-only change on r46 wave-only control. FLOW observes displayed-pipeline sample arrival, not physical ADC timing. No servo restoration. Existing r43 page/revision/transport/query limitations remain. Not board acceptance.'
    (OUT / (args.build + '_validation.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ['tests', 'source_asset_hashes']}, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
