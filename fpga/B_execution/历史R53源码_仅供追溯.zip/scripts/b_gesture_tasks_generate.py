"""Generate B-private constants and source wiring. No hardware access."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'fpga_b/gesture_tasks'
def packed(data): return f"{len(data)*8}'h{int.from_bytes(data,'little'):x}"
def main():
    caps=dict(board='B',revision='r50',protocol=1,max_classes=32,pose_slots=9,
        typed_tasks=[0,1,2,3,4,5,6],collision=True,legacy_loop=False,pages=[0,1,2,3],
        range_mv=[20,50,100,200,500,1200,3300],raw_center='visible_window_mean',
        gesture_stable_windows=2,gesture_interval_ms=200,rest_rearm=True,
        return_uart='GPIO_921600_8N1',teach=True,flash=True,
        status_schema=1,status_pages=[0,1,2,3,4],pose_query_bytes=13,local_uart_rx=False)
    data=json.dumps(caps,separators=(',',':')).encode()
    assert len(data)<=512
    rom=[0]*4096
    def status_json(obj,fields,slot):
        data=json.dumps(obj,separators=(',',':')).encode()
        assert len(data)<=512
        tokens=list(data)
        for key,(field,count,digits) in fields.items():
            start=data.index(('"'+key+'":').encode())+len(key)+3
            cursor=start
            for item in range(count):
                cursor=data.index(b'"',cursor)+1
                for k in range(digits):
                    tokens[cursor+k]=(field<<8)|(item*digits+digits-1-k)
                cursor+=digits+1
        rom[slot*512:slot*512+len(data)]=tokens
        return f'json_slot<=3\'d{slot};response_length<=10\'d{len(data)};'
    (D/'caps.vh').write_text(status_json(caps,{},0)+'\n')
    servo=dict(schema=1,kind='servo',ids=[1,2,3,4,5])
    fields={}
    for key,source in [('positions_hex','positions'),('speeds_hex','speeds'),('loads_raw_hex','loads'),('feedback_age_ms_hex','feedback_age_ms')]:
        servo[key]=['0000']*5;fields[key]=({'positions':1,'speeds':2,'loads':3,'feedback_age_ms':4}[source],5,4)
    for key,source,digits in [('online_mask_hex','online',2),('torque_mask_hex','torque',2),('torque_valid_mask_hex','torque_valid_mask',2),('feedback_valid_mask_hex','feedback_valid_mask',2),('fault_flags_hex','fault_flags',8)]:
        servo[key]='0'*digits;fields[key]=({'online':5,'torque':6,'feedback_valid_mask':7,'fault_flags':8,'torque_valid_mask':12}[source],1,digits)
    lines=['if(data_length==0 || arguments[7:0]==0)begin',status_json(servo,fields,1),
           'json_words0<=positions;json_words1<=speeds;json_loads<=loads;json_ages<=feedback_age_ms;',
           'json_online<=online;json_torque<=torque;json_valid<=feedback_valid_mask;json_faults<=fault_flags;json_torque_valid<=torque_valid_mask;',
           'end else begin','case(arguments[2:0])']
    for page in range(4):
        display=dict(schema=1,kind='display',page=page,range_mv_hex=['0000']*8,gain_q8_hex=['0000']*8,
                     custom_mask_hex='00',semantics='bipolar' if page<2 else 'unipolar',
                     centering=['visible_512_mean','zero','bottom_zero','bottom_zero'][page])
        fields={'range_mv_hex':(9,8,4),'gain_q8_hex':(10,8,4),'custom_mask_hex':(11,1,2)}
        lines += [f'3\'d{page+1}:begin',status_json(display,fields,page+2),'end']
    lines+=['default:reply(3);','endcase',
            'for(integer q=0;q<8;q=q+1)begin json_words0[q*16+:16]<=range_value(range_pages[{json_query_page,q[2:0]}]);json_words1[q*16+:16]<=gain_pages[{json_query_page,q[2:0]}];end',
            'json_custom<=custom_pages[{json_query_page,3\'d0}+:8];','end']
    (D/'status.vh').write_text('\n'.join(lines)+'\n')
    (D/'assets/query_tokens.hex').write_text(''.join(f'{x:04x}\n' for x in rom))
    adc=(ROOT/'fpga_b/ab_scope_v2/b_v2.adc').read_text()
    adc+='\n# Schematic v1.0 p3: SW15=R15; GPIO return candidate header33.\n'
    adc+='set_pin_assignment { display_sw } { LOCATION = R15; IOSTANDARD = LVCMOS33; PULLTYPE = NONE; }\n'
    adc+='set_pin_assignment { b_return_tx } { LOCATION = A11; IOSTANDARD = LVCMOS33; DRIVESTRENGTH = 8; PULLTYPE = NONE; }\n'
    (D/'b_tasks.adc').write_text(adc)
    sdc=(ROOT/'fpga_b/ab_scope_v2/wave_debug.sdc').read_text()
    sdc=sdc.replace('host_uart_tx scs_tx','host_uart_tx b_return_tx scs_tx').replace('rst_n host_uart_rx scs_rx','rst_n host_uart_rx scs_rx display_sw')
    (D/'b_tasks.sdc').write_text(sdc)
    print('Generated caps/status and candidate GPIO constraints')
if __name__=='__main__':main()
