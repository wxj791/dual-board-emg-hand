"""Decode GPIO UART capture independently of the RTL response formatter."""
from pathlib import Path
import binascii,struct,json,hashlib
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'artifacts/b_gesture_tasks'
def main():
    raw=bytes(int(x,16) for x in (OUT/'gpio_responses.hex').read_text().split());frames=[];offset=0
    while offset<len(raw):
        assert raw[offset:offset+2]==b'\xa5\x5a'
        ver,kind,seq,length,tick=struct.unpack_from('<BBHHI',raw,offset+2)
        end=offset+14+length;assert end<=len(raw)
        assert binascii.crc_hqx(raw[offset+2:end-2],65535)==struct.unpack_from('<H',raw,end-2)[0]
        p=raw[offset+12:end-2];schema,target,id,op,status,size=struct.unpack_from('<BBHHHH',p)
        assert ver==schema==1 and target==2 and kind==0x51 and status==0 and len(p)==10+size
        data=p[10:];decoded=json.loads(data) if op in (1,2) else data.hex()
        frames.append(dict(id=id,opcode=f'{op:04x}',length=size,data=decoded));offset=end
    assert [f['id'] for f in frames]==list(range(1,8))
    cap=frames[0]['data'];assert cap['revision']=='r50' and cap['collision'] and not cap['legacy_loop'] and cap['pose_query_bytes']==13
    state=bytes.fromhex(frames[3]['data']);assert len(state)==28 and state[19]==1 and state[20:22]==b'\x32\x00'
    pose=bytes.fromhex(frames[4]['data']);assert len(pose)==13 and pose[0]==0
    live=frames[5]['data'];assert live['ids']==[1,2,3,4,5] and live['feedback_valid_mask_hex']=='00'
    display=frames[6]['data'];assert display['page']==1 and display['range_mv_hex']==['0032']*8 and display['semantics']=='bipolar'
    queries=[json.loads(x) for x in (OUT/'query_readback.jsonl').read_text().splitlines()]
    assert queries[0]['positions_hex']==['01dc','0280','02c6','0191','03eb']
    assert queries[0]['feedback_age_ms_hex']==['0000','0001','00c7','00c8','ffff'] and queries[0]['torque_valid_mask_hex']=='1f'
    assert [q['page'] for q in queries[1:]]==[0,1,2,3]
    evidence=[OUT/'gpio_responses.hex',OUT/'query_readback.jsonl',Path(__file__).resolve()]
    report=dict(passed=True,bytes=len(raw),frames=frames,query_unit_snapshots=queries,input_hashes={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in evidence},hardware='NOT_RUN',three_endpoint_integration='NOT_RUN')
    (OUT/'gpio_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(f'PASS: {len(frames)} GPIO frames, exact CRC/target/schema/13-byte pose/live feedback/range queries')
if __name__=='__main__':main()
