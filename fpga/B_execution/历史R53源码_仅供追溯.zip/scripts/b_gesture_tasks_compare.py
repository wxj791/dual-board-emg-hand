"""Read-only Python reference comparison; never imports any hardware bus module."""
from pathlib import Path
import ast,json,hashlib,sys,math
ROOT=Path(__file__).resolve().parents[1];C=ROOT/'collision_detection';OUT=ROOT/'artifacts/b_gesture_tasks';D=ROOT/'fpga_b/gesture_tasks'
def main():
    tree=ast.parse((C/'together_run.py').read_text(encoding='utf-8'))
    names={'measured_fraction','shared_fraction','collision_load_limit'}
    namespace={'math':math}
    exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[]),str(C/'together_run.py'),'exec'),namespace)
    sys.path.insert(0,str(C))
    from load_model import ExcessLoad
    from percent_model import PercentModel
    from guard import Guard,Policy
    bank=json.loads((C/'models/percent_v5/rate_100.json').read_text());assets=json.loads((OUT/'collision_assets.json').read_text())
    params={p['id']:p for p in assets['params']};ids=[1,3,4,5]
    max_fraction=0;rounds=0;model_samples=0;pending=None
    for line in (OUT/'collision_trace.txt').read_text().splitlines():
        a=line.split()
        if a[0]=='R':pending=list(map(int,a[1:]))
        elif a[0]=='Q' and pending:
            now,elapsed,phase,previous,mask,*values=pending;initials=values[:4];positions=values[4:]
            states={i:dict(initial=initials[k],sample=dict(position=positions[k]),profile=dict(arrival_tolerance=8)) for k,i in enumerate(ids) if mask>>(i-1)&1}
            targets={i:params[i]['lower' if phase==1 else 'upper'] for i in states}
            if states:
                expected=namespace['shared_fraction'](states,targets,elapsed/1000,100,previous/65536)
                error=abs(int(a[1])/65536-expected);max_fraction=max(error,max_fraction);rounds+=1
                assert error<=3/65536,(pending,a,error)
            pending=None
        elif a[0]=='S':
            now,phase,lane,pos,load,upper,limit,ref,retired=map(int,a[1:]);i=lane+1
            if phase==0 or i==2:continue
            p=params[i];direction=1 if phase==1 else -1
            if i==1:direction=-direction
            # Startup lookup is checked by the boundary replay below; late samples
            # use the frozen directional envelope and exact integer model cells.
            model=PercentModel(bank['servos'][str(i)])
            if p['observed'][0]<=pos<=p['observed'][1] and upper!=1023:
                normal=model.predict(i,direction,220,pos,False)
                startup=model.predict(i,direction,220,pos,True)
                assert upper in (normal,startup),(a,normal,startup)
                expected_limit=namespace['collision_load_limit'](dict(hard_load=p['hard']),dict(normal_upper=upper,excess_margin=p['load_margin']))
                assert limit==expected_limit;model_samples+=1
    assert rounds>100 and model_samples>100
    records=[];cases=[]
    def sequence(i,loads,times,label):
        p=params[i];model=PercentModel(bank['servos'][str(i)]);direction=-1 if i==1 else 1
        candidates=[int(b)*32+16 for b in model.data['channels'][f'{i}:{direction}:220']['bins']]
        valid_positions=[x for x in candidates if p['observed'][0]<=x<=p['observed'][1] and abs(x-p['lower'])>8]
        pos=min(valid_positions,key=lambda x:model.predict(i,direction,220,x,False))
        upper=model.predict(i,direction,220,pos,False)
        detector=ExcessLoad(model,i,direction,220,margin=p['load_margin'],duration=p['hold_ms']/1000,allow_uncovered=True)
        guard=Guard(p['lower'],pos,Policy(p['hard'],tolerance=8,stall_seconds=10,motion_seconds=24,
                    hard_load_seconds=.03,emergency_load=300,check_voltage=False,position_min=p['bounds'][0],position_max=p['bounds'][1]),0)
        start=len(records)
        for k,(ms,value) in enumerate(zip(times,loads)):
            magnitude=int(value(upper) if callable(value) else value)
            evidence=detector.feed(ms/1000,1,pos,magnitude|1024)
            limit=namespace['collision_load_limit'](dict(hard_load=p['hard']),evidence)
            reason=guard.feed(ms/1000,pos,magnitude|1024,hard_load_limit=limit)
            hit=reason=='high_load' or evidence.get('reason')=='excess_load'
            records.append(dict(reset=k==0,id=i,ms=ms,position=pos,load=magnitude|1024,upper=int(upper),limit=limit,hit=int(hit)))
            if hit:break
        cases.append(dict(label=label,id=i,start=start,samples=len(records)-start,hit=records[-1]['hit']))
    for i in ids:
        margin=params[i]['load_margin'];hold=params[i]['hold_ms']
        high=lambda upper,m=margin:upper+m
        sequence(i,[high]*5,[0,hold//2,hold-1,hold,hold+1],'relative_threshold_duration')
        sequence(i,[high]*5,[0,10,61,61+hold//2,61+hold],'gap_over_50_resets')
        sequence(i,[lambda u,m=margin:u+m-1]*4,[0,20,40,60],'one_below_margin')
        sequence(i,[300],[0],'emergency_300_immediate')
        sequence(i,[299]*4,[0,15,29,30],'hard_persistence_30ms')
    (OUT/'guard_reference.json').write_text(json.dumps(dict(cases=cases,records=records),indent=2)+'\n')
    # 80-bit compact stimulus, MSBs padded. DUT comparisons use original refs.
    packed=[]
    for r in records:
        v=r['reset'];v=(v<<3)|(r['id']-1);v=(v<<16)|r['ms'];v=(v<<10)|r['position'];v=(v<<11)|r['load'];v=(v<<10)|r['upper'];v=(v<<10)|r['limit'];v=(v<<1)|r['hit'];packed.append(v)
    (OUT/'guard_vectors.hex').write_text(''.join(f'{v:020x}\n' for v in packed))
    (D/'guard_vector_count.vh').write_text(f'localparam integer GUARD_VECTORS={len(records)};\n')
    report=dict(passed=True,reference_rounds=rounds,model_samples=model_samples,max_fraction_error=max_fraction,
                max_goal_error_bound_counts=math.ceil(905*max_fraction+0.5),model_quantization_error=0,
                timestamp_resolution_ms=1,quantization_note='ms floor: an individual duration boundary can shift by less than 1 ms; Python float equality can differ at decimal boundaries',
                guard_cases=cases,reference_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [C/'together_run.py',C/'load_model.py',C/'guard.py',C/'models/percent_v5/rate_100.json']},hardware='NOT_RUN')
    (OUT/'python_comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
