"""Copy test-only bus/NOR models into B-owned paths and extend torque reads."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];D=ROOT/'fpga_b/gesture_tasks'
def main():
    s=(ROOT/'fpga_b/ab_scope_v2/b_v2_scs_model.v').read_text().replace('module b_v2_scs_model #(','module b_tasks_scs_model #(')
    s=s.replace('reg response_is_read;','reg response_is_read;reg response_is_torque,response_is_config;\n `include "fpga_b/gesture_tasks/collision_params.vh"\n wire [319:0] config_bytes=expected_config(response_wire_id-1);')
    s=s.replace('response_is_read ? 6\'d21 : 6\'d6','response_is_read ? (response_is_config?6\'d55:response_is_torque?6\'d7:6\'d21) : 6\'d6')
    s=s.replace("response_is_read ? 8'd17 : 8'd2", "response_is_read ? (response_is_config?8'd51:response_is_torque?8'd3:8'd17) : 8'd2")
    s=s.replace('5: selected_response_byte = response_wire_position[15:8];',
        "5: selected_response_byte = response_is_torque?{7'd0,torque_enabled[response_wire_id-1]}:response_wire_position[15:8];")
    s=s.replace('response_is_read <= 1\'b1;',"response_is_read <= 1'b1;response_is_torque<=packet_param[0]==40;response_is_config<=packet_param[0]==0 && packet_param[1]==49;")
    s=s.replace('            case (response_index)', '''            if(response_is_read && response_is_config && response_index>=5)begin
                selected_response_byte=response_index<45?config_bytes[(response_index-5)*8+:8]:response_index==53?8'd1:8'd0;
            end else case (response_index)''')
    s=s.replace("model_position            <= {16'h0505,16'h0404,16'h0303,16'h0202,16'h0101};", "model_position            <= {5{16'd512}};")
    (D/'b_tasks_scs_model.v').write_text(s)
    s=(ROOT/'fpga_b/ab_scope_v2/tb_b_v2_flash.sv').read_text()
    (D/'test_nor_flash.v').write_text(s[:s.index('module tb_b_v2_flash;')])
    print('Copied independent test bus and NOR model')
if __name__=='__main__':main()
