# Fresh-process physical hold repair, using the original SDC throughout.
# No cable, programming or hardware commands.
if {[catch {
set build_dir $::env(B_TASKS_BUILD_DIR)
cd $build_dir
import_db routed.db
# Hold-only exception for two late grid-data reset endpoints. They are
# overwritten before region_pipe[20] can make the native grid observable.
# tb_tasks_grid_reset injects FOUR unknown clocks at these exact bits and
# proves the 21-clock validity flush. No data path or recovery check is waived.
set reset_sdc [open grid_reset_only.sdc w]
puts $reset_sdc {set_false_path -hold -from [get_regs {pix_sync/sync_pipe[*]}] -to [get_regs {renderer/native_trace/edge_grid[18] renderer/native_trace/mid_grid[19]}]}
close $reset_sdc
# Runtime set_false_path commands are not retained by TD's timer startup;
# an additive SDC is required. Keep the original complete SDC loaded once.
read_sdc grid_reset_only.sdc
reset_path_margin -all
report_timing_summary -ep_num 30 -file before_hold_timing.rpt
# Mirrors the proven refresh-before-hold order in historical B r29.
# This changes physical delays only; it does not exempt any timing path.
fix_hold
reset_path_margin -all
export_db final_pre_refresh.db
import_db final_pre_refresh.db
reset_path_margin -all
report_area -io_info -file phy.area
report_timing_summary -ep_num 30 -file final_timing.rpt
check_timing -verbose -file timing_check.rpt
report_timing_exception -file timing_exceptions.rpt
report_clock_summary -file clocks.rpt
export_db routed.db
report_route_status -drc
set f [open final_timing.rpt r]
set timing [read $f]
close $f
foreach metric {SWNS STNS HWNS HTNS} {
 if {![regexp "$metric: +(-?\[0-9.\]+)ns" $timing unused value]} {error "Missing $metric"}
 if {$value < 0} {error "R50_REJECT $metric=$value"}
}
bitgen -bit fpga_b_gesture_tasks_r50.bit
puts B_GESTURE_TASKS_R50_TD_PASS
} err]} {puts stderr $err; exit 1}
exit
