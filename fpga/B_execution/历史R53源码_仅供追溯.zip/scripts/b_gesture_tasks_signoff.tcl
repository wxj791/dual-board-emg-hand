# Fresh-process STA/DRC only. No cable or programmer commands.
if {[catch {
set build_dir $::env(B_TASKS_BUILD_DIR)
cd $build_dir
import_db routed.db
reset_path_margin -all
report_timing_summary -ep_num 30 -file independent_timing.rpt
check_timing -verbose -file independent_timing_check.rpt
report_route_status -drc
set f [open independent_timing.rpt r]
set timing [read $f]
close $f
foreach metric {SWNS STNS HWNS HTNS} {
 if {![regexp "$metric: +(-?\[0-9.\]+)ns" $timing unused value]} {error "Missing $metric"}
 if {$value < 0} {error "B_TASKS_INDEPENDENT_REJECT $metric=$value"}
}
puts B_GESTURE_TASKS_R50_INDEPENDENT_STA_PASS
} err]} {puts stderr $err; exit 1}
exit
