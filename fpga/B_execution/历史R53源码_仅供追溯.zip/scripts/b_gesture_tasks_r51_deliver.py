"""Sign off one r51 build and create a new immutable candidate package."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import zipfile
from b_gesture_tasks_audit import rom_audit, timing

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/b_gesture_tasks'
TD=Path('E:/FPGA/TD_6.2.1_Engineer_168116/bin/td_commands_prompt.exe')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def valid_hashes(r):return bool(r.get('input_hashes')) and all(sha(ROOT/p)==h for p,h in r['input_hashes'].items())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--attempt',default='r51_frame_mean_02');ap.add_argument('--release',action='store_true');a=ap.parse_args()
    td=OUT/('td_'+a.attempt)
    result=read(OUT/('build_'+a.attempt+'_result.json'))
    assert result['exit_code']==0 and result['sources_unchanged'] and result['bit_exists'],result
    log=OUT/('signoff_'+a.attempt+'.log')
    with log.open('w') as f:
        subprocess.run([TD.as_posix(),(ROOT/'scripts/b_gesture_tasks_signoff.tcl').as_posix()],cwd=td,
                       env=dict(os.environ,B_TASKS_BUILD_DIR=td.as_posix()),stdout=f,stderr=subprocess.STDOUT,check=True)
    build=(OUT/('build_'+a.attempt+'.log')).read_text(errors='replace');signoff=log.read_text(errors='replace')
    r=dict(version='r51',attempt=a.attempt,hardware='NOT_RUN',three_endpoint_integration='NOT_RUN')
    r['timing_ns'],r['timing_passed']=timing(td/'final_timing.rpt')
    r['independent_timing_ns'],r['independent_timing_passed']=timing(td/'independent_timing.rpt')
    r['timing_matches']=r['timing_ns']==r['independent_timing_ns']
    r['timing_coverage_passed']=all(all(re.search(x,(td/n).read_text()) for x in
        [r'STA coverage\s*:\s*100\.00%',r'Confidence\s*:\s*Routed',r'Check Corner\s*:\s*Both \(Slow and Fast\)'])
        for n in ['final_timing.rpt','independent_timing.rpt'])
    r['errors']=re.findall(r'^.*(?:\bERROR\b|CRITICAL-WARNING|No objects matched|Oops!|Undriven pin:).*$',build+'\n'+signoff,re.M)
    r['drc_passed']=all(s in build and s in signoff for s in ['No multi-drive.','All clock nets do not utilize local routing resource.','No abnormal timing path.'])
    r['constraints_passed']=True
    for name in ['timing_check.rpt','independent_timing_check.rpt']:
        categories=dict(re.findall(r'checking ([^\n(]+)\((\d+)\) \((?:HIGH|MEDIUM)\)',(td/name).read_text()))
        r[name]=categories
        required=['no clock','clock definition','invalid constraint','pll/clock buffer clock constraints','combinational loops','soft fifo timing exception constraints','no path constraints','shadowed/ignored timing exception constraints','no output delay','partial output delay','abnormal input delay']
        r['constraints_passed'] &= all(categories.get(k)=='0' for k in required)
    manifest=read(OUT/(a.attempt+'_build_inputs.json'));parent=read(OUT/'r50_34_signoff_build_inputs.json')
    r['source_matches_build']=all(sha(ROOT/p)==h for p,h in manifest.items())
    extra='fpga_b/gesture_tasks/b_tasks_mean_multicycle.sdc'
    r['changed_build_inputs']=[p for p in set(parent)|set(manifest) if manifest.get(p)!=parent.get(p)]
    r['change_scope_passed']=set(manifest)==set(parent)|{extra} and set(r['changed_build_inputs'])=={
        'fpga_b/gesture_tasks/b_v2_native_trace.v','fpga_b/gesture_tasks/b_v2_ui_r48_renderer.v',extra}
    options=read(OUT/(a.attempt+'_build_options.json'))
    r['build_recipe_passed']=sha(td/'build_recipe.tcl')==options['recipe_sha256']==sha(ROOT/options['recipe_source']) and options.get('recipe_source')=='scripts/b_gesture_tasks_build_r50.tcl' and not options.get('resume_mapped') and not options.get('resume_routed')
    commands=[s.strip() for s in (ROOT/extra).read_text().splitlines() if s.strip() and not s.startswith('#')]
    endpoints='-from [get_regs {renderer/mean_lane* renderer/mean_sum*}] -to [get_regs {renderer/mean_sum*}]'
    r['mean_multicycle_passed']=commands==['set_multicycle_path -setup 3 '+endpoints,'set_multicycle_path -hold 2 '+endpoints] and manifest[extra]==sha(ROOT/extra)
    r['mean_multicycle_scope']='Only lane/sum-source -> sum registers; pair-data and other pixel paths remain single-cycle; setup=3, hold=2.'
    r['added_grid_reset_exception']=False
    r['protected_changed']=[p for p,h in read(OUT/'r48_protected.json').items() if sha(ROOT/p)!=h]
    pins=re.findall(r'set_pin_assignment\s*\{\s*([^}]+?)\s*\}\s*\{\s*LOCATION\s*=\s*(\w+)',(ROOT/'fpga_b/gesture_tasks/b_tasks.adc').read_text())
    r['pins_passed']=len(pins)==len(set(ball for _,ball in pins))
    r['roms']=rom_audit(td);r['rom_passed']=all(v['passed'] for v in r['roms'].values())
    targeted=[]
    for name in ['display','history_top','grid_reset','frame_mean','mean_multicycle']:
        report=read(OUT/('verification_tb_tasks_'+name+'.json'))
        assert len(report['tests'])==1
        test=report['tests'][0]
        targeted.append(dict(name=test['name'],passed=report['passed'] and test['passed'] and valid_hashes(test),seconds=test['seconds']))
    r['targeted_tests']=targeted;r['targeted_tests_passed']=all(t['passed'] for t in targeted)
    replay=read(OUT/'r51_frame_mean_02_validation_20261101/old_a_replay.json')
    r['old_a_replay_passed']=replay['passed'] and valid_hashes(replay)
    previous=read(OUT/'r50_release/verification_all.json')
    unchanged_names={'tb_tasks_'+s for s in ['collision','control','scale','servo','collision_uart','guards','flash','mailbox']}
    inherited=[t for t in previous['tests'] if t['name'] in unchanged_names]
    r['unchanged_tests']=[dict(name=t['name'],passed=t['passed'] and valid_hashes(t),source='r50 unchanged dependencies') for t in inherited]
    r['unchanged_tests_passed']=len(inherited)==8 and all(t['passed'] for t in r['unchanged_tests'])
    r['scope_note']='The r50 full command/GPIO test and artificial preview were not rerun; only two display RTL files changed. Current display/history/grid/frame tests and historical A replay were rerun. No claim of full three-endpoint or hardware verification.'
    r['resources']={k:int(v) for k,v in re.findall(r'^#(\w+)\s+(\d+)\s+out of',(td/'phy.area').read_text(),re.M)}
    r['resources_passed']=all(r['resources'].get(k,n+1)<=n for k,n in dict(lut=19600,reg=19600,bram=64,bram32k=16,dsp=29).items())
    bit=td/'fpga_b_gesture_tasks_r50.bit';r['bit_bytes']=bit.stat().st_size;r['bit_sha256']=sha(bit)
    checks=['timing_passed','independent_timing_passed','timing_matches','timing_coverage_passed','drc_passed','constraints_passed','source_matches_build','change_scope_passed','build_recipe_passed','mean_multicycle_passed','pins_passed','rom_passed','targeted_tests_passed','old_a_replay_passed','unchanged_tests_passed','resources_passed']
    r['passed']=all(r[k] for k in checks) and not r['errors'] and not r['protected_changed'] and r['bit_bytes']>600000
    report_path=OUT/(a.attempt+'_validation.json');report_path.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({k:v for k,v in r.items() if k!='roms'},indent=2),flush=True)
    if a.release:
        assert r['passed'],'r51 release gates failed'
        release=OUT/'r51_release';release.mkdir(exist_ok=False)
        shutil.copy2(bit,release/'fpga_b_gesture_tasks_r51.bit')
        files=[report_path,log,OUT/('build_'+a.attempt+'.log'),OUT/(a.attempt+'_build_inputs.json'),OUT/(a.attempt+'_build_options.json')]
        files += [td/n for n in ['build_recipe.tcl','final_timing.rpt','independent_timing.rpt','timing_check.rpt','independent_timing_check.rpt','timing_exceptions.rpt','phy.area','clocks.rpt']]
        files += [OUT/('verification_tb_tasks_'+n+'.json') for n in ['display','history_top','grid_reset','frame_mean','mean_multicycle']]
        files += [OUT/('tb_tasks_'+n+'.log') for n in ['display','history_top','grid_reset','frame_mean','mean_multicycle']]
        files += [ROOT/extra]
        files += list((OUT/'r51_frame_mean_02_validation_20261101').glob('*.json'))+list((OUT/'r51_frame_mean_02_validation_20261101').glob('*.log'))
        for f in files:shutil.copy2(f,release/f.name)
        shutil.copy2(ROOT/'docs/B_GESTURE_TASKS_R51_FRAME_MEAN.md',release/'B_GESTURE_TASKS_R51_FRAME_MEAN.md')
        snapshot={ROOT/p for p in manifest}
        snapshot.update((ROOT/'scripts').glob('b_gesture_tasks_*.py'));snapshot.update((ROOT/'scripts').glob('b_gesture_tasks_*.tcl'))
        snapshot.update((ROOT/'fpga_b/gesture_tasks').rglob('*.sv'))
        snapshot.update(ROOT/p for p in replay['input_hashes'])
        snapshot.update((OUT/'r48_protected.json',ROOT/'scripts/b_ab_v2_ui_r48_audit.py'))
        with zipfile.ZipFile(release/'sources_and_tools.zip','w',zipfile.ZIP_DEFLATED) as z:
            for f in sorted(snapshot):z.write(f,f.relative_to(ROOT).as_posix())
        (release/'source_snapshot_sha256.json').write_text(json.dumps({f.relative_to(ROOT).as_posix():sha(f) for f in sorted(snapshot)},indent=2)+'\n')
        text=f'''# B r51 frame-mean candidate

1080p60 / 148.5MHz. Replaces the differential sliding sum and its separate RAM with a zero-based 512-point scan of the existing history during vertical blanking. Layout, range semantics and interface unchanged. r50 user-reported center drift is the motivation; r51 hardware confirmation is still pending. [Chinese handoff](B_GESTURE_TASKS_R51_FRAME_MEAN.md).

BIT: [fpga_b_gesture_tasks_r51.bit](fpga_b_gesture_tasks_r51.bit), {r['bit_bytes']} bytes. SHA256: `{r['bit_sha256']}`.

Five focused tests (including 10240 multicycle stability assertions), a 602-wave historical A replay, and eight inherited tests with unchanged dependencies pass. See [{report_path.name}]({report_path.name}) for exact scope, source hashes, routed timing, independent STA and ROM checks. The scanner lane/sum -> sum paths use setup=3/hold=2 constraints matching their three-clock write interval; all other pixel data paths retain single-cycle checks. No added grid-reset exception. This is not a rerun of every r50 test.

No cable access, programming, servo movement or three-endpoint integration. Keep servos disconnected for display confirmation. r48 and r50 are preserved. Hardware: NOT_RUN.
'''
        (release/'README.md').write_text(text,encoding='utf-8')
        (release/'SHA256SUMS').write_text(''.join(sha(f)+'  '+f.relative_to(release).as_posix()+'\n' for f in sorted(release.rglob('*')) if f.is_file() and f.name!='SHA256SUMS'))
    return 0 if r['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
