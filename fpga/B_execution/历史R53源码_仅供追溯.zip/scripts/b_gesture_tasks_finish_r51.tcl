# Attach only the scanner's proven clock-enable multicycle constraints.
# Never reread the base SDC or duplicate its clocks. No hardware access.
if {[catch {
set build_dir $::env(B_TASKS_BUILD_DIR)
set root $::env(B_TASKS_ROOT)
cd $build_dir
import_db $::env(B_TASKS_PARENT_DB)
read_sdc [file join $root fpga_b gesture_tasks b_tasks_mean_multicycle.sdc]
reset_path_margin -all
phys_opt -post_route -effort high
fix_hold
reset_path_margin -all
write_verilog gate.v
report_timing_summary -ep_num 30 -file final_timing.rpt
check_timing -verbose -file timing_check.rpt
report_timing_exception -file timing_exceptions.rpt
report_clock_summary -file clocks.rpt
report_area -io_info -file phy.area
report_route_status -drc
export_db routed.db
set f [open final_timing.rpt r]
set timing [read $f]
close $f
foreach metric {SWNS STNS HWNS HTNS} {
 if {![regexp "$metric: +(-?\[0-9.\]+)ns" $timing unused value]} {error "Missing $metric"}
 if {$value < 0} {error "R51_REJECT $metric=$value"}
}
bitgen -bit fpga_b_gesture_tasks_r50.bit
puts B_GESTURE_TASKS_R50_TD_PASS
} err]} {puts stderr $err; exit 1}
exit
