`timescale 1ns/1ps
module tb_tasks_minimal_text;
 reg clk=0;always #5 clk=~clk;
 reg rst=0;reg [2:0] page=0;reg [7:0] custom=0;
 reg [127:0] ranges=0,centers=0;reg [319:0] snapshot=0;
 reg frozen=0,armed=0,stale=0,clip=0;
 integer i,j,checks=0;reg [15:0] values[0:7];
 b_v2_renderer d(.clk(clk),.rst_n(rst),.sample_valid(1'b0),.sample_data(128'd0),
  .servo_snapshot(snapshot),.history_clear(1'b0),.freeze(frozen),.page(page),
  .gain(16'd256),.sample_rate(16'd1000),.class_id(16'd0),.generation(16'd0),
  .mapped_action(16'd0),.mapped_pose(16'd0),.channel_gains({8{16'd256}}),
  .ranges(ranges),.custom(custom),.armed(armed),.saturated(clip),.link_stale(stale));
 reg [9:0] tx=0;reg [8:0] ty=0;
 task character(input integer col,input integer yy,input [6:0] expected);begin
  @(negedge clk);tx=col*8;ty=yy;repeat(10)@(negedge clk);
  if(d.character3!==expected)$fatal(1,"text col=%d y=%d got=%d expected=%d",col,yy,d.character3,expected);
  checks=checks+1;
 end endtask
 function [15:0] bcd(input integer value);begin
  bcd=((value/1000)%10)*4096+((value/100)%10)*256+((value/10)%10)*16+value%10;
 end endfunction
 initial begin
  values[0]=20;values[1]=50;values[2]=100;values[3]=200;
  values[4]=500;values[5]=1200;values[6]=3300;values[7]=1200;
  for(i=0;i<8;i=i+1)begin ranges[i*16+:16]=values[i];centers[i*16+:16]=1000+i*300;end
  for(i=0;i<5;i=i+1)snapshot[16+i*16+:16]=476+i*100;
  snapshot[256+:5]=31;snapshot[261+:5]=15;snapshot[266+:5]=31;snapshot[289+:5]=31;
  repeat(5)@(negedge clk);rst=1;
  force d.x=tx;force d.y=ty;force d.centers=centers;
  force d.flow_active=1;force d.native_clip=0;
  force d.number_update=1;@(negedge clk);force d.number_update=0;
  repeat(300)@(negedge clk);
  for(i=0;i<8;i=i+1)begin
   if(d.centers_bcd[i*16+:16]!==bcd(1000+i*300))$fatal(1,"center BCD %d",i);
   if(d.ranges_bcd[i*16+:16]!==bcd(values[i]))$fatal(1,"range BCD %d",i);
   character(1,48+i*40,48+i);
   for(j=0;j<4;j=j+1)character(4+j,48+i*40,48+((values[i]/(j==0?1000:j==1?100:j==2?10:1))%10));
   for(j=0;j<4;j=j+1)character(4+j,64+i*40,48+(((1000+i*300)/(j==0?1000:j==1?100:j==2?10:1))%10));
  end
  custom=128;character(4,328,"C");character(5,328,"U");character(6,328,"S");character(7,328,"T");
  for(i=0;i<5;i=i+1)begin
   if(d.positions_bcd[i*16+:16]!==bcd(476+i*100))$fatal(1,"position BCD %d",i);
   character(2,384+i*16,49+i);
   for(j=0;j<4;j=j+1)character(8+j,384+i*16,48+(((476+i*100)/(j==0?1000:j==1?100:j==2?10:1))%10));
   character(17,384+i*16,"1");character(23,384+i*16,i==4?"0":"1");
  end
  snapshot=0;character(8,384,"?");character(17,384,"0");character(23,384,"?");
  character(5,16,"0");character(14,16,"1");character(23,16,"0");character(30,16,"0");
  frozen=1;stale=1;clip=1;armed=1;
  character(5,16,"1");character(14,16,"0");character(23,16,"1");character(30,16,"1");
  for(i=0;i<4;i=i+1)begin page=i;character(0,0,i==0?"R":i==1?"F":i==2?"F":"S");end
  page=1;character(0,64," ");character(0,32," ");character(0,368," ");character(0,464," ");
  $display("PASS: %0d character checks, all 13 decimal values, seven ranges, CUSTOM, feedback/torque unknown and status flags",checks);$finish;
 end
 initial begin #1000000;$fatal(1,"watchdog");end
endmodule
