`timescale 1ns/1ps
module tb_tasks_collision_uart;
 reg clk=0;always #20.833333 clk=~clk;
 reg rst=0,req=0,event_ready=1;reg [2:0] op=0;reg [15:0] id=0;wire ready,idle,ev;
 wire [15:0] ei,es;wire tx,en,rx;wire [4:0] torque,mt,active,retired,online,valid,known;
 wire [79:0] ages;wire [7:0] motion;reg [4:0] drop=0;reg [15:0] load=10;
 reg [15:0] last_id=65535,last_status=0;integer events=0,config_reads=0;
 b_tasks_servo #(.POLL_CLKS(100),.TIMEOUT_CLKS(30000),.GAP_CLKS(50),.MS_CLKS(1000)) d(
  .clk(clk),.rst_n(rst),.servo_rx(rx),.servo_tx(tx),.servo_tx_enable(en),
  .req_valid(req),.req_ready(ready),.req_op(op),.req_id(id),.req_arg(16'd0),
  .event_valid(ev),.event_ready(event_ready),.event_id(ei),.event_status(es),.idle(idle),
  .query_pose(4'd0),.flash_init_done(1'b1),.flash_available(1'b1),.flash_load_valid(1'b0),
  .flash_load_group(4'd0),.flash_load_positions(50'd0),.flash_save_done(1'b0),.flash_save_ok(1'b0),
  .online(online),.torque(torque),.torque_valid_mask(known),.feedback_age_ms(ages),.feedback_valid_mask(valid),
  .motion_state(motion),.active_mask(active),.retired_mask(retired));
 b_tasks_scs_model m(.clk(clk),.rst_n(rst),.master_tx(tx),.master_tx_enable(en),.servo_rx(rx),
  .stall(1'b0),.feedback_load(load),.fault_drop_mask(drop),.fault_bad_checksum_mask(5'd0),
  .response_delay_clks(16'd25),.inject_foreign_once(1'b0),.torque_enabled(mt));
 always @(posedge clk)begin
  if(ev && event_ready)begin last_id=ei;last_status=es;events=events+1;$display("event %d status %d",ei,es);end
  if(motion==2 && mt[1])$fatal(1,"collision enabled thumb");
  if(d.collision_inflight && d.done && d.collision_command==5 && d.result==0)config_reads=config_reads+1;
 end
 task command(input [2:0] c,input [15:0] n);begin
  @(negedge clk);op=c;id=n;req=1;#1;while(!ready)@(negedge clk);@(negedge clk);req=0;
 end endtask
 task completion(input [15:0] n,input [15:0] s);begin
  wait(last_id==n);if(last_status!=s)$fatal(1,"event %d status %d expected %d",n,last_status,s);
  repeat(5)@(negedge clk);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst=1;wait(idle);
  // Simulate the saved starting pose; all transport uses real 1 Mbaud packets.
  @(negedge clk);m.model_position={16'd711,16'd401,16'd710,16'd640,16'd476};
  wait(online==31);command(4,101);wait(d.collision.phase==1 && d.collision.state==12);load=300;
  wait(retired[0]);#1;
  if(active!=5'b11100 || mt[0] || config_reads!=5)$fatal(1,"retire/config integration");
  if(valid[1] && ages[31:16]>=200)$fatal(1,"stale feedback marked valid");
  event_ready=0;command(3,102);wait(d.collision_complete);repeat(10)@(negedge clk);
  if(!ev || ei!=101 || es!=7)$fatal(1,"backpressure overwrote cancellation");
  event_ready=1;completion(101,7);completion(102,0);
  if(mt!=0 || torque!=0 || known!=31)$fatal(1,"STOP verified release");
  load=10;force m.config_bytes=320'd0;
  command(4,103);completion(103,8);release m.config_bytes;
  if(mt!=0)$fatal(1,"configuration failure enabled torque");
  // An off readback timeout must fail the STOP even when cached torque is zero.
  command(4,104);wait(d.collision.phase==1);command(3,105);drop=1;
  completion(104,7);completion(105,7);
  $display("PASS: collision over real UART, 49-byte EEPROM identity, ID2 off, per-lane retirement, STOP cancellation/final and failed readback");$finish;
 end
 initial begin #200000000;$fatal(1,"watchdog state=%d phase=%d motion=%d faults=%h",d.collision.state,d.collision.phase,motion,d.fault_flags);end
endmodule
