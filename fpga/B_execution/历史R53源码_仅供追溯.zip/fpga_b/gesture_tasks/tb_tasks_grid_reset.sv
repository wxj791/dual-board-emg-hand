`timescale 1ns/1ps
// Exact endpoints named by the hold-only reset exception. Functional grid
// data/clock paths and all recovery checks remain constrained.
module tb_tasks_grid_reset;
 reg clk=0;always #3.367003 clk=~clk;
 reg rst_n=0;reg [11:0] v=194;
 wire [23:0] rgb;wire active,clipped;
 pcs_native_trace d(.clk(clk),.rst_n(rst_n),.sample_valid(1'b0),
  .sample_data(128'd0),.write_ptr(10'd0),.view_base(10'd0),.raw_page(1'b0),.mean_read(1'b0),.mean_even_addr(9'd0),.mean_odd_addr(9'd0),
  .centers(128'd0),.ranges({8{16'd1200}}),.gains({8{16'd256}}),.custom(8'd0),
  .wave_valid(1'b0),.view_commit(1'b0),.history_clear(1'b0),.clipped(clipped),
  .h(12'd500),.v(v),.sample_index(9'd3),.sample_phase(5'd1),.rgb(rgb),.active(active));
 integer scene,cycle;reg [23:0] expected;
 initial begin
  for(scene=0;scene<3;scene=scene+1)begin
   rst_n=0;repeat(5)@(negedge clk);
   case(scene)
    0:begin v=194;expected=24'h203044;end
    1:begin v=149;expected=24'h304058;end
    2:begin v=200;expected=24'h080c18;end
   endcase
   // Model an adversarial unknown value lasting FOUR clocks after reset
   // release, rather than assuming a 30ps removal miss resolves immediately.
   force d.edge_grid[18]=1'bx;force d.mid_grid[19]=1'bx;
   rst_n=1;
   for(cycle=1;cycle<=40;cycle=cycle+1)begin
    @(negedge clk);
    if(cycle==4)begin release d.edge_grid[18];release d.mid_grid[19];end
    if(cycle<=21 && active!==0)$fatal(1,"grid became observable before validity flush");
    if(cycle>=22 && (active!==1 || rgb!==expected))
     $fatal(1,"reset exception affects active pixel scene=%0d cycle=%0d rgb=%h",scene,cycle,rgb);
   end
  end
  $display("PASS: exact two late grid reset endpoints tolerate four unknown clocks; 21-clock validity flush prevents all visible corruption in mid/edge/background cases");$finish;
 end
 initial begin #10000;$fatal(1,"grid reset watchdog");end
endmodule
