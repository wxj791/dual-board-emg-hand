`timescale 1ns/1ps
module tb_tasks_collision;
 reg clk=0;always #5 clk=~clk;reg rst=0,start=0,stop=0;wire running,done;wire [15:0] status;
 wire bv;wire [2:0] lane,cmd;wire [9:0] goal;wire [4:0] active,retired;wire [31:0] faults;
 reg ready=1,fv=0,ok=1;reg [15:0] pos=0,load=0;reg [7:0] trq=0;reg [391:0] cfg=0;
 reg [15:0] positions[0:4];reg [4:0] torque=31;reg [391:0] configs[0:4];
 reg [7:0] delay_count=0;reg [2:0] saved_lane,saved_cmd;reg [9:0] saved_goal;
 reg contacts=0,config_fault=0,feedback_fault=0;integer requests=0,goals=0,phases=0,retire_events=0;
 reg [1:0] last_phase=0;reg [4:0] old_retired=0;integer i,f;
 `include "fpga_b/gesture_tasks/collision_params.vh"
 b_tasks_collision #(.MS_CLKS(200)) d(.clk(clk),.rst_n(rst),.start(start),.stop(stop),
  .running(running),.done(done),.status(status),.bus_valid(bv),.bus_ready(ready),.bus_lane(lane),.bus_command(cmd),.bus_target(goal),
  .feedback_valid(fv),.feedback_ok(ok),.feedback_position(pos),.feedback_load(load),.feedback_error(8'd1),
  .feedback_temperature(8'd25),.feedback_torque(trq),.feedback_config(cfg),.active_mask(active),.retired_mask(retired),.fault_flags(faults));
 always @(posedge clk)begin
  fv<=0;
  if(bv && ready)begin
   saved_lane<=lane;saved_cmd<=cmd;saved_goal<=goal;delay_count<=25;ready<=0;requests=requests+1;
   if(lane==1 && (cmd==3 || cmd==4))$fatal(1,"thumb enabled or given goal");
  end
  if(delay_count!=0)begin
   delay_count<=delay_count-1;
   if(delay_count==1)begin
    fv<=1;ready<=1;ok<=!feedback_fault;pos<=positions[saved_lane];trq<={7'd0,torque[saved_lane]};
    cfg<=configs[saved_lane]^(config_fault?392'd1:392'd0);load<=10;
    if(saved_cmd==4)begin positions[saved_lane]<=saved_goal;goals=goals+1;end
    if(saved_cmd==3)torque[saved_lane]<=1;
    if(saved_cmd==2)torque[saved_lane]<=0;
    if(contacts && saved_cmd==1 && d.state==12 && d.phase!=0 &&
       ((saved_lane==0 && d.now_ms>1700) || (saved_lane==2 && retired[0]) ||
        (saved_lane==3 && retired[2]) || (saved_lane==4 && retired[3])))load<=300;
   end
  end
  if(d.sample_event)$fdisplay(f,"S %d %d %d %d %d %d %d %d %d",d.now_ms,d.phase,d.sample_lane,d.position_hold,d.load_hold[9:0],d.normal_upper,d.load_limit,d.reference_q16,retired);
  if(d.state==9 && running)$fdisplay(f,"R %d %d %d %d %d %d %d %d %d %d %d %d %d",d.now_ms,d.elapsed,d.phase,d.reference_q16,d.pending_mask,d.initials[0],d.initials[2],d.initials[3],d.initials[4],d.position[0],d.position[2],d.position[3],d.position[4]);
  if(d.state==12 && d.lane==0 && ready)$fdisplay(f,"Q %d",d.reference_q16);
  if(d.phase!=last_phase)begin phases=phases+1;last_phase=d.phase;end
  if(retired!=old_retired)begin
   retire_events=retire_events+1;old_retired=retired;
   if((retired & torque)!=0)$fatal(1,"retired motor not off");
  end
  if(active[1])$fatal(1,"thumb in active mask");
 end
 task run_start;begin @(negedge clk);start=1;@(negedge clk);start=0;wait(running);end endtask
 initial begin
  for(i=0;i<5;i=i+1)begin positions[i]=i==1?640:upper(i);configs[i]={8'd1,64'd0,expected_config(i)};end
  f=$fopen("artifacts/b_gesture_tasks/collision_trace.txt","w");
  repeat(5)@(negedge clk);rst=1;contacts=1;run_start;wait(done);#1;
  if(status!=0 || retired!=5'b11101 || torque!=0 || phases<2 || goals<500 || retire_events!=4)$fatal(1,"continuous collision totals status=%d retired=%b phases=%d events=%d faults=%h lane=%d",status,retired,phases,retire_events,faults,d.lane);
  // Configuration mismatch must fail before torque enable; STOP cancels safely.
  config_fault=1;run_start;wait(done);#1;if(status!=8 || torque!=0)$fatal(1,"EEPROM identity guard");config_fault=0;
  contacts=0;run_start;wait(d.phase==1);stop=1;wait(done);#1;if(status!=7 || torque!=0)$fatal(1,"STOP release");stop=0;
  feedback_fault=1;run_start;wait(done);#1;if(status!=7)$fatal(1,"missing off verification");
  $fclose(f);
  $display("PASS: prepare_upper, continuous shared lower/upper phases, four sequential retire+verified off, ID2 always off, exact EEPROM mismatch, STOP and feedback fault; packets=%d goals=%d",requests,goals);$finish;
 end
 initial begin #50000000;$fatal(1,"watchdog state=%d ms=%d phase=%d active=%b pending=%b",d.state,d.now_ms,d.phase,active,d.pending_mask);end
endmodule
