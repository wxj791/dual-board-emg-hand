`timescale 1ns/1ps
module tb_tasks_servo;
 reg clk=0;always #5 clk=~clk;reg rst=0,req=0;reg [2:0] op=0;reg [15:0] id=0,arg=0;
 wire ready,idle,ev;wire [15:0] ei,es;wire tx,en,rx;wire [4:0] online,torque,mt;
 wire [8:0] valid;reg load_valid=0;reg [3:0] load_group=8;reg [49:0] load_pos={5{10'd600}};
 wire save;wire [3:0] sg;wire [49:0] sp;reg sd=0,so=1,auto_flash=1;
 reg drop_torque=0,stall=0;reg [4:0] drop=0;wire [49:0] qp;wire qv;
 wire [7:0] motion;wire [31:0] faults;integer events=0;reg [15:0] last_id=65535,last_status;
 b_tasks_servo #(.POLL_CLKS(100),.TIMEOUT_CLKS(30000),.GAP_CLKS(50)) d(
  .clk(clk),.rst_n(rst),.servo_rx(rx),.servo_tx(tx),.servo_tx_enable(en),
  .req_valid(req),.req_ready(ready),.req_op(op),.req_id(id),.req_arg(arg),
  .event_valid(ev),.event_ready(1'b1),.event_id(ei),.event_status(es),.idle(idle),
  .query_pose(4'd8),.query_valid(qv),.query_positions(qp),
  .flash_init_done(1'b1),.flash_available(1'b1),.flash_load_valid(load_valid),.flash_load_group(load_group),.flash_load_positions(load_pos),
  .flash_save_req(save),.flash_save_group(sg),.flash_save_positions(sp),.flash_save_done(sd),.flash_save_ok(so),
  .online(online),.torque(torque),.pose_valid(valid),.motion_state(motion),.fault_flags(faults));
 b_tasks_scs_model m(.clk(clk),.rst_n(rst),.master_tx(tx),.master_tx_enable(en),.servo_rx(rx),
  .stall(stall),.feedback_load(16'd10),.fault_drop_mask(drop),.fault_bad_checksum_mask(5'd0),
  .response_delay_clks(16'd25),.inject_foreign_once(1'b0),.torque_enabled(mt));
 always @(posedge clk)begin if(auto_flash)sd<=save;if(ev)begin last_id=ei;last_status=es;events=events+1;$display("event %d status %d",ei,es);end end
 task command(input [2:0] c,input [15:0] a,input [15:0] n);begin
  @(negedge clk);op=c;arg=a;id=n;req=1;#1;while(!ready)@(negedge clk);@(negedge clk);req=0;
 end endtask
 task completion(input [15:0] n,input [15:0] s);begin
  wait(last_id==n);if(last_status!=s)$fatal(1,"event %d status %d wanted %d",n,last_status,s);repeat(5)@(negedge clk);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst=1;wait(idle);if(mt!=0)$fatal(1,"startup not off");
  wait(online==31);command(1,8,1);completion(1,0);if(!valid[8] || !qv || qp!=sp)$fatal(1,"slot8 save/query");
  so=0;command(1,0,2);completion(2,7);if(valid[0])$fatal(1,"failed flash became valid");so=1;
  @(negedge clk);load_valid=1;@(negedge clk);load_valid=0;
  command(2,8,3);completion(3,0);if(mt!=31)$fatal(1,"pose torque");
  command(3,0,4);completion(4,0);if(mt!=0 || torque!=0)$fatal(1,"STOP readback");
  // STOP preempts a running pose and returns distinct cancellation + final.
  stall=1;command(2,8,5);wait(en);repeat(20)@(negedge clk);command(3,0,6);
  completion(5,7);completion(6,0);if(mt!=0)$fatal(1,"preempt off");stall=0;
  // Missing off verification must never report success.
  drop=5'b00001;command(3,0,7);completion(7,7);
  drop=0;wait(online==31);auto_flash=0;sd=0;
  command(1,1,8);wait(save);command(3,0,9);completion(8,7);completion(9,0);
  if(idle)$fatal(1,"new operation accepted during unfinished Flash");
  @(negedge clk);sd=1;@(negedge clk);sd=0;repeat(5)@(negedge clk);
  if(!valid[1] || d.poses[1]!=sp)$fatal(1,"Flash completion lost after STOP");
  $display("PASS: shared SCS engine, five torque readbacks, nine-slot capture/Flash failure/pose feedback, STOP cancellation and missing feedback failure");$finish;
 end
 initial begin #100000000;$fatal(1,"watchdog state=%d lane=%d",d.state,d.lane);end
endmodule
