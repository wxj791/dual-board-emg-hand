`timescale 1ns/1ps
module tb_tasks_guards;
 reg clk=0;always #5 clk=~clk;reg rst=0;
 `include "fpga_b/gesture_tasks/guard_vector_count.vh"
 reg [79:0] vectors[0:GUARD_VECTORS-1];reg [79:0] row;integer n,lane,ms,wrap,base;
 b_tasks_collision d(.clk(clk),.rst_n(rst),.start(1'b0),.stop(1'b0),.bus_ready(1'b0),
  .feedback_valid(1'b0),.feedback_ok(1'b1),.feedback_position(16'd0),.feedback_load(16'd0),
  .feedback_error(8'd0),.feedback_temperature(8'd25),.feedback_torque(8'd0),.feedback_config(392'd0));
 initial begin
  $readmemh("artifacts/b_gesture_tasks/guard_vectors.hex",vectors);
  repeat(5)@(negedge clk);rst=1;
  for(wrap=0;wrap<2;wrap=wrap+1)begin
  base=wrap?65520:1000;
  for(n=0;n<GUARD_VECTORS;n=n+1)begin
   @(negedge clk);row=vectors[n];lane=row[60:58];ms=row[57:42];
   d.running=1;d.state=13;d.phase=1;d.lane=lane;d.pending_mask=29;d.ms_div=0;
   d.now_ms=base+ms;d.phase_started=base-1000;d.guard_started=base;
   d.position_hold={6'd0,row[41:32]};d.load_hold={5'd0,row[31:21]};d.temp_hold=25;d.error_hold=1;
   d.initials[lane]=d.upper(lane);d.position[lane]=row[41:32];d.commanded[lane]=row[41:32];
   d.best_error[lane]=1023;d.last_progress[lane]=base+ms;d.reference_q16=30000;
   if(row[61])begin
    d.excess_active=0;d.hard_active=0;d.arrival_active=0;d.last_feedback[lane]=base+ms;
    d.excess_count[lane]=0;d.excess_since[lane]=0;d.hard_since[lane]=0;
   end
   // Reproduce the synchronous directional ROM output before EVALUATE.
   d.model_cell=d.model[{1'b0,row[60:58],(lane!=0),row[41:37]}];
   #1;
   if(d.model_upper!==row[20:11] || d.current_limit!==row[10:1])$fatal(1,"model/limit vector=%d got %d/%d expected %d/%d",n,d.model_upper,d.current_limit,row[20:11],row[10:1]);
   @(posedge clk);#1;
   if((d.state==15)!==row[0])$fatal(1,"guard boundary vector=%d lane=%d ms=%d state=%d expected_hit=%d",n,lane,ms,d.state,row[0]);
  end
  end
  $display("PASS: original Python ExcessLoad/Guard boundary vectors, direction-bit load, margins, 30/60ms, three samples, gap reset, hard/emergency");$finish;
 end
endmodule
