lengths[0]=22;
lengths[1]=26;
lengths[2]=23;
lengths[3]=22;
lengths[4]=24;
lengths[5]=22;
lengths[6]=23;
