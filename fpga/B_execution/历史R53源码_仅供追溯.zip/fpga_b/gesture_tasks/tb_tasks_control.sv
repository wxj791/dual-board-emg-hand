`timescale 1ns/1ps
module tb_tasks_control;
 reg clk=0;always #5 clk=~clk;reg rst=0,cv=0,rr=0,rv=0,disp=0,stale=0;
 reg [15:0] id=1,op=0,len=0,cls=0,gen=7,count=3,epoch=1;
 reg [31:0] win=0;reg [79:0] args=0;wire cr,rvalid;wire [15:0] status;wire [9:0] rlen;wire [4095:0] data;
 reg [9:0] byte_index=0;wire [7:0] byte_value;
 wire [2:0] page;wire [127:0] ranges;wire armed;wire [31:0] autos,rejects;
 reg [7:0] motion=0;reg ev=0;reg [15:0] eid=0;wire req;wire [2:0] reqop;
 b_tasks_control #(.FRESH_CLKS(100000),.MIN_EVENT_CLKS(8),.COLLISION_SUPPORTED(0)) d(
  .clk(clk),.rst_n(rst),.display_enabled(disp),.command_valid(cv),.command_ready(cr),
  .request_id(id),.opcode(op),.data_length(len),.arguments(args),.response_valid(rvalid),.response_ready(rr),
  .response_status(status),.response_length(rlen),.response_data(data),
  .response_byte_index(byte_index),.response_byte(byte_value),
  .result_valid(rv),.wave_valid(1'b0),.link_fault(1'b0),.stale(stale),.generation(gen),.epoch(epoch),
  .class_id(cls),.class_count(count),.result_flags(8'd3),.window_seq(win),
  .online(5'd0),.torque(5'd0),.pose_valid(9'd0),.servo_idle(1'b1),.flash_ready(1'b0),
  .flash_available(1'b1),.flash_initialized(1'b1),
  .positions({16'd1003,16'd401,16'd710,16'd640,16'd476}),.speeds({5{16'd220}}),.loads({5{16'h041e}}),
  .feedback_age_ms({16'hffff,16'd200,16'd199,16'd1,16'd0}),.feedback_valid_mask(5'd7),.torque_valid_mask(5'd31),
  .motion_state(motion),.active_mask(5'd0),.retired_mask(5'd0),.fault_flags(32'd0),
  .req_valid(req),.req_ready(1'b1),.req_op(reqop),.event_valid(ev),.event_ready(),.event_id(eid),.event_status(16'd0),
  .query_valid(1'b1),.query_positions({10'd1003,10'd401,10'd710,10'd640,10'd476}),.page(page),.ranges(ranges),.armed(armed),.auto_count(autos),.auto_rejects(rejects));
 task send(input [15:0] opcode,input [15:0] length,input [79:0] argument,input [15:0] expected);
  begin @(negedge clk);op=opcode;len=length;args=argument;cv=1;
   while(!cr)@(negedge clk);@(negedge clk);cv=0;wait(rvalid);#1;
   if(status!==expected)$fatal(1,"opcode %h status=%d expected=%d",opcode,status,expected);
   @(negedge clk);rr=1;@(negedge clk);rr=0;id=id+1;
  end
 endtask
 task result(input [15:0] c);begin
  @(negedge clk);cls=c;win=win+1;rv=1;@(negedge clk);rv=0;repeat(10)@(negedge clk);
 end endtask
 reg [63:0] rows[0:2];reg [63:0] max_row;reg [31:0] crc;reg [15:0] held_revision;integer i,j,f,stops=0;
 always @(posedge clk)if(req && reqop==3)stops=stops+1;
 task dump_json;begin
  if(rlen>512)$fatal(1,"oversize JSON");
  for(integer k=0;k<rlen;k=k+1)begin
   @(negedge clk);byte_index=k;repeat(2)@(negedge clk);$fwrite(f,"%c",byte_value);
  end
  $fwrite(f,"\n");
 end endtask
 function [31:0] cb(input [31:0] c,input [7:0] b);reg [31:0] v;integer n;
  begin v=c^b;for(n=0;n<8;n=n+1)v=v[0]?(v>>1)^32'hedb88320:v>>1;cb=v;end
 endfunction
 initial begin
  f=$fopen("artifacts/b_gesture_tasks/query_readback.jsonl","w");
  repeat(4)@(negedge clk);rst=1;result(0);result(0);
  send('h030a,2,8,0);
  if(rlen!=13 || data[103:0]!={8'd1,8'd1,16'd1003,16'd401,16'd710,16'd640,16'd476,8'd1})$fatal(1,"historical 13 byte POSE_QUERY");
  send('h030a,2,9,3);
  send('h0002,0,0,0);dump_json;
  send('h0001,0,0,0);send('h0306,1,1,6);send('h0606,0,0,6);
  rows[0]=0;rows[1]=64'h0000000001040001;rows[2]=64'h0000000001050002;
  crc='hffffffff;for(i=0;i<3;i=i+1)for(j=0;j<8;j=j+1)crc=cb(crc,rows[i][j*8+:8]);crc=crc^'hffffffff;
  send('h0600,8,{16'd0,32'd1,16'd3,16'd7},0);
  send('h0601,8,rows[0],0);send('h0601,8,rows[1],0);
  send('h0602,8,{16'd0,crc,32'd1},8);
  send('h0601,8,rows[2],0);send('h0602,8,{16'd0,crc^32'd1,32'd1},8);
  send('h0602,8,{16'd0,crc,32'd1},0);
  // Servo absent and ARM=false: display tasks still operate.
  result(0);result(1);result(1);if(page!=0)$fatal(1,"OFF gesture executed");
  disp=1;result(1);result(1);if(page!=0)$fatal(1,"ON replayed old gesture");
  result(0);result(1);result(1);if(page!=1 || armed)$fatal(1,"display/ARM independence");
  repeat(6)result(1);if(page!=1)$fatal(1,"held gesture repeated");
  result(0);result(2);result(2);if(ranges!={8{16'd100}})$fatal(1,"zoom all filter channels");
  send('h0204,4,{48'd0,16'd50,8'hff,8'd0},0);
  send('h0204,4,{48'd0,16'd77,8'hff,8'd0},3);
  send('h0200,1,0,0);if(ranges!={8{16'd50}})$fatal(1,"per-page range persistence");
  send('h0604,0,0,0);
  if(rlen!=28 || data[7:0]!=1 || data[47:32]!=7 || data[175:160]!=50)$fatal(1,"TASK_STATE byte layout");
  for(integer p=1;p<=4;p=p+1)begin send('h0002,1,p,0);dump_json;end
  if(page!=0 || ranges!={8{16'd50}})$fatal(1,"status query changed display");
  send('h0002,1,5,3);send('h0002,2,0,3);
  held_revision=d.revision;send('h0202,1,1,0);
  if(!d.freeze || d.revision!=held_revision)$fatal(1,"freeze cleared visible history");
  send('h0202,1,0,0);if(d.freeze || d.revision!=held_revision+1)$fatal(1,"resume history isolation");
  // Re-BEGIN must discard prior staging completeness and retain the active map.
  send('h0600,8,{16'd0,32'd2,16'd3,16'd7},0);send('h0601,8,rows[0],0);
  send('h0602,8,{16'd0,crc,32'd2},8);send('h0603,2,1,0);
  if(data[63:0]!==rows[1])$fatal(1,"invalid commit changed active");
  // class0 enabled, invalid kinds, reserved bits all fail.
  send('h0601,8,64'h0000000001040000,3);
  send('h0601,8,64'h0000000001070001,3);
  send('h0601,8,64'h0001000001040001,3);
  gen=8;result(0);result(1);result(1);if(armed)$fatal(1,"generation did not revoke ARM");
  // Revocation on the exact cycle a mechanical start is accepted still stops it.
  @(negedge clk);d.req_valid=1;d.req_op=4;gen=9;rv=1;win=win+1;
  @(negedge clk);rv=0;motion=2;repeat(8)@(negedge clk);
  stale=1;repeat(8)@(negedge clk);
  if(stops!=1)$fatal(1,"revocation lost or repeated STOP count=%d",stops);
  stale=0;motion=0;
  count=32;result(0);send('h0600,8,{16'd0,32'd3,16'd32,gen},0);
  crc='hffffffff;
  for(i=0;i<32;i=i+1)begin
   max_row=i==31?64'h000000080101001f:i;
   for(j=0;j<8;j=j+1)crc=cb(crc,max_row[j*8+:8]);
   send('h0601,8,max_row,0);
  end
  send('h0602,8,{16'd0,crc^32'hffffffff,32'd3},0);send('h0603,2,31,0);
  if(data[63:0]!=64'h000000080101001f)$fatal(1,"32 row capacity / compact pose slot8 readback");
  $fclose(f);$display("PASS: 13-byte pose/status paging, atomic map/CRC/missing rows/class0/re-BEGIN, held/rest gestures, OFF/ON, no-servo display, range pages, state layout");$finish;
 end
 initial begin #200000;$fatal(1,"watchdog");end
endmodule
