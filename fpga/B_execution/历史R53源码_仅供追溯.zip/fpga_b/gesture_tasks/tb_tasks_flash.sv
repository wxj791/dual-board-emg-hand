module tb_tasks_flash;
    reg clk = 0;
    always #20.833 clk = ~clk;
    reg rst_n = 0;
    reg save_req = 0;
    reg [3:0] save_group = 0;
    reg [49:0] save_positions = 0;
    wire init_done, available, load_valid, save_done, save_ok;
    wire [3:0] load_group;
    wire [49:0] load_positions;
    wire cs_n, sclk, mosi, miso;
    wire captured_miso;
    b_tasks_flash_input capture(.clk(clk),.miso(miso),.captured(captured_miso));
    integer loaded_count = 0;
    reg [49:0] last_loaded = 0;
    reg [3:0] last_group = 0;
    localparam [49:0] FIRST = {10'd104,10'd103,10'd102,10'd101,10'd100};
    localparam [49:0] SECOND = {10'd304,10'd303,10'd302,10'd301,10'd300};

    teach_flash_store dut (
        .clk(clk), .rst_n(rst_n), .save_req(save_req),
        .save_group(save_group), .save_positions(save_positions),
        .init_done(init_done), .available(available),
        .load_valid(load_valid), .load_group(load_group),
        .load_positions(load_positions), .save_done(save_done), .save_ok(save_ok),
        .flash_cs_n(cs_n), .flash_clk(sclk), .flash_mosi(mosi), .flash_miso(captured_miso)
    );
    test_nor_flash flash (.cs_n(cs_n), .sclk(sclk), .mosi(mosi), .miso(miso));

    always @(posedge clk) if (load_valid) begin
        loaded_count = loaded_count + 1;
        last_loaded = load_positions;
        last_group = load_group;
    end

    task reboot;
        begin
            @(negedge clk); rst_n = 0;
            repeat (10) @(negedge clk);
            rst_n = 1;
            wait (init_done);
            repeat (2) @(negedge clk);
            if (!available) $fatal(1, "JEDEC ID rejected");
        end
    endtask

    task save;
        input [49:0] positions;
        begin
            @(negedge clk);
            save_group = 4'd5;
            save_positions = positions;
            save_req = 1;
            @(negedge clk); save_req = 0;
            wait (save_done);
            if (!save_ok) $fatal(1, "flash save failed");
            @(negedge clk);
        end
    endtask

    initial begin #50000000; $fatal(1, "flash store timeout"); end
    initial begin
        reboot();
        if (loaded_count != 0) $fatal(1, "blank flash loaded data");
        save(FIRST);
        reboot();
        if (loaded_count != 1 || last_group != 5 || last_loaded != FIRST)
            $fatal(1, "first record did not survive reset");
        save(SECOND);
        reboot();
        if (loaded_count != 2 || last_loaded != SECOND)
            $fatal(1, "newer record was not selected");
        flash.data['hb000 + 17] = 8'h00;
        reboot();
        if (loaded_count != 3 || last_loaded != FIRST)
            $fatal(1, "corrupt new record did not fall back to old record");
        $display("PASS: flash save, reset recovery, and redundant fallback");
        $finish;
    end
endmodule
