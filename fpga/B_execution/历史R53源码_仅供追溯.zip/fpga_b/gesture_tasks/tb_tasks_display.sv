`timescale 1ns/1ps
module tb_tasks_display;
 reg clk=0;always #5 clk=~clk;reg rst=0,valid=0,clear=0,freeze=0;reg [2:0] page=0;
 reg [127:0] samples=0,ranges={8{16'd1200}};integer n,c,k,expected;reg [15:0] range_values[0:6];
 reg [127:0] gains={8{16'd256}};reg [7:0] custom=0;
 b_v2_renderer d(.clk(clk),.rst_n(rst),.sample_valid(valid),.sample_data(samples),.servo_snapshot(320'd0),
  .history_clear(clear),.freeze(freeze),.page(page),.gain(16'd256),.sample_rate(16'd1000),
  .class_id(16'd0),.generation(16'd0),.mapped_action(16'd0),.mapped_pose(16'd0),
  .channel_gains(gains),.ranges(ranges),.custom(custom),.armed(1'b0),.saturated(1'b0),.link_stale(1'b0));
 task sample(input integer value);begin
  @(negedge clk);for(integer ch=0;ch<8;ch=ch+1)samples[ch*16+:16]=value+ch*10;valid=1;
  @(negedge clk);valid=0;repeat(5)@(negedge clk);
 end endtask
 task commit;begin
  @(negedge clk);force d.frame_start=1;@(negedge clk);release d.frame_start;repeat(7500)@(negedge clk);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst=1;
  for(n=0;n<520;n=n+1)sample(1000+n);
  commit;
  if(d.history!=512 || d.view_base!=8 || !d.wave_valid)$fatal(1,"visible window alignment");
  for(c=0;c<8;c=c+1)if(d.centers[c*16+:16]!==1263+c*10)$fatal(1,"512 sliding mean ch=%d center=%d",c,d.centers[c*16+:16]);
  force d.h=384;force d.v=194;force d.wave_x=0;force d.wave_phase=0;
  range_values[0]=20;range_values[1]=50;range_values[2]=100;range_values[3]=200;range_values[4]=500;range_values[5]=1200;range_values[6]=3300;
  for(k=0;k<7;k=k+1)begin
   @(negedge clk);ranges={8{range_values[k]}};repeat(24)@(negedge clk);
   if(d.native_trace.sample_a3!==-16'sd255)$fatal(1,"raw sample/center subtraction");
   expected=-(2676480/integer'(range_values[k]));
   if((d.native_trace.scale_a4>>>12)<expected-2 ||
      (d.native_trace.scale_a4>>>12)>expected+2)$fatal(1,"mV pixel height range=%d got=%d expected=%d",range_values[k],d.native_trace.scale_a4>>>12,expected);
   if(d.native_trace.low_a5!==(range_values[k]<255))$fatal(1,"raw overflow range=%d",range_values[k]);
  end
  @(negedge clk);custom=1;gains[15:0]=512;repeat(24)@(negedge clk);
  expected=(-255*512*117)>>>12;
  if((d.native_trace.scale_a4>>>12)!=expected)$fatal(1,"legacy CUSTOM gain pixel amplitude got=%d expected=%d",d.native_trace.scale_a4>>>12,expected);
  @(negedge clk);custom=0;repeat(24)@(negedge clk);
  repeat(600)@(negedge clk);
  if(d.ranges_bcd[15:0]!=16'h1200 && d.ranges_bcd[15:0]!=16'h3300)$fatal(1,"decimal conversion");
  freeze=1;sample(3000);commit;if(d.write_ptr!=520 || d.centers[15:0]!=1263)$fatal(1,"freeze changed history/center");
  @(negedge clk);clear=1;@(negedge clk);clear=0;repeat(5)@(negedge clk);
  if(d.wave_valid || d.history!=0 || d.mean_sum[0]!=0)$fatal(1,"revision/clear history isolation");
  freeze=0;page=1;sample(0);if(d.mean_sum[0]!=0)$fatal(1,"filter altered raw mean");
  release d.h;release d.v;release d.wave_x;release d.wave_phase;
  $display("PASS: 512-point sliding mean/snapshot, seven physical raw ranges, signed pixel amplitude and overflow, freeze, page/history isolation, decimal converter");$finish;
 end
 initial begin #1000000;$fatal(1,"watchdog");end
endmodule
