localparam integer GUARD_VECTORS=72;
