`timescale 1ns/1ps
module tb_tasks_top;
 reg clk=0;always #20.833333 clk=~clk;reg rst=0,lc=0,lv=0;always #500 lc=~lc;
 reg [7:0] ld=0;wire ready,return_tx;wire [3:0] led;
 b_tasks_top #(.BOOT_CLKS(8),.SW_CLKS(8),.FLASH_RELEASE_CLKS(8),.SERVO_TIMEOUT_CLKS(3000)) d(
  .clk_24m(clk),.rst_n(rst),.host_uart_rx(1'b1),.display_sw(1'b0),.b_return_tx(return_tx),
  .link_data(ld),.link_clk(lc),.link_valid(lv),.link_ready(ready),.scs_rx(1'b1),.flash_miso(1'b1),.status_led_n(led));
 wire [7:0] rb;wire rv,fe;
 ingress_uart_rx #(.CLKS_PER_BIT(26)) receiver(.clk(clk),.rst_n(rst),.uart_rx(return_tx),.byte_data(rb),.byte_valid(rv),.framing_error(fe));
 `include "fpga_b/gesture_tasks/vector_constants.vh"
 integer f,bytes=0,frames=0;reg [7:0] stimulus[0:VECTOR_BYTES-1];integer lengths[0:VECTOR_FRAMES-1];integer n,j,k=0;
 always @(posedge clk)begin
  if(rv)begin $fdisplay(f,"%02x",rb);bytes=bytes+1;end
  if(fe)$fatal(1,"GPIO response framing");
  if(d.sample_valid || d.result_valid)$fatal(1,"0x42 leaked into wave/class decoder");
 end
 initial begin
  `include "fpga_b/gesture_tasks/vector_lengths.vh"
  $readmemh("artifacts/b_gesture_tasks/command_vectors.hex",stimulus);
  f=$fopen("artifacts/b_gesture_tasks/gpio_responses.hex","w");
  repeat(8)@(negedge clk);rst=1;wait(d.pix_reset);repeat(20)@(negedge clk);
  if(led[0]!==0)$fatal(1,"actual display enable LED");
  // Production 24MHz control / 148.5MHz pixel / 1MHz parallel / GPIO 921600.
  for(n=0;n<VECTOR_FRAMES;n=n+1)begin
   for(j=0;j<lengths[n];j=j+1)begin @(negedge lc);while(!ready)@(negedge lc);ld=stimulus[k];k=k+1;lv=1;end
   @(negedge lc);lv=0;
   wait(d.pc.sending || d.pc.buffering);wait(!d.pc.sending && !d.pc.buffering);repeat(800)@(negedge clk);
  end
  if(d.page!=1 || d.ranges!={8{16'd50}} || d.a_crc!=0 || d.rejected!=0 || d.control.armed)$fatal(1,"routed display state");
  if(bytes<400)$fatal(1,"missing GPIO responses %d",bytes);
  $fclose(f);
  $display("PASS: production clocks, physical 1MHz 0x42 forwarding, GPIO framed responses, separate waveform/classification decoder, range command and switch LED");$finish;
 end
 initial begin forever begin #1000000;$display("PROGRESS: top time=%t frame=%0d response_bytes=%0d",$time,n,bytes);$fflush();end end
 always @(negedge d.clk_pix)if(d.pix_reset && d.renderer.timing.h>0)
  if(d.renderer.timing.x_window !== (d.renderer.timing.h>=192 && d.renderer.timing.h<2111))
   $fatal(1,"anticipated physical x-window differs from original timing");
 initial begin #20000000;$fatal(1,"watchdog");end
endmodule
