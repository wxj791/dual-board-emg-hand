`timescale 1ns/1ps
module tb_tasks_scale;
 reg clk=0;always #5 clk=~clk;reg rst=0,sv=0;reg [2:0] page=1;
 reg [127:0] ranges={8{16'd200}},gains={8{16'd256}};reg [7:0] custom=0;reg [191:0] filt=0,env=0;
 wire valid,sat;wire [160:0] data;integer range[0:6];integer i,k;
 b_tasks_scale d(.clk(clk),.rst_n(rst),.sample_valid(sv),.segment_break(1'b0),
  .raw_mv({8{16'd1700}}),.filtered_q8(filt),.fast_q4(env),.slow_q4(env),.page(page),
  .ranges(ranges),.gains(gains),.custom(custom),.revision(16'd3),.fifo_full(1'b0),
  .valid(valid),.data(data),.saturated(sat));
 task sample;begin @(negedge clk);sv=1;@(negedge clk);sv=0;wait(valid);@(negedge clk);end endtask
 initial begin
  range[0]=20;range[1]=50;range[2]=100;range[3]=200;range[4]=500;range[5]=1200;range[6]=3300;
  repeat(4)@(negedge clk);rst=1;
  for(i=0;i<7;i=i+1)begin
   for(k=0;k<8;k=k+1)ranges[k*16+:16]=range[i];
   page=1;for(k=0;k<8;k=k+1)filt[k*24+:24]=range[i]*128;
   sample;if($signed(data[15:0])<11482 || $signed(data[15:0])>11484 || sat)$fatal(1,"half-range filter %d got %d",range[i],$signed(data[15:0]));
   for(k=0;k<8;k=k+1)filt[k*24+:24]=-range[i]*128;
   sample;if($signed(data[15:0])> -11482 || $signed(data[15:0])< -11484)$fatal(1,"negative filter");
   page=2;env=0;sample;if($signed(data[15:0])!=-22966)$fatal(1,"envelope zero bottom");
   for(k=0;k<8;k=k+1)env[k*24+:24]=range[i]*8;
   sample;if($signed(data[15:0])< -2 || $signed(data[15:0])>2)$fatal(1,"envelope half range");
   for(k=0;k<8;k=k+1)env[k*24+:24]=range[i]*32;
   sample;if(!sat || $signed(data[15:0])!=22966)$fatal(1,"clip");
  end
  page=2;env={8{24'h800000}};sample;
  if(!sat || $signed(data[15:0])!=22966)$fatal(1,"unsigned envelope high bit wrapped negative");
  page=0;sample;if(data[15:0]!=1700)$fatal(1,"raw must preserve ADC mV");
  custom=8'hff;gains={8{16'd512}};
  page=1;filt={8{24'd25600}};sample;
  if($signed(data[15:0])!=3200 || sat)$fatal(1,"CUSTOM filter positive");
  for(k=0;k<8;k=k+1)filt[k*24+:24]=-25600;
  sample;if($signed(data[15:0])!=-3200 || sat)$fatal(1,"CUSTOM filter negative");
  page=2;env={8{24'd1600}};sample;
  if($signed(data[15:0])!=-16566 || sat)$fatal(1,"CUSTOM envelope offset");
  $display("PASS: all seven mV ranges, signed Q8 filter, unsigned Q4 envelope, zero/half/overflow and preserved RAW ADC values");$finish;
 end
 initial begin #100000;$fatal(1,"watchdog");end
endmodule
