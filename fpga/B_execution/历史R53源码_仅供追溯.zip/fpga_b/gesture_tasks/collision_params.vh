function [9:0] upper;input [2:0] lane;begin case(lane)
3'd0:upper=10'h1dc;
3'd1:upper=10'h0;
3'd2:upper=10'h2c6;
3'd3:upper=10'h191;
3'd4:upper=10'h2c7;
default:upper=10'd0;endcase end endfunction
function [9:0] lower;input [2:0] lane;begin case(lane)
3'd0:lower=10'h62;
3'd1:lower=10'h0;
3'd2:lower=10'h3eb;
3'd3:lower=10'h2ce;
3'd4:lower=10'h3ea;
default:lower=10'd0;endcase end endfunction
function [9:0] bound_low;input [2:0] lane;begin case(lane)
3'd0:bound_low=10'h56;
3'd1:bound_low=10'h14;
3'd2:bound_low=10'h2ba;
3'd3:bound_low=10'h185;
3'd4:bound_low=10'h2bb;
default:bound_low=10'd20;endcase end endfunction
function [9:0] bound_high;input [2:0] lane;begin case(lane)
3'd0:bound_high=10'h1e8;
3'd1:bound_high=10'h3ff;
3'd2:bound_high=10'h3fa;
3'd3:bound_high=10'h348;
3'd4:bound_high=10'h3f7;
default:bound_high=10'd1023;endcase end endfunction
function [9:0] observed_low;input [2:0] lane;begin case(lane)
3'd0:observed_low=10'h63;
3'd1:observed_low=10'h0;
3'd2:observed_low=10'h2c5;
3'd3:observed_low=10'h192;
3'd4:observed_low=10'h2c7;
default:observed_low=10'd0;endcase end endfunction
function [9:0] observed_high;input [2:0] lane;begin case(lane)
3'd0:observed_high=10'h1dc;
3'd1:observed_high=10'h0;
3'd2:observed_high=10'h3ec;
3'd3:observed_high=10'h2cc;
3'd4:observed_high=10'h3eb;
default:observed_high=10'd0;endcase end endfunction
function [9:0] hard_load;input [2:0] lane;begin case(lane)
3'd0:hard_load=10'hf0;
3'd1:hard_load=10'h12c;
3'd2:hard_load=10'hd2;
3'd3:hard_load=10'h10e;
3'd4:hard_load=10'h12c;
default:hard_load=10'd300;endcase end endfunction
function [9:0] startup_hard;input [2:0] lane;begin case(lane)
3'd0:startup_hard=10'h12c;
3'd1:startup_hard=10'h12c;
3'd2:startup_hard=10'hd2;
3'd3:startup_hard=10'h10e;
3'd4:startup_hard=10'h12c;
default:startup_hard=10'd300;endcase end endfunction
function [9:0] startup_stall;input [2:0] lane;begin case(lane)
3'd0:startup_stall=10'h258;
3'd1:startup_stall=10'h15e;
3'd2:startup_stall=10'h15e;
3'd3:startup_stall=10'h15e;
3'd4:startup_stall=10'h15e;
default:startup_stall=10'd350;endcase end endfunction
function [9:0] load_margin;input [2:0] lane;begin case(lane)
3'd0:load_margin=10'hf;
3'd1:load_margin=10'h1e;
3'd2:load_margin=10'hf;
3'd3:load_margin=10'h1e;
3'd4:load_margin=10'h1e;
default:load_margin=10'd30;endcase end endfunction
function [9:0] hold_ms;input [2:0] lane;begin case(lane)
3'd0:hold_ms=10'h1e;
3'd1:hold_ms=10'h3c;
3'd2:hold_ms=10'h1e;
3'd3:hold_ms=10'h3c;
3'd4:hold_ms=10'h3c;
default:hold_ms=10'd60;endcase end endfunction
function [319:0] expected_config;input [2:0] lane;begin case(lane)
3'd0:expected_config=320'h50641400000000000000000101012d00000f0f252001e8032d5a46eb031400010000010405010500;
3'd1:expected_config=320'h50641400000000000000000101012d00000f0f252001e8032d5a46eb031400010000020405010500;
3'd2:expected_config=320'h50641400000000000000000101012d00000f0f252001e8032d5a46eb031400010000030405010500;
3'd3:expected_config=320'h50641400000000000000000101012d00000f0f252001e8032d5a46eb031400010000040405010500;
3'd4:expected_config=320'h50641400000000000000000101012d00000f0f252001e8032d5a46eb031400010000050405010500;
default:expected_config=320'd0;endcase end endfunction
