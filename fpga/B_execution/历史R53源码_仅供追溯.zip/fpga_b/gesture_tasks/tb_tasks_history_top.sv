`timescale 1ns/1ps
module tb_tasks_history_top;
 reg clk=0;always #20.833333 clk=~clk;reg rst=0;
 reg [679:0] metadata=0;reg [160:0] word=0;reg empty=1;integer n;
 b_tasks_top #(.BOOT_CLKS(8),.SW_CLKS(8),.FLASH_RELEASE_CLKS(8),.SERVO_TIMEOUT_CLKS(3000)) d(
  .clk_24m(clk),.rst_n(rst),.host_uart_rx(1'b1),.display_sw(1'b1),
  .link_data(8'd0),.link_clk(1'b0),.link_valid(1'b0),.scs_rx(1'b1),.flash_miso(1'b1));
 task sample(input [15:0] revision,input clear_flag,input [15:0] value);begin
  @(negedge d.clk_pix);word={16'd0,revision,clear_flag,{8{value}}};empty=0;
  @(negedge d.clk_pix);empty=1;repeat(7)@(negedge d.clk_pix);
 end endtask
 initial begin
  repeat(8)@(negedge clk);rst=1;wait(d.pix_reset);
  metadata[15:0]=16'h1234;metadata[31:16]=1000;metadata[351:224]={8{16'd1200}};
  force d.pix_meta=metadata;force d.fifo_data=word;force d.fifo_empty=empty;
  repeat(8)@(negedge d.clk_pix);
  for(n=0;n<512;n=n+1)sample('h1234,0,1700);
  force d.frame_start=1;@(negedge d.clk_pix);release d.frame_start;repeat(7500)@(negedge d.clk_pix);
  if(!d.renderer.wave_valid || d.renderer.centers[15:0]!=1700)$fatal(1,"initial visible raw window");
  metadata[51]=1;repeat(8)@(negedge d.clk_pix);sample('h1234,0,1900);
  if(!d.renderer.wave_valid || d.renderer.history!=512 || d.renderer.centers[15:0]!=1700)$fatal(1,"HOLD lost frozen window");
  metadata[51]=0;metadata[15:0]='h1235;repeat(8)@(negedge d.clk_pix);
  if(d.renderer.history!=0 || d.renderer.wave_valid)$fatal(1,"resume did not isolate history");
  sample('h5235,0,1800);if(d.renderer.history!=0)$fatal(1,"high revision nibble mismatch accepted");
  sample('h1234,0,1800);if(d.renderer.history!=0)$fatal(1,"old revision sample accepted");
  sample('h1235,0,1800);if(d.renderer.history!=1)$fatal(1,"new revision sample dropped");
  metadata[50:48]=1;metadata[15:0]='h1236;metadata[648]=1;repeat(8)@(negedge d.clk_pix);
  if(d.renderer.history!=0 || !d.renderer.armed)$fatal(1,"page/ARM mailbox snapshot");
  sample('h1235,0,1700);if(d.renderer.history!=0)$fatal(1,"old scale leaked into new page");
  sample('h1236,0,16'sd1000);if(d.renderer.history!=1 || d.renderer.mean_sum[0]!=0)$fatal(1,"filter page history/raw center isolation");
  sample('h1236,1,0);if(d.renderer.history!=0)$fatal(1,"transport segment break did not clear history");
  release d.pix_meta;release d.fifo_data;release d.fifo_empty;
  $display("PASS: production pixel pipeline revision nibbles, HOLD preserves visible window, resume/page/transport history isolation, ARM mailbox CDC");$finish;
 end
 initial begin #1000000;$fatal(1,"watchdog");end
endmodule
