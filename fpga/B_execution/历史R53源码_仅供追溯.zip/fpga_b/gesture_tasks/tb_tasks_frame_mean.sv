`timescale 1ns/1ps
module tb_tasks_frame_mean;
 reg clk=0;always #3.367003 clk=~clk;
 reg rst=0,sv=0,clear=0,freeze=0;
 reg [127:0] data=0;
 integer count=0,ch,n,frame,cycles,checks=0;
 integer reference_ring[0:4095];
 integer expected[0:7];
 b_v2_renderer d(.clk(clk),.rst_n(rst),.sample_valid(sv),.sample_data(data),
  .servo_snapshot(320'd0),.history_clear(clear),.freeze(freeze),.page(3'd0),
  .gain(16'd256),.sample_rate(16'd1000),.class_id(16'd0),.generation(16'd0),
  .mapped_action(16'd0),.mapped_pose(16'd0),.channel_gains({8{16'd256}}),
  .ranges({8{16'd1200}}),.custom(8'd0),.armed(1'b0),.saturated(1'b0),.link_stale(1'b0));
 task sample(input integer level);integer c,value;begin
  @(negedge clk);
  for(c=0;c<8;c=c+1)begin
   value=level<0?((count*37+c*127)%3301):level+c*5;
   data[c*16+:16]=value;reference_ring[(count%512)*8+c]=value;
  end
  sv=1;@(negedge clk);sv=0;repeat(3)@(negedge clk);count=count+1;
 end endtask
 task capture_expected;integer c,k;begin
  for(c=0;c<8;c=c+1)begin expected[c]=0;
   for(k=0;k<512;k=k+1)expected[c]=expected[c]+reference_ring[k*8+c];
   expected[c]=expected[c]>>9;
  end
 end endtask
 task scan(input integer concurrent_write);begin
  capture_expected;
  @(negedge clk);force d.frame_start=1;
  @(negedge clk);force d.frame_start=0;
  if(!d.mean_busy)$fatal(1,"RAW frame scan did not start");
  if(concurrent_write)sample(1700);
  cycles=0;
  while(d.mean_busy && cycles<7200)begin @(negedge clk);cycles=cycles+1;end
  if(cycles>=7200 || d.mean_fault)$fatal(1,"scan timeout/fault");
  repeat(3)@(negedge clk);
  for(ch=0;ch<8;ch=ch+1)begin
   if(d.centers[ch*16+:16]!==expected[ch] || d.centers[ch*16+:16]>3300)
    $fatal(1,"frame=%d ch=%d center=%d reference=%d",frame,ch,d.centers[ch*16+:16],expected[ch]);
   checks=checks+1;
  end
 end endtask
 initial begin
  force d.h=0;force d.v=0;force d.frame_start=0;
  repeat(6)@(negedge clk);rst=1;
  for(n=0;n<512;n=n+1)sample(-1);
  for(frame=0;frame<64;frame=frame+1)begin
   // Random full-scale data, touch excursion, then stable rest; odd view
   // bases and more than two wraps of the physical history are exercised.
   for(n=0;n<37;n=n+1)sample(frame<8?-1:frame<12?2600:1700);
   scan(frame[0]);
  end
  // Repeated frames without new samples must never accumulate a DC drift.
  for(frame=64;frame<80;frame=frame+1)scan(0);
  freeze=1;
  @(negedge clk);force d.frame_start=1;@(negedge clk);force d.frame_start=0;
  if(d.mean_busy)$fatal(1,"frozen view should not scan");
  @(negedge clk);clear=1;@(negedge clk);clear=0;
  if(d.mean_busy || d.centers!=0)$fatal(1,"clear must abort scanner and invalidate centers");
  $display("PASS: %d exact 512-point channel means, 80 zero-based scans, full-scale/touch/rest, no-data drift, concurrent writes, odd bases, ring wraps, freeze and clear",checks);
  $finish;
 end
 initial begin #10000000;$fatal(1,"watchdog");end
endmodule
