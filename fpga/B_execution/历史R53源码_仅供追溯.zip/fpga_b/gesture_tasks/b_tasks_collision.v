`timescale 1ns/1ps
`default_nettype none
// Fixed100 shared-percent-feedback-v5. Integer msec clock / Q16 shared reference.
// One bus owner, no PC dependency. EEPROM matching precedes any torque enable.
module b_tasks_collision #(parameter integer MS_CLKS=24000)(
 input wire clk,rst_n,start,stop,output reg running,done,output reg [15:0] status,
 output reg bus_valid,input wire bus_ready,output reg [2:0] bus_lane,bus_command,
 output reg [9:0] bus_target,output wire [15:0] bus_speed,
 input wire feedback_valid,input wire feedback_ok,input wire [15:0] feedback_position,feedback_load,
 input wire [7:0] feedback_error,feedback_temperature,feedback_torque,input wire [391:0] feedback_config,
 output reg [4:0] active_mask,retired_mask,output reg [31:0] fault_flags,
 output reg off_verified,
 output reg sample_event,output reg [2:0] sample_lane,
 output reg [16:0] reference_q16,output reg [9:0] normal_upper,load_limit,
 output reg [1:0] phase
);
 `include "fpga_b/gesture_tasks/collision_params.vh"
 localparam IDLE=0,OFF_ALL=1,VERIFY_ALL=2,CONFIG=3,INITIAL=4,PHASE_READ=5,
  HOLD_GOAL=6,ENABLE=7,BASELINE=8,RAMP=9,CAP_START=10,CAP_WAIT=11,
  READ=12,EVALUATE=13,GOAL=14,HOLD_RETIRE=15,OFF_RETIRE=16,VERIFY_RETIRE=17,
  ROUND_WAIT=18,PHASE_WAIT=19,LOOKUP=20,RAMP_WAIT=21,STARTUP_START=22,STARTUP_WAIT=23;
 reg [4:0] state;reg [2:0] lane;reg [4:0] pending_mask;
 reg [9:0] initials[0:4],position[0:4],commanded[0:4],best_error[0:4];
 reg [15:0] last_feedback[0:4],last_progress[0:4],excess_since[0:4],hard_since[0:4],arrival_since[0:4];
 reg [4:0] excess_active,hard_active,arrival_active;reg [7:0] excess_count[0:4];
 reg [14:0] ms_div;reg [15:0] now_ms,phase_started,motion_started,guard_started,wait_started;
 reg finalizing,off_failed,contact_retire;reg [15:0] final_status;
 reg [15:0] position_hold,load_hold;reg [7:0] error_hold,temp_hold;
 reg [16:0] cap_min;reg [31:0] ramp_q16,ramp_elapsed;
 reg divide_start;reg [31:0] dividend;reg [15:0] divisor;wire divide_done;wire [31:0] quotient;
 b_tasks_div divide(.clk(clk),.rst_n(rst_n),.start(divide_start),.numerator(dividend),.denominator(divisor),.done(divide_done),.quotient(quotient));
 (* ram_style="block" *)reg [20:0] model[0:511];reg [20:0] model_cell;
 initial $readmemh("fpga_b/gesture_tasks/assets/collision_model.hex",model);
 wire [9:0] target=phase==1 ? lower(lane):upper(lane);
 wire positive=target>=initials[lane];
 wire [9:0] travel=positive ? target-initials[lane]:initials[lane]-target;
 wire [15:0] progress=positive ? (position[lane]>=initials[lane] ? position[lane]-initials[lane]:0):
                          (position[lane]<=initials[lane] ? initials[lane]-position[lane]:0);
 wire [31:0] lead_numerator=travel*32'd2621>32'd786432 ? travel*32'd2621:32'd786432;
 function [15:0] age_ms;input [15:0] now_value,stamp;begin age_ms=now_value-stamp;end endfunction
 wire [31:0] elapsed=age_ms(now_ms,motion_started);
 wire [8:0] ramp_t=elapsed[8:0];
 wire [26:0] acceleration_numerator=ramp_t*ramp_t*27'd512;
 wire [31:0] phase_elapsed=age_ms(now_ms,phase_started);
 wire [15:0] error_distance=position_hold>=target ? position_hold-target:target-position_hold;
 wire [9:0] magnitude=load_hold[9:0];
 wire covered=phase!=0 && travel>8 && model_cell[20] && position_hold>=observed_low(lane) && position_hold<=observed_high(lane);
 wire [9:0] model_upper=phase_elapsed<=250 && model_cell[19:10]>model_cell[9:0] ? model_cell[19:10]:model_cell[9:0];
 wire [10:0] upper_margin={1'b0,model_upper}+load_margin(lane);
 wire [9:0] profile_hard=phase==0 ? startup_hard(lane):hard_load(lane);
 wire [10:0] adaptive_limit=covered && upper_margin>profile_hard ? upper_margin:{1'b0,profile_hard};
 wire [9:0] current_limit=adaptive_limit>300 ? 10'd300:adaptive_limit[9:0];
 wire excess=covered && {1'b0,magnitude}>=upper_margin;
 wire [31:0] fresh_gap=age_ms(now_ms,last_feedback[lane]);
 wire excessive_now=excess && excess_active[lane] && fresh_gap<=50 && excess_count[lane]>=2 &&
                      age_ms(now_ms,excess_since[lane])>=hold_ms(lane);
 wire hard_now=magnitude>=300 || (magnitude>=current_limit && hard_active[lane] && age_ms(now_ms,hard_since[lane])>=30);
 wire [31:0] stall_ms=phase==0 ? {22'd0,startup_stall(lane)}:32'd350;
 wire close_to_reference=(commanded[lane]>=position_hold ? commanded[lane]-position_hold:position_hold-commanded[lane])<10;
 wire [26:0] goal_product=travel*reference_q16;
 wire [15:0] raw_goal=positive ? initials[lane]+((goal_product+32768)>>16):initials[lane]-((goal_product+32768)>>16);
 wire [15:0] bounded_goal=raw_goal>position[lane]+24 ? position[lane]+24:
   (position[lane]>24 && raw_goal<position[lane]-24) ? position[lane]-24:raw_goal;
 wire [9:0] next_goal=bounded_goal<20 ? 10'd20:bounded_goal>1003 ? 10'd1003:bounded_goal[9:0];
 reg moving_found,deadline_fault;integer moving_i;reg [9:0] moving_target;
 always @*begin
  moving_found=0;moving_target=0;deadline_fault=age_ms(now_ms,guard_started)>=24000;
  for(moving_i=0;moving_i<5;moving_i=moving_i+1)begin
   moving_target=phase==1 ? lower(moving_i):upper(moving_i);
   if(pending_mask[moving_i] && (moving_target>=initials[moving_i] ? moving_target-initials[moving_i]:initials[moving_i]-moving_target)>8)moving_found=1;
   if(pending_mask[moving_i] && age_ms(now_ms,last_feedback[moving_i])>=200)deadline_fault=1;
  end
 end
 assign bus_speed=220;
 integer i;
 task request;input [2:0] cmd;input [9:0] goal;begin
  if(bus_ready && !bus_valid && !feedback_valid && (!stop || state==OFF_ALL || state==VERIFY_ALL))begin bus_valid<=1;bus_lane<=lane;bus_command<=cmd;bus_target<=goal;end
 end endtask
 task finish_all;input [15:0] s;input [4:0] reason;begin
  finalizing<=1;final_status<=s;fault_flags[reason]<=1;state<=OFF_ALL;lane<=0;off_failed<=0;
 end endtask
 task next_pending;begin
  if(lane==4)begin state<=ROUND_WAIT;wait_started<=now_ms;lane<=0;end
  else begin lane<=lane+1'b1;state<=READ;end
 end endtask
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   running<=0;done<=0;status<=0;bus_valid<=0;bus_lane<=0;bus_command<=0;bus_target<=0;off_verified<=0;
   active_mask<=0;retired_mask<=0;fault_flags<=0;state<=IDLE;lane<=0;pending_mask<=0;
   ms_div<=0;now_ms<=0;phase_started<=0;motion_started<=0;guard_started<=0;wait_started<=0;
   finalizing<=0;off_failed<=0;final_status<=0;contact_retire<=0;
   reference_q16<=0;cap_min<=65536;ramp_q16<=0;ramp_elapsed<=0;divide_start<=0;dividend<=0;divisor<=1;
   position_hold<=0;load_hold<=0;error_hold<=0;temp_hold<=0;excess_active<=0;hard_active<=0;arrival_active<=0;
   sample_event<=0;sample_lane<=0;normal_upper<=0;load_limit<=0;phase<=0;
   for(i=0;i<5;i=i+1)begin initials[i]<=0;position[i]<=0;commanded[i]<=0;best_error[i]<=1023;
    last_feedback[i]<=0;last_progress[i]<=0;excess_since[i]<=0;hard_since[i]<=0;arrival_since[i]<=0;excess_count[i]<=0;end
  end else begin
   done<=0;divide_start<=0;sample_event<=0;
   if(ms_div==MS_CLKS-1)begin ms_div<=0;now_ms<=now_ms+1'b1;end else ms_div<=ms_div+1'b1;
   if(bus_valid && bus_ready)bus_valid<=0;
   // Synchronous ROM lookup has an entire READ transaction before EVALUATE.
   model_cell<=model[{1'b0,lane,positive,position_hold[9:5]}];
   if(start && !running)begin
    running<=1;fault_flags<=0;active_mask<=5'b11101;retired_mask<=0;phase<=0;off_verified<=0;
    state<=OFF_ALL;lane<=0;finalizing<=0;off_failed<=0;final_status<=0;
   end else if(running)begin
    case(state)
     OFF_ALL:request(2,0);
     VERIFY_ALL:request(6,0);
     CONFIG:request(5,0);
     INITIAL:request(1,0);
     PHASE_READ:begin
      if(!active_mask[lane])begin
       if(lane==4)begin lane<=0;state<=HOLD_GOAL;end else lane<=lane+1'b1;
      end else request(1,0);
     end
     HOLD_GOAL:begin
      if(!active_mask[lane])begin if(lane==4)begin state<=ENABLE;lane<=0;end else lane<=lane+1'b1;end
      else request(4,initials[lane]);
     end
     ENABLE:begin
      if(!active_mask[lane])begin if(lane==4)begin state<=BASELINE;lane<=0;guard_started<=now_ms;end else lane<=lane+1'b1;end
      else request(3,0);
     end
     BASELINE:begin
      if(!active_mask[lane])begin
       if(lane==4)begin state<=RAMP;lane<=0;motion_started<=now_ms;end else lane<=lane+1'b1;
      end else request(1,0);
     end
     RAMP:begin
      if(pending_mask==0)begin state<=PHASE_WAIT;wait_started<=now_ms;end
      else if(!moving_found)begin ramp_q16<=65536;cap_min<=65536;lane<=0;state<=CAP_START;end
      else begin
       // Reuse the restoring divider; no wide combinational constant divisions.
       dividend<=elapsed<400 ? {5'd0,acceleration_numerator}:(elapsed-200)*32'd65536;
       ramp_elapsed<=elapsed;
       divisor<=elapsed<400 ? 6250:1000;divide_start<=1;state<=RAMP_WAIT;
      end
     end
     RAMP_WAIT:if(divide_done)begin ramp_q16<=quotient;state<=STARTUP_START;end
     STARTUP_START:begin
      if(ramp_elapsed<150)begin dividend<=ramp_elapsed*32'd1966;divisor<=150;divide_start<=1;state<=STARTUP_WAIT;end
      else begin ramp_q16<=ramp_q16+1966;cap_min<=65536;lane<=0;state<=CAP_START;end
     end
     STARTUP_WAIT:if(divide_done)begin ramp_q16<=ramp_q16+quotient;cap_min<=65536;lane<=0;state<=CAP_START;end
     CAP_START:begin
      if(!pending_mask[lane] || travel<=8)begin
       if(lane==4)begin
        reference_q16<=reference_q16>(ramp_q16<cap_min ? ramp_q16:cap_min) ? reference_q16:(ramp_q16<cap_min ? ramp_q16:cap_min);
        lane<=0;state<=READ;
       end else lane<=lane+1'b1;
      end else begin
       dividend<=((progress>travel ? travel:progress)*32'd65536)+lead_numerator;
       divisor<={6'd0,travel};divide_start<=1;state<=CAP_WAIT;
      end
     end
     CAP_WAIT:if(divide_done)begin
      if(quotient<cap_min)cap_min<=quotient[16:0];
      if(lane==4)begin
       reference_q16<=reference_q16>(ramp_q16<(quotient<cap_min ? quotient:cap_min) ? ramp_q16:(quotient<cap_min ? quotient:cap_min)) ? 
        reference_q16:(ramp_q16<(quotient<cap_min ? quotient:cap_min) ? ramp_q16:(quotient<cap_min ? quotient:cap_min));
       state<=READ;lane<=0;
      end else begin lane<=lane+1'b1;state<=CAP_START;end
     end
     READ:begin
      if(!pending_mask[lane])next_pending;
      else if(deadline_fault)finish_all(7,2);
      else request(1,0);
     end
     LOOKUP:state<=EVALUATE;
     EVALUATE:begin
      sample_event<=1;sample_lane<=lane;normal_upper<=covered ? model_upper:10'h3ff;load_limit<=current_limit;
      last_feedback[lane]<=now_ms;position[lane]<=position_hold[9:0];
      if(excess)begin
       if(!excess_active[lane] || fresh_gap>50)begin excess_since[lane]<=now_ms;excess_count[lane]<=1;end
       else if(excess_count[lane]<255)excess_count[lane]<=excess_count[lane]+1'b1;
       excess_active[lane]<=1;
      end else begin excess_active[lane]<=0;excess_count[lane]<=0;end
      if(magnitude>=current_limit)begin if(!hard_active[lane])hard_since[lane]<=now_ms;hard_active[lane]<=1;end
      else hard_active[lane]<=0;
      if(temp_hold>=45 || (error_hold & 8'hfe)!=0 || position_hold<bound_low(lane) || position_hold>bound_high(lane) ||
         fresh_gap>=200 || age_ms(now_ms,guard_started)>=24000)finish_all(7,3);
      else if(hard_now || excessive_now)begin
       if(phase==0)finish_all(7,4);
       else begin contact_retire<=1;state<=HOLD_RETIRE;end
      end else if(error_distance<=8)begin
       last_progress[lane]<=now_ms;
       if(!arrival_active[lane])begin arrival_since[lane]<=now_ms;arrival_active[lane]<=1;end
       if(arrival_active[lane] && age_ms(now_ms,arrival_since[lane])>=100 && reference_q16>=65536)begin
        contact_retire<=0;state<=HOLD_RETIRE;
       end else state<=GOAL;
      end else begin
       arrival_active[lane]<=0;
       if((reference_q16<65536 && close_to_reference) || error_distance+2<=best_error[lane])begin
        last_progress[lane]<=now_ms;if(error_distance+2<=best_error[lane])best_error[lane]<=error_distance[9:0];state<=GOAL;
       end else if(age_ms(now_ms,last_progress[lane])>=stall_ms)finish_all(7,5);
       else state<=GOAL;
      end
     end
     GOAL:begin
      if(deadline_fault)finish_all(7,2);
      else if((positive && next_goal>commanded[lane]) || (!positive && next_goal<commanded[lane]))request(4,next_goal);
      else next_pending;
     end
     HOLD_RETIRE:request(4,position[lane]);
     OFF_RETIRE:request(2,0);
     VERIFY_RETIRE:request(6,0);
     ROUND_WAIT:if(age_ms(now_ms,wait_started)>=6)state<=RAMP;
     PHASE_WAIT:if(age_ms(now_ms,wait_started)>=250)begin
      if(active_mask==0)begin finalizing<=1;final_status<=0;off_failed<=0;state<=OFF_ALL;lane<=0;end
      else begin phase<=phase==1 ? 2:1;phase_started<=now_ms;pending_mask<=active_mask;
       reference_q16<=0;state<=PHASE_READ;lane<=0;excess_active<=0;hard_active<=0;arrival_active<=0;end
     end
    endcase
    if(feedback_valid)begin
     if(!feedback_ok && state!=OFF_ALL && state!=VERIFY_ALL)finish_all(7,0);
     else case(state)
      OFF_ALL:begin if(!feedback_ok)off_failed<=1;state<=VERIFY_ALL;end
      VERIFY_ALL:begin
       if(!feedback_ok || feedback_torque!=0)off_failed<=1;
       if(lane==4)begin
        if(finalizing || off_failed || !feedback_ok || feedback_torque!=0)begin
         running<=0;done<=1;status<=off_failed || !feedback_ok || feedback_torque!=0 ? 7:final_status;state<=IDLE;
         off_verified<=!off_failed && feedback_ok && feedback_torque==0;active_mask<=0;
        end else begin lane<=0;state<=CONFIG;end
       end else begin lane<=lane+1'b1;state<=OFF_ALL;end
      end
      CONFIG:begin
       if(feedback_config[319:0]!=expected_config(lane) || feedback_config[391:384]!=1)finish_all(8,1);
       else state<=INITIAL;
      end
      INITIAL:begin
       if(feedback_position>1023 || feedback_temperature>=45 || (feedback_error & 8'hfe)!=0 ||
          (lane!=1 && (feedback_position<bound_low(lane) || feedback_position>bound_high(lane))))finish_all(7,3);
       else if(lane==4)begin lane<=0;state<=PHASE_READ;phase_started<=now_ms;pending_mask<=active_mask;reference_q16<=0;end
       else begin lane<=lane+1'b1;state<=CONFIG;end
      end
      PHASE_READ:begin
       if(feedback_position<bound_low(lane) || feedback_position>bound_high(lane) || feedback_temperature>=45 || (feedback_error & 8'hfe)!=0)finish_all(7,3);
       else begin
        initials[lane]<=feedback_position[9:0];position[lane]<=feedback_position[9:0];commanded[lane]<=feedback_position[9:0];
        best_error[lane]<=1023;last_progress[lane]<=now_ms;last_feedback[lane]<=now_ms;excess_count[lane]<=0;
        if(lane==4)begin lane<=0;state<=HOLD_GOAL;end else lane<=lane+1'b1;
       end
      end
      HOLD_GOAL:if(lane==4)begin lane<=0;state<=ENABLE;end else lane<=lane+1'b1;
      ENABLE:if(lane==4)begin lane<=0;state<=BASELINE;guard_started<=now_ms;end else lane<=lane+1'b1;
      BASELINE:begin
       last_feedback[lane]<=now_ms;last_progress[lane]<=now_ms;
       if(feedback_load[9:0]>=profile_hard || feedback_temperature>=45 ||
          feedback_position<bound_low(lane) || feedback_position>bound_high(lane))finish_all(7,4);
       else if(lane==4)begin lane<=0;state<=RAMP;motion_started<=now_ms;end else lane<=lane+1'b1;
      end
      READ:begin
       position_hold<=feedback_position;load_hold<=feedback_load;error_hold<=feedback_error;temp_hold<=feedback_temperature;
       state<=LOOKUP;
      end
      GOAL:begin commanded[lane]<=bus_target;next_pending;end
      HOLD_RETIRE:state<=OFF_RETIRE;
      OFF_RETIRE:state<=VERIFY_RETIRE;
      VERIFY_RETIRE:begin
       if(feedback_torque!=0)finish_all(7,6);
       else begin
        pending_mask[lane]<=0;
        if(contact_retire)begin active_mask[lane]<=0;retired_mask[lane]<=1;end
        next_pending;
       end
      end
     endcase
    end
    // STOP is observed between complete packets; never emits a partial packet.
    if(stop && bus_ready && !bus_valid && state!=OFF_ALL && state!=VERIFY_ALL)begin
     finalizing<=1;final_status<=7;off_failed<=0;state<=OFF_ALL;lane<=0;
    end
   end
  end
 end
endmodule
`default_nettype wire
