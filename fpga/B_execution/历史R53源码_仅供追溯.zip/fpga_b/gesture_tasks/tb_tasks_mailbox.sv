`timescale 1ns/1ps
module tb_tasks_mailbox;
 reg src_clk=0,dst_clk=0,rst_n=0;
 always #20.833333 src_clk=~src_clk;
 always #3.367003 dst_clk=~dst_clk;
 reg src_valid=0,commit=0;
 reg [679:0] data=0,expected=0;
 wire ready,pulse;wire [679:0] published;
 b_v2_mailbox #(.WIDTH(680)) d(src_clk,rst_n,src_valid,ready,data,
  dst_clk,rst_n,commit,published,pulse);
 integer trial,lane,pulses=0,prior;
 always @(negedge dst_clk)if(rst_n && pulse)begin
  if(published!==expected)$fatal(1,"mailbox mixed/torn publication");
  pulses=pulses+1;
 end
 task submit;
  begin
   @(negedge src_clk);wait(ready);
   for(lane=0;lane<21;lane=lane+1)data[lane*32+:32]=$random;
   data[679:672]=$random;expected=data;src_valid=1;
   @(negedge src_clk);src_valid=0;data=~data;
   repeat(12)@(negedge dst_clk);
  end
 endtask
 initial begin
  repeat(5)@(negedge src_clk);rst_n=1;
  repeat(5)@(negedge src_clk);
  for(trial=0;trial<64;trial=trial+1)begin
   prior=pulses;submit();
   if(pulses!=prior)$fatal(1,"mailbox published before commit");
   commit=1;@(negedge dst_clk);commit=0;
   wait(pulse);@(negedge src_clk);
   if(pulses!=prior+1)$fatal(1,"mailbox missing/duplicate completion");
   repeat(8)@(negedge dst_clk);
   if(published!==expected)$fatal(1,"mailbox output changed without commit");
  end
  submit();rst_n=0;repeat(4)@(negedge src_clk);
  if(published!==0 || pulse)$fatal(1,"mailbox reset failed");
  rst_n=1;repeat(12)@(negedge src_clk);
  if(published!==0 || pulse)$fatal(1,"mailbox replayed cancelled request");
  submit();commit=1;@(negedge dst_clk);commit=0;
  wait(pulse);@(negedge src_clk);
  if(pulses!=65)$fatal(1,"mailbox post-reset completion");
  $display("PASS: 65 atomic 680-bit publications at production clocks, busy payload isolation, commit gating and pending-reset cancellation");$finish;
 end
 initial begin #1000000;$fatal(1,"mailbox watchdog");end
endmodule
