`timescale 1ns/1ps
module b_tasks_div(input wire clk,rst_n,start,input wire [31:0] numerator,input wire [15:0] denominator,
 output reg busy,done,output reg [31:0] quotient);
 reg [31:0] work;reg [16:0] rem;reg [15:0] divisor;reg [5:0] bit_index;
 wire [16:0] next_rem={rem[15:0],work[31]};
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin busy<=0;done<=0;quotient<=0;work<=0;rem<=0;divisor<=0;bit_index<=0;end
  else begin
   done<=0;
   if(start && !busy)begin busy<=1;work<=numerator;divisor<=denominator;rem<=0;bit_index<=0;end
   else if(busy)begin
    rem<=next_rem>=divisor?next_rem-divisor:next_rem;
    work<={work[30:0],next_rem>=divisor};
    if(bit_index==31)begin quotient<={work[30:0],next_rem>=divisor};done<=1;busy<=0;end
    else bit_index<=bit_index+1'b1;
   end
  end
 end
endmodule
